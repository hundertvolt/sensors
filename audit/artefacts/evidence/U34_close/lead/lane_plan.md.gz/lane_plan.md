# U34 lane plan (P1 and P2, agents, 2026-10-21; read-only at c6b8a07). LEAD NOTES at the end.

## P1 (step table, open findings, packet vs code)

# U34 plan, block P1 (agent, 2026-10-21; read-only at c6b8a07)

I used about 47 tool calls and covered all 37 steps (42 M.IDs), both open findings and the one REGISTER carry. Line numbers are at `c6b8a07` in `S/wt-u33plan`. My helper scripts are in `S/u34/plan_scratch/` (wo.py, wo2.py, wo3.py, hostnames.py).

## 1. Counts and step table
The work order (`audit/order/work_order.json`, unit U34) has 42 steps (29 explicit, 13 implicit), 19 actions and 28 files. Its hardware rounds are `{"R1": ["H25","H73"], "R3": ["H73"]}`. **None of U34's own edits needs the bench.** H25 and H73 come in only through carried actions A.U26.66 and A.U28.35, and those already landed in U26 and U28.

**[FW]** marks a `src/` edit. Header rewrites keep 3 lines → 3 lines and are comments only: mpy-cross drops comments and the line numbers stay the same, so the frozen image does not change.

| # | M.ID | files | verdict | evidence at c6b8a07 |
|---|---|---|---|---|
| 1 | DOCS.001 | THIRD_PARTY_LICENSES.md | to write | :3-7 still says "MIT overall with that one documented exception". The names it needs already exist: `UDPSocket` src/asy_udp_socket.py:38, `CaptiveDNS`/`DNSQuery` src/asy_captive_dns.py:52/:157. Use M.DOCS.001's "post-audit only" form, as SPEC:40-42 has it, not A.U34.01's "until the C side is reconciled". |
| 2 | DOCS.002 | THIRD_PARTY | part landed + conflicts | Landed at :15-22: tag `v2.7.0`, the test pointer, and the `ext/typings/microdot/` stubs. Left: name the three stub files and add "(type-checking only, never frozen)" and "on 2026-10-06" (the date CLAUDE.md:124 records). :19 "between `v2.0.1` and `v2.1.0`" is wrong: `git describe 482ab6d` in S/corpus/microdot-new gives `v2.0.6-4-g482ab6d`, which is before v2.0.7. That is U36's stage in the packet; it is the same sentence, and I suggest fixing it now. **Conflict:** test_vendored_microdot.py:21 and :40-43 need the literal "`ext/microdot.py`, pinned `vX.Y.Z`". The packet's wording ("`ext/microdot.py` and upstream's type stubs …, pinned `<tag>`") breaks that. Keep the tree's word order and add the stub names after it. |
| 3 | DOCS.003 | THIRD_PARTY | to write | :23-25 is the old wording. All five ext/freezefs sha256 values equal A.U34.08 (4)'s, and test_vendored_freezefs.py:10 gives `26be9e339a25…` (2025-10-25). The holders the entry quotes are in the tree: ext/freezefs/LICENSE:3 "Copyright (c) 2022 bixb922", and line 1 of archive.py, ffsextract.py and ffsmount.py "(c) 2023 Hermann Paul von Borries". Comment stripping is at archive.py:165-167, inside the :150-175 the entry cites. No fetch is needed. |
| 4a | DOCS.004 | THIRD_PARTY | to write | :29-31 still has "the one non-Adafruit file below" (:31). |
| 4b | DOCS.005 | THIRD_PARTY | to write | The first ISL entry (:36-41) is deleted. The second (:48-55) is rewritten; it still says "FRAM-persisted gain-ratio self-calibration" (:54-55). |
| 4c | DOCS.007 | THIRD_PARTY | to write | :78-81 still has "its own module docstring" and "this attribution predates…". The header itself is a `#` comment: src/asy_dns_client.py:1-3. |
| 4d | DOCS.009 | THIRD_PARTY | to write | Section :109-123; :120-123 is the "used to be listed" paragraph. All 20 legacy files the text names exist. Headers: SPDX present in legacy bmp3xx, scd30, sgp40 (both files), isl29125, mprls, shtc3, captive_dns and asy_udp_socket; absent in legacy asy_fram_driver, CommonDrivers/microdot, async_connect and all eight legacy/dev_drivers copies. This matches A.U34.10. |
| 5 | GEN.051 | ext/microdot.py, ext/LICENSE-microdot | landed | v2.7.0, with hashes at test_vendored_microdot.py:14-15. Whether a newer upstream tag exists is the dependency-refresh bullet's job, not this step's. |
| 6 | GEN.050 | ext/typings/microdot/*.pyi | landed | The three files are pinned at test_vendored_microdot.py:16-18. `ext/typings` is on mypy_path (pyproject.toml:367). No `microdot` import ignore remains (grep). |
| 7 | SCR.066 | scripts/build_firmware.py | landed (check-only) | build_firmware.py:44-62, :77-78, :94-105, :109-111 and :122 (sorted list). Only named modules are staged, so `ext/typings` is never frozen. |
| 8 | SCR.072 | scripts/build_frozen_html.sh | landed | Header :2-4, help :7-18, :29-32, :42-51, the 254 check :53-61, pinned clock and sorted walk :66-76. The old `:30` comment now has no "2.4", so A.U34.08 (3) is already met. |
| 9 | SPEC.005 | SPECIFICATION.md | part landed | U34's stage is one line: SPEC:61 "freezefs 2.4, unmodified" → "freezefs `main` at `26be9e3`, unmodified". Stages 1-2 landed (:37-50, :59-60, :80-82). Stage 4 belongs to U36: :35 datasheets (now stale: .gitmodules:1-3), :51 "(Part D)", :56-57 improved-quality, :62 "variant", :85. Small difference: :60 says "upstream v2.7.0 type stubs for it, unmodified (A.5)", where the packet has "…never frozen (B.15)". That is U0's stage; leave it for U36. |
| 10 | SRC_NET.005 | src/LICENSE-captive_dns | part landed, **needs upstream** | :1-3 paths and names landed. Left: :201 "Copyright 2019 p-doyle (Micropython-DNSServer-Captive-Portal contributors)", which needs the sourced year; and a NOTICE append at the end (:213), if upstream has a NOTICE file. |
| 11 | SRC_NET.002 | src/asy_captive_dns.py **[FW]** | to write, **needs upstream** | :1-3 header; :2 still scopes `Apache-2.0` to the whole file. The year is sourced from upstream, or dropped. |
| 12 | DOCS.010 | THIRD_PARTY | part landed, **needs upstream** | Landed: paths and names at :130-131, :138, :148, :201, and the §4(b) list at :147-152. Left: the SPDX scope sentence with holder, year and NOTICE, after :135-139. |
| 13 | SRC_NET.025 | src/asy_udp_socket.py **[FW]** | part landed | The docstring (:5-8) no longer has the context-manager clause. Left: header :1-3 (the discussion link). |
| 14 | DOCS.013 | THIRD_PARTY | part landed | Landed: :192-193 `UDPSocket` and its paths; :197 "locking, input validation"; :201 `asy_captive_dns.py`. Left: :208-210 → A.U34.06 (2). See REGISTER U30 below: :189-198 changes if `write_and_recvfrom()` goes. |
| 15 | SPEC.142 | SPECIFICATION.md | to write (stage 6), **after U33** | K.9 is at SPEC:9989. The bullet to rewrite is :10003-10004, "(SPDX header + attribution, matching the file's existing entries)". U33's new B.16 (after :2745-2746) moves these lines. K.5.1 is U36's: C.11.1 is still at :4186. A.U25.67 and A.U26.66 landed: tests_scripts/test_twin_fake_catalog.py, tests_hardware/conformance.py, flash/test_chip_conformance.py. |
| 16 | SRC_CORE.100 | src/asy_fram_driver.py **[FW]** | part landed | The docstring (:5-6) and the :8-10 comment are already the end state. Left: header :1-3 (the pointer line sits before the licence line). |
| 17 | SRC_SENS.014 | src/voc_algorithm.py | landed | The docstring at :5-7 landed (U12 2949ed9). U30 (06a8ae5) changed the last clause to "…the state codec answers False for what struct refuses". Keep the tree's text. |
| 18 | SRC_SENS.038 | src/asy_bmp3xx_driver.py **[FW]** | part landed | :6 `BMP3XX_Reader` and :7 sources landed. Left: header :1-3. |
| 19 | SRC_SENS.070 | src/asy_isl29125_driver.py **[FW]** | part landed | Imports :10-33 landed; the tree also has `CfgValue` under TYPE_CHECKING (:31). The only quoted annotations left name TYPE_CHECKING symbols (grep). Left: header :1-3. |
| 20 | TEST_UNIT.331 | tests/voc_reference_vectors.py | landed | :1-3 header names gas-index-algorithm 2ef9f13 and embedded-sgp e9ecd60 (U12). |
| 21 | TOOL.020 | .github/workflows/ci.yml | landed (check-only) | Action pins are in the table below. Local `./` uses stay: actionlint-py is 1.7.12.25 (pyproject:34) and .github/zizmor.yml keeps `self-repository: disable`. No `submodules:` key. OF-208 joins this file. |
| 22 | TOOL.028 | pyproject.toml | part landed | `ignore` (:69-150) is in U28 form; U33's row 29 checked it and E722 is not listed. Left: the CPY001 comment at :147-148, "carry SPDX headers" → "carry an attribution header (SPDX where a license is named)". U33 writes no pyproject change. Its CLAUDE.md E722 bullet text (A.U33.06, CLAUDE.md:902-905) does not affect this step. |
| 23 | TOOL.030 | pyproject.toml | part landed | The per-file block :180-353 is restructured. Left for U34: six `ANN401` entries and their category comments, :261-264, :267-271, :272-276 (tests/machine.py, digital_twin/machine.py, test_asy_uart_comm.py, test_asy_uart_driver.py, _bus_hazard_catalog.py, _sensortask_scenarios.py). They are still live, because those files still hold `Any`. They go only once the explicit-Any sweep clears them (see step 27). |
| 24 | DOCS.066 | BACKLOG.md | to write, **after U33** | The list is :518-975. U33 adds A.U33.04's paragraph after :609-612 and R-18's four files. U34 adds its own paragraph after the last one (:971-975, 2026-10-21), before :976. Contents: pyproject (CPY001 comment, ANN401 and baseline removal), the two ini baselines, ci.yml if OF-208 lands, the new L0 test. The list never named `test_vendored_freezefs.py` (U0, 8104062), which fits A.U34.08's "new L0 freezefs hash test — no leg affected". |
| 25 | SCR.026 | scripts/typecheck.sh | landed | Header :2-4, help :6-18, venv/python/summary :20-28, stage and trap :30-45, `exit 0` :197. The usage wording was later changed to "CI passes none". |
| 26 | SCR.028 | scripts/typecheck.sh | landed | :159-163 (`--no-sync`) and the passes :180-192, plus a later bench-conftest check at :190. |
| 27 | TOOL.033 | pyproject.toml | part landed | The decorator override is gone (no `disallow_untyped_decorators` left), and the `frozen_html` block is in place (:411-415). Left: the baseline :417-437 still exempts **15 modules**. Explicit `Any` counts by grep: `_sensortask_scenarios` 79, `test_asy_uart_comm` 26, `test_asy_uart_driver` 23, `_bus_hazard_catalog` 21, tests/machine.py 9, `test_bus_hazard_generated` 8, src/asy_system_service.py 7 **[FW, typing only]** (:229-230, :297, :480, :744), `test_bus_hazard_multi_device` 5, `_boot_contiguity_probe` 3, `_uart_link_contract` 2, and five device scripts with 0 (probably stale entries). |
| 28 | TOOL.079 | host_typecheck.ini | part landed + **conflicts** | `enable_error_code` (:36-37), the flag (:38) and the conftest comment (:14-15) landed. Left: baseline :43-55 (`conftest` 0 `Any`, `http_client` 0, `scripts._hardware_verdict` 1, `test_cross_browser_smoke_probe` 8). **Conflict:** the step adds `scripts` to mypy_path (:27). The tree instead imports `scripts.` package-qualified: scripts/_digital_twin_ci_suite.py:35-37, tests_hardware/twin_board.py:17, tests_scripts/test_twin_board.py:21 and 5 more. With `explicit_package_bases`, a nearer `scripts` base would rename `scripts/_twin_process.py` to `_twin_process`. **Conservative option (agent, 2026-10-21):** keep mypy_path as it is, and change scripts/_hardware_verdict.py:22 to `from scripts._summary_block import …`, the form its siblings use; its ignores at :22 and :73 then go. That file is not in U34's list. |
| 29 | TSC.065 | tests_scripts/test_comment_block_cap.py | check-only, **after U33** | U33's R-3: `_WRAP_WIDTH = None` stays until owner question 6 is answered, and the "(owner-reviewed, 2026-10-02)" tag is not written. The A.U34.07 headers are 3 lines each. |
| 30 | TSC.109 | tests_scripts/test_mypy_any_baseline.py | to write | The test is still in U8 form (:50-60). Adding "nothing sets the flag false" fails until all three baselines are empty. |
| 31 | TSC.139 | tests_scripts/test_third_party_attribution.py (new) | to write | The file does not exist. It depends on steps 11, 13, 16, 18 and 19. The six correct headers already pass it: sgp40, scd30, ntp_client, dns_client, voc_algorithm, and captive_dns line 3. |
| 32 | TSC.153 | tests_scripts/test_vendored_freezefs.py | landed (U0 8104062) | The pin is at :9-17. Optional, for consistency with test_vendored_microdot.py:40-43: a check that THIRD_PARTY_LICENSES.md names `UPSTREAM_COMMIT` once step 3 writes it. |
| 33a | DOCS.008 | THIRD_PARTY | to write | The VOC entry :95-107 still says "MIT terms are the operative ones" with no actor. Use the "(agent, 2026-08-20; not a verified legal conclusion)" form. |
| 33b | DOCS.011 | THIRD_PARTY | to write | Goes before :161. The upstream files are local: /root/pico-toolchain/micropython is at v1.29.0, and its seven submodule commits equal A.U34.09's. The rest also checks out: mbedTLS is dual Apache-2.0 OR GPL-2.0-or-later with no NOTICE file; the board manifests and mpconfigboard.cmake:5-17 match; mpconfigport.h:216-217 is as stated; cyw43 LICENSE.RP and LICENSE:12 match. CI uploads coverage and logs only (ci.yml:347, :604-668); package.json has devDependencies only. |
| 33c | DOCS.014 | THIRD_PARTY | to write | New section at the end. Its precondition holds: the datasheets submodule is at .gitmodules:1-3. |
| 34 | DOCS.060 | README.md | to write (U34 stage) | Licence bullet at README:931-935, with the "source couldn't be established" claim. Use M.DOCS.060's "post-audit only" wording. The map rewrite (:847-) is U36's. A.U32.01 landed (README:440). |
| 35 | SPEC.098 | SPECIFICATION.md | landed | SPEC:6427-6447: the successor, the 2ef9f13/e9ecd60 vectors, and the last sentence verbatim. |
| 36 | TSC.154 | tests_scripts/test_vendored_microdot.py | landed | :13-19, :28-31. |
| 37 | TWIN.075 | digital_twin/typecheck.ini | part landed | :1-10 (3+2+3 lines), :12, :17, :27-28 and :33 landed. Left: baseline :32-40 (`machine`, digital_twin/machine.py with 5 `Any`; `test_digital_twin_bus_hazard_concurrency` with 5). |

**Totals (42 M.IDs):**
- Landed: 12 (5, 6, 7, 8, 17, 20, 21, 25, 26, 32, 35, 36).
- Part landed: 14 (2, 9, 10, 12, 13, 14, 16, 18, 19, 22, 23, 27, 28, 37).
- To write: 15 (1, 3, 4a-d, 11, 15, 24, 30, 31, 33a-c, 34).
- Check-only: 1 (29).
- Overlays: after U33 on 15, 24 and 29; needs upstream on 10, 11 and 12; conflicts on 2 (test regex), 28 (`scripts` base) and 29 (U33's R-3).
- Hardware: none.

**Where the 19 carried actions land:**
- A.U34.01 → step 1.
- A.U10.37 and A.U10.38 → step 1 (names already in the tree).
- A.U34.12 → steps 2, 5-9 and 36.
- A.U34.08 → steps 3, 8, 9, 24 and 32.
- A.U34.03 → step 4a-c; A.U34.10 → step 4d.
- A.U34.09 → steps 7, 21, 33b and 33c.
- A.U28.35 → step 9 (landed: .gitmodules).
- A.U8.23 → step 9 (landed: pyproject:367).
- A.U34.05 → steps 10-12; A.U34.06 → steps 13-14.
- A.U25.67 and A.U26.66 → step 15 (code landed; K.5/K.5.1 is U36's).
- A.U34.07 → steps 15-19, 22, 29 and 31.
- A.U34.04 → steps 17, 20, 33a and 35.
- A.U34.11 → steps 23-28, 30 and 37.
- A.U32.01 → step 34 (landed); A.U34.02 → step 34.

**Pinned versions, tree today against the step text:**

| Item | Tree today | Step text |
|---|---|---|
| Microdot | `v2.7.0` (THIRD_PARTY:16, SPEC:59, test :14) | "the tag B0 leaves (`v2.6.2` if held)" — B0 left v2.7.0 |
| Microdot stubs | three files at v2.7.0 (test :16-18) | the same tag as the module |
| Legacy Microdot copy | `482ab6d` (CLAUDE.md; THIRD_PARTY:19 states it wrongly) | `482ab6d` |
| freezefs | `26be9e3` (test only; THIRD_PARTY says "main … 2026-09-10"; SPEC:61 says "2.4") | `26be9e3` |
| GitHub actions | checkout@v7 ×16, setup-node@v7 ×8, cache@v6 ×6, upload-artifact@v7 ×6, dorny/paths-filter@ceb8a2b (v4.0.3) | "the newest major" |
| ruff / mypy | 0.16.10 / 2.4.0 (pyproject:24, :23) | "the refreshed ruff", no number |
| Stubs package | board 1.29.0.post1, stdlib 1.29.0.post2 (versions.toml:16-17) | — |
| MicroPython | v1.29.0 (versions.toml:10) | v1.29.0 |
| actionlint-py / zizmor | 1.7.12.25 / 1.30.1 | `$/` uses only if actionlint accepts them |

**Needs upstream (one fetch for the lead):** `github.com/p-doyle/Micropython-DNSServer-Captive-Portal`, default branch. From it: the first commit of `main.py` (year and SHA, from `git log --reverse -- main.py`), whether a `NOTICE` file exists, and `LICENSE`. If it cannot be reached, the year is dropped in all three places and the failure goes on the OR4.a egress list. Nothing else needs fetching; local copies:
- Microdot: S/corpus/microdot-new at 7742db9 (v2.7.0).
- freezefs: S/pass4/F/ffs/freezefs at 26be9e3.
- gas-index-algorithm: S/corpus/gas-index-algorithm.
- MicroPython: /root/pico-toolchain/micropython at v1.29.0.

## 2. Open findings and carries
- **OF-96** (no freezefs hash pin). Closed by the tree: tests_scripts/test_vendored_freezefs.py:1-31 (U0, 8104062). It joins step 32; close it with that citation.
- **OF-208** (Playwright cache key has no runner-image identity). Open. The row cites ci.yml:175; the key is now at ci.yml:183 and also :244, :297 and :383 (four jobs, the first `web-unit-tests` at :153). Fix: an identity step like .github/actions/setup-micropython-toolchain/action.yml:19-21 (ImageOS, gcc, ldd) before each cache, with its output added to each key. It is its own step, in the same file as step 21. Optionally pin the form in tests_scripts/test_ci_workflow.py (Playwright checks at :284; not in U34's file list). The remaining `actions/cache` site gets checked for the same class.
- **REGISTER U30 carry** (REGISTER.md:726): `UDPSocket.write_and_recvfrom()` (src/asy_udp_socket.py:175, the `tries` guard at :187-188) has no caller in `src/`; its only callers are tests. **[FW, real bytecode change]** Removing it touches:
  - THIRD_PARTY:189-198 (the comparison sentence, joins step 14).
  - SPEC:6254 (mentions the method).
  - tests/test_asy_udp_socket.py:276-354, :454, :1410-1505, :1899-1913 and :1998-2010. This file is not in U34's list, and the NTP-shaped exchange tests at :1410-1505 would need rewriting onto `write()`/`recvfrom()`.
  - It is its own step; P2 rules on scope.

## 3. Packet vs code
**Moved sites (packet line → now):**
- THIRD_PARTY:

  | Packet | Now |
  |---|---|
  | :15-20 | :15-22 |
  | :21-23 | :23-25 |
  | :27-29 | :27-31 |
  | :34-39 | :36-41 |
  | :46-53 | :48-55 |
  | :76-79 | :78-81 |
  | :93-105 | :95-107 |
  | :107-121 | :109-123 |
  | :128-148 | :130-152 |
  | :157 | :161 |
  | :175-205 | :179-210 |
  | :188 | :192-193 |
  | :203-205 | :208-210 |

- SPEC: A.1 :33-92 → :34-93 (:63 → :61); K.9 :5937-5938 → :10003-10004; F.4 :3669-3676 → :6420-6447; C.11.1 :2348 → :4186.
- pyproject: ignore :53-195 → :58-150; CPY001 :192-193 → :147-148; per-file :214-351 → :180-353; overrides :408-413 → :411-437; mypy_path :365 → :367.
- README: :723-726 → :931-935; map :641 → :847. BACKLOG chroot list :515-613 → :518-975.
- typecheck.sh: :1-14 → :1-45; :99-130 → :159-197.
- The inis: host :1-36 → :1-55; twin :1-28 → :1-40.
- build_firmware.py: :39-108 → :44-123. build_frozen_html.sh: :30 → :66.

**Names:** the work order's file list still names `src/captive_dns.py`, which is now `src/asy_captive_dns.py`. The renames `AsyUDPSocket` → `UDPSocket` and `DNSServer` → `CaptiveDNS` landed in U10.

**Done by U0-U32:**
- U0: the Microdot re-vendor, the stubs and the freezefs pin.
- U8 and U19: the stub hash table.
- U12: the VOC vectors and F.4.
- U12, U15, U16, U18 and U30: the docstring halves of five headers.
- U20: the `frozen_html` override.
- U25 and U26: the twin catalog and the conformance probes.
- U27: the staging, the frozen site, typecheck.sh, `enable_error_code` and the decorator override's removal.
- U28: the datasheets submodule and the restructured lint scheme.
- U32: the reflash runbook.

**BACKLOG items touched:**
- Owner question 6, "Count a long comment line as several?" (BACKLOG.md:1296-1302): step 29.
- "Refactor targets not yet done", first bullet, "Mypy shall be configured to disallow `Any` types" (:21-30): steps 23, 27, 28, 30 and 37. Its "Deferred to a dedicated future session (project owner, 2026-09-11)" is overtaken by OR81.a (owner, 2026-09-28: "do it in this audit"; typing only, the frozen image behaves the same; PROJECT_AUDIT_PLAN.md:432-433). Rewriting that bullet is U36's job (A.U34.11's blast).
- The deferred chroot-list entry (:518-975): step 24.
- The deferred "`arduino/` and the C reconciliation are post-audit only" (:514): the wording source for steps 1 and 34.
- If A.U34.11 (4)'s `disallow_any_unimported` count is not zero, it becomes owner question 8 (CLAUDE.md decision rule 4).

**For P2 to rule:**
- (a) **The explicit-Any sweep is the bulk of U34's code.** 21 baseline modules remain in total: 15 main, 2 twin, 4 host. They include src/asy_system_service.py and test files outside the 28-file list. A.U34.11 (1) lists what is left for the OR2.c review, but OR81.a says every pass must be clean before B5.
- (b) The step 28 conflict and its conservative option.
- (c) Step 2's word order, so the test regex at test_vendored_microdot.py:21 still matches.
- (d) The scope of the `write_and_recvfrom()` removal.
- (e) The scope of OF-208's sweep (4 keys).
- (f) Whether U34 fixes the legacy Microdot commit text now, rather than in U36.

**Not determinable read-only:**
- Whether the baseline modules that show 0 `Any` still hold findings: the five device scripts, `http_client` and `conftest`. A typecheck run with each section removed settles it.
- The exact per-pass explicit-Any and `disallow_any_unimported` counts: needs a mypy run.
- p-doyle's year and NOTICE: needs the fetch above.
- Whether the new THIRD_PARTY text passes test_decision_vocabulary.py, which scans that file (`_LICENCE_FILE`, :29) and has no allowlist entry for it: an L0 run settles it.
- Whether newer upstream tags or action majors exist: the dependency refresh's job, not U34's.
- The source of the "owner-reviewed, 2026-10-02" tag that DOCS.011 carries: check it at landing, in the same spirit as U33's R-3.

## P2 (cut, waves, rulings, risks, blocks, shards)

# U34 plan, block P2 (agent, 2026-10-21; read-only at c6b8a07)

I used about 55 tool calls. Line numbers are at `c6b8a07` in `S/wt-u33plan`. Lanes branch from U33's close head, so every BACKLOG and SPEC site is found by its quoted text, not its number. My helper scripts are in `S/u34/plan_scratch/`: p2_route.py, p2_files.py, p2_allow.py.

### P2.1 Findings that change the cut (beyond P1)
- **None of the 21 baseline modules is in U34's 28 files.** Only their config lines are (pyproject.toml, the two inis).
  - pyproject.toml is also held by U36 and U37. The two inis and test_mypy_any_baseline.py are held only by U37 (work_order.json).
  - U35's file list names `asy_system_service.py` by its bare name. U30 read such a bare name as the `src/` file (REGISTER.md:724).
- **Eight baseline modules hold no explicit `Any`** (grep):
  - the five device scripts (tests_hardware/device_scripts/{allocation_need_per_source, serving_at_default_gc, uart_crossover_exchange, uart_crossover_recovery, uart_driver_read_never_blocks_the_loop}.py);
  - tests_hardware/conftest.py, tests_hardware/http_client.py;
  - scripts/_hardware_verdict.py: its one grep hit is the :73 comment "Summary is Any to mypy".
  - Removing these eight entries is a config-only edit inside U34's own files.
- **The mypy-path conflict is real.** In mypy 2.4.0 (pyproject:23; installed copy at /home/user/sensors/.venv/.../mypy/find_sources.py:185-187), the crawl up from a file stops at the nearest explicit base. With `scripts` on mypy_path, scripts/_twin_process.py would get the name `_twin_process`. scripts/_digital_twin_ci_suite.py:37 imports it as `scripts._twin_process`, so one file would carry two module names.
  - Only two bare-sibling imports are left: scripts/_hardware_verdict.py:22 (its ignores are :22, :73, :131) and tests_hardware/manual/runner.py:18.
  - Neither file is in U34's list. build_firmware.py:36 already uses the package-qualified form.
- **Removing `write_and_recvfrom()` changes the frozen image.** Nothing in `src/` calls it:
  - the resolver uses `write()` then `recvfrom()` (asy_dns_client.py:167-171), and so does the NTP client (asy_ntp_client.py:261-264);
  - the captive DNS uses `recvfrom()` and `sendto()` (asy_captive_dns.py:92, :117).
  - Its tests are in tests/test_asy_udp_socket.py, which is outside the list (U35 and U36 hold it later). The removal and those tests must land in one commit.
  - The NTP-pattern section says its purpose is to "mirror each caller's documented, stable call shape" (:1408-1416). The callers no longer make this call, so the three tests (:1419, :1458, :1487) are now wrong models.
- **The attribution test (step 31) reads both THIRD_PARTY and the five headers**, including asy_udp_socket.py:1-3. That puts THIRD_PARTY and the headers with one owner, and the UDP header has to be published early.
- **The Firefox cache key (ci.yml:409-417) is a different case.** It is a conda-forge environment that brings its own libraries, and its monthly roll is a recorded decision (agent, 2026-09-30; ci.yml:409-411). Only the four Playwright keys (:183, :244, :297, :383) carry OF-208's flaw.
- **The "owner-reviewed, 2026-10-02" tag has a source.** FOLD_BRIEF.md:32-34 defines the tag form, and FOLD_ANSWERS.md:249-251 marks `licence-notices` (refs A.U34.04/.05/.09) status=ok. The same answer settles "Apache-2.0 AND MIT" scoped to DNSQuery.
- **Allowlist rows** (p2_allow.py): vocab :48 (SPEC:9991, K.9) and citation :69 (SPEC:56) sit near U34's edits but in no line it edits. Vocab :256-257 quote tests/test_asy_udp_socket.py:1364 and :1831, outside the removal ranges. All must stay intact; no allowlist change is expected.

### P2.2 The cut (one owner per file; four agents at most, four in W1)

**Lane A (attribution)**
- Files: THIRD_PARTY_LICENSES.md, README.md, src/LICENSE-captive_dns, src/asy_captive_dns.py, src/asy_fram_driver.py, src/asy_bmp3xx_driver.py, src/asy_isl29125_driver.py, tests_scripts/test_third_party_attribution.py (new), tests_scripts/test_vendored_freezefs.py.
- Steps written: 1, 2 (R-5, R-6), 3, 4a-d, 10, 11, 12 (R-11), 14 (with R-7's sentence), 16, 18, 19, 31, 32 (R-10), 33a-c (R-20), 34.
- Open findings: OF-96 closes (R-9).
- Size: about 60 lines added and 40 removed in THIRD_PARTY (two new sections), 5 in README, 4 headers at 3 lines each, a new test of about 100 lines, +6 in the freezefs test.
- Checks at -1/32768: none. The headers are comments only, kept at 3 lines so line numbers hold, and an mpy-cross byte compare of the four files at base and head proves no bytecode change. The lead's gate runs both stages.
- Readers:
  - THIRD_PARTY: test_decision_vocabulary, test_vendored_microdot, test_vendored_freezefs, the new test.
  - README: test_bench_restores_serving, citations, device_script_bench_facts, digital_twin_generated_boot, harness_mpremote_retry, legacy_paths, persistence_write_marker_completeness, setup_toolchain_env.
  - asy_captive_dns: buildgen_definitions, buildgen_validate, fault_or_warning_never_both, task_tops.
  - asy_fram_driver: buildgen_limits, device_tomls, lint_sh, lock_order.
  - bmp3xx and isl29125: buildgen_definitions, driver_registry, error_contract, limits, schema_ast, source_agreement, validate, web_tag, wiring, config_schemas, device_script_config_schemas, digital_twin_scenarios, import_graph, import_placement, memory_catalog, counter_steps, isl29125_copies, lint_ceilings.
  - Repo scans: test_comment_block_cap, test_no_variant_literals.
- Seen failing first:
  - the new test names asy_udp_socket.py's header until <UDPHDR> is merged;
  - it names the two ISL entries until 4b merges them;
  - a planted header with no entry is named;
  - the freezefs commit check fails until step 3's text lands;
  - planting the packet's step-2 word order makes test_vendored_microdot.py:40-43 fail, which proves R-5.
- Depends on: <UDPHDR>, merged before A2's green run.

**Lane N (UDP and SPEC)**
- Files: src/asy_udp_socket.py **[FW]**, tests/test_asy_udp_socket.py (taken in by R-7), SPECIFICATION.md.
- Steps written: 13 (the header, published first as <UDPHDR>), the REGISTER carry (R-7), 9 (R-17), 15 (R-16), SPEC:6253-6254.
- Size: about −22 lines in src; about −120 and +40 lines in the test file; 3 edits in SPEC.
- Checks at -1/32768: earlier units' figures for balance only; the base is still to measure.
  - test_asy_udp_socket 7.21/7.22 s (S/u31)
  - test_asy_dns_client 0.80/0.81 s (S/u30)
  - test_asy_ntp_client 23.6/24.9 s (S/u30)
  - test_asy_captive_dns 25.58/25.60 s (S/u30)
  - test_digital_twin_sensortask_integration[dev] 22.95/23.65 s (S/u32/base_times.tsv)
- Readers: test_lock_order, test_twin_entry_point_order; the SPEC readers U33 listed (citations, import_placement, level_containment, lock_order, memory_catalog, task_inventory, threat_model_statement, timing_budget, toml_schema_contract, tunables_register); the repo scans; the main mypy pass.
- Seen failing first: none is needed for removing dead code. The proof is that `git grep write_and_recvfrom -- . ':!arduino' ':!audit' ':!legacy'` comes back empty and the main pass is green (a leftover caller fails it with attr-defined).

**Lane T (typing config)**
- Files: pyproject.toml, host_typecheck.ini, digital_twin/typecheck.ini, tests_scripts/test_mypy_any_baseline.py, BACKLOG.md.
- Checked only: scripts/typecheck.sh (steps 25, 26), test_comment_block_cap (step 29).
- Steps: 22, 23 (confirm the six ANN401 entries are live, R-13), 24 (R-15), 27, 28 (R-4), 30 (R-3), 37 (both twin entries still hold `Any`: unchanged), A.U34.11 (4) (R-14).
- Size: −5 module lines in pyproject and the CPY001 comment (:147-148); −3 sections in the host ini; +25 lines in the test; +8 in BACKLOG.
- Checks: none at -1/32768. typecheck.sh (three passes and three single-file runs): base to measure.
- Readers:
  - pyproject: test_ci_workflow, config_paths_resolve, host_annotations, lint_ceilings, lint_type_scopes, mypy_any_baseline, no_variant_literals, preview_server, ruff_exemptions_live, script_metadata_pins, suppression_form, tool_pins, typecheck_sh.
  - inis: buildgen_validate, digital_twin_boot_contiguity (15.54 s, S/u32), config_paths_resolve, lint_type_scopes, typecheck_sh.
  - BACKLOG: test_citations. The test: test_lint_type_scopes (:23).
- Seen failing first: an extra `disallow_any_explicit = false` exemption in a tmp config is named by the new subset guard.
- Depends on: nothing.

**Lane C (CI)**
- Files: .github/workflows/ci.yml, tests_scripts/test_ci_workflow.py (taken in by R-8).
- Steps: OF-208 (R-8); step 21 checked only.
- Size: 4 identity steps of 4 lines each and 4 keys; +15 lines of test.
- Checks: lint.sh (actionlint, zizmor). No GC stages.
- Readers: test_build_firmware, ci_workflow, js_coverage_report_dir, lint_type_scopes, test_sh, uv_sync_retried_sh, plus the repo scans.
- Seen failing first: the new pin fails at base on all four keys.
- Depends on: nothing.

**Lead**
- Proves the four file sets are disjoint.
- Runs the base checks on U33's close head, then verifies the check-only steps (5, 6, 7, 8, 17, 20, 21, 25, 26, 29, 32, 35, 36) there and again at the gate.
- At the close: re-records twin_record.json (the `src/` files change), runs the silent-failure scan, and writes the open-findings and register rows.

### P2.3 Waves and order
- **W0 (lead):** set the base (U33's close head); prove the sets disjoint; open `S/u34/relay.md` with sections `## A`, `## N`, `## T`, `## C`.
- **W1:** A1, N1, T1 and C1 in parallel.
  - <UDPHDR> is N1's first commit: src/asy_udp_socket.py:1-3 only, relayed as `<UDPHDR> <hash>` under `## N`.
  - It is the only commit any other lane needs. A2's attribution test checks that header (M.TSC.139 Change).
- **W2:** A2 (merges <UDPHDR> first), N2 and T2.
  - T2's BACKLOG text names C's and A's changes from the rulings, not from their commits, so it has no merge dependency.
- **W3 (lead):**
  - merge A, N, T and C (disjoint);
  - re-record the twin record;
  - run the whole tests_scripts tier once through S/u29/tier.sh, never beside another tier;
  - run the full gate at both GC stages, the twin CI per device, the web tier and coverage;
  - push and watch CI. CI's first run is the one Playwright cache miss OF-208's row expects: "the browser re-installed once".

### P2.4 Rulings draft (agent, 2026-10-21)
- **R-1 The cut as in P2.2.** Process.
- **R-2 (a) The explicit-Any sweep.**
  - Baselines: main pass 15 modules (pyproject:420-436), twin 2 (digital_twin/typecheck.ini:32-40), host 4 (host_typecheck.ini:43-55). None of the 21 is in U34's 28 files.
  - What the step text requires of U34 (A.U34.11 (1)): run typecheck.sh, remove the emptied entries with their comment, and, for every module still listed, list its sites in the landing note and send it to the OR2.c review, "not removed silently".
  - So U34 does not clear other units' files. It trial-removes the 8 zero-`Any` entries (5 main, 3 host). It keeps every removal the three passes and the three single-file runs accept; an entry that still shows a finding stays and is listed.
  - The 13 modules that still hold `Any` go by the routing rule (grep counts are P1's):
    - **U35:** _sensortask_scenarios 79, test_asy_uart_comm 26, test_asy_uart_driver 23, _bus_hazard_catalog 21, tests/machine.py 9, test_bus_hazard_generated 8 (no later holder; test file), src/asy_system_service.py 7 (U35's bare-name entry; typing only), test_bus_hazard_multi_device 5, digital_twin/machine.py 5, test_digital_twin_bus_hazard_concurrency 5, test_cross_browser_smoke_probe 8 (no later holder; test file).
    - **U36:** _boot_contiguity_probe 3, _uart_link_contract 2.
    - **U37:** none.
  - So OR81.a's "the flag is on and all passes clean before B5" (PROJECT_AUDIT_PLAN.md:433; B5 is U37, :600) holds if U35 and U36 clear their modules.
  - Process point for the lead's routing rows: each row carries the module's own pyproject.toml lines (its ANN401 entry and its baseline line) or its ini section, to be removed in the clearing commit. Otherwise test_ruff_exemptions_live.py:123 fails on the stale ANN401 entry.
  - Settled by A.U34.11 (1), the routing rule and OR81.a.
- **R-3 Step 30's U34 form.** Each pass's exempted set must be a subset of a named residual set: the 13 modules above, split by pass. A new exemption then fails, and leaving the baseline needs no edit to the test. The "nothing sets false" form lands when the residual set is empty: U37, which holds the test (A.U37.02).
  - Settled by M.TSC.109's own Change "(a new per-module exemption fails)" and by SPEC:2664-2666 ("only shrinks and which … pins"). Today that sentence is unpinned: the test checks only existence (:56-60).
- **R-4 (b) Step 28.** mypy_path stays as it is, and so does the :21-22 comment: the packet's "the scripts' sibling modules" clause would be false. The `scripts` sections leave by R-2. Settled by find_sources.py:185-187 and host_typecheck.ini:24-27.
  - The two bare imports go to the next holder: _hardware_verdict.py:20-22, :73, :131 to U37 (no later holder; not a test file), and runner.py:18 to C (work_order.json). The fix shape is the one in _digital_twin_ci_suite.py:31, :36: a repo-root path entry plus `from scripts._summary_block import`.
  - Conservative: no config change.
- **R-5 (c) Step 2's word order.** Keep "`ext/microdot.py`, pinned `v2.7.0`" (test_vendored_microdot.py:21, :40-43). After it, add the three stub file names, "(type-checking only, never frozen)" and "on 2026-10-06" (CLAUDE.md:124). Settled by the test.
- **R-6 (f) The legacy Microdot text is fixed now.** THIRD_PARTY:19 becomes "upstream commit `482ab6d`, an untagged snapshot four commits after `v2.0.6`, before `v2.0.7`".
  - Sources: CLAUDE.md:119-121, and `git describe` of S/corpus/microdot-new, which gives v2.0.6-4-g482ab6d.
  - Step 2 rewrites this same entry, and the stale-doc agreement plus PQ1 ("factual doc drift fixed in place") apply.
  - The lead records U36's stage for this sentence as done.
- **R-7 (d) Remove `write_and_recvfrom()` and its `tries` guard** (asy_udp_socket.py:175, guard :186-189).
  - Settled by the carry at REGISTER.md:726 (agent, 2026-10-20) and by the callers' code (P2.1).
  - In the tests:
    - delete :276-354, :1899-1912 and :1998-2010;
    - rewrite the three NTP-pattern tests onto `write()` and `recvfrom()` in the shape asy_ntp_client.py:261-264 uses;
    - reword the comments at :454, :1408-1412 and :1913.
  - SPEC:6253-6254 drops "(and so `write_and_recvfrom()`)". THIRD_PARTY:189-198 drops the paired-method comparison.
  - The test file is taken in because the method and its tests must land in one commit (precedent: U32's R-20). Keep :1364 and :1831.
- **R-8 (e) OF-208.**
  - The four Playwright keys gain `${{ steps.ident.outputs.id }}`.
  - Each of the four jobs (:153, :212, :273, :353) gets the identity step from action.yml:18-21, its text identical.
  - The pin in test_ci_workflow.py: every key on `~/.cache/ms-playwright` names the identity, and every identity run line equals the action's.
  - The Firefox key stays (P2.1). Conservative: one more cache download per change to `ImageOS` or the compiler/glibc versions.
  - test_ci_workflow.py is taken in as the fix's own test. CLAUDE.md's workflow puts tests first, and no later unit holds the file.
- **R-9 OF-96 closes with no edit**, citing tests_scripts/test_vendored_freezefs.py:9-31 (U0, 8104062).
- **R-10 test_vendored_freezefs** gains a check that THIRD_PARTY names `UPSTREAM_COMMIT` (:10), the same pattern as test_vendored_microdot.py:40-43. Consistency fix ('Change, don't flag', owner, 2026-09-25).
- **R-11 Captive DNS:** 2019, p-doyle, no NOTICE file (S/u34/upstream_captive.md).
  - LICENSE-captive_dns:201 keeps its year and gets no append.
  - The header is `Apache-2.0 AND MIT`, with Apache-2.0 scoped to DNSQuery (FOLD_ANSWERS.md:250).
  - Steps 10-12 no longer need upstream.
- **R-12 Step 29 is check-only.** U33's R-3 holds while owner question 6 is open (BACKLOG:1296-1302).
- **R-13 Step 23:** the six ANN401 entries (pyproject:261-276) and their category comments stay while they fire. They leave with their files under R-2.
- **R-14 `disallow_any_unimported` (A.U34.11 (4)).**
  - T2 measures it per pass and puts the count and sites in the landing note. The lead writes the OR2.c register row, and U34's close report names the count.
  - OR81.a's owner question ("what remains") is entered by U37, where the sweep ends, because the U35/U36 edits may clear more of it.
  - Conservative: no question is asked on a count that will still change.
- **R-15 Step 24.** A BACKLOG paragraph after U33's last one, with no audit IDs (test_citations). It names:
  - the CPY001 comment;
  - the removed baseline entries and sections (lint and typecheck legs);
  - the subset guard and the new attribution test;
  - test_vendored_freezefs.py, never listed so far ("no leg affected", A.U34.08);
  - ci.yml (CI only, no chroot leg).
- **R-16 Step 15:** the K.9 bullet is found by its text "(SPDX header + attribution, matching the file's existing entries)". K.5.1 is U36's.
- **R-17 Step 9:** only SPEC "freezefs 2.4, unmodified" becomes "freezefs `main` at `26be9e3`, unmodified". The other A.1 drifts stay in U36's stage 4: a sentence U34 does not rewrite (unlike R-6).
- **R-18 Steps 1 and 34** use M.DOCS.001/060's "post-audit only" wording (BACKLOG:514). The README map stays U36's.
- **R-19 Step 33b** writes "(agent, 2026-09-30; owner-reviewed, 2026-10-02)". Settled by FOLD_BRIEF.md:32-34 and FOLD_ANSWERS.md:249-251.
- **R-20 Every new THIRD_PARTY sentence with decision vocabulary carries its actor or source.** That file is scanned with no allow-list row (`_LICENCE_FILE`). No text anywhere carries an audit ID or "Step N" (test_citations).
- **R-21 No # @tunable, error_catalog, UART changelog or allowlist change.** If a lane orphans an allowlist row, it relays that to the lead.
- **R-22 Hardware: none.** H25 and H73 landed through U26 and U28.
- **R-23 Check-only steps** are verified at the base and again at the gate. A red there is a regression, routed by the rule.
- **R-24 The work order's `src/captive_dns.py`** is the old name of `src/asy_captive_dns.py`. The lead notes it.
- **R-25 For the owner: none.**
- Every P1 "conflicts" row is ruled: step 2 by R-5, step 28 by R-4, step 29 by R-12.

### P2.5 Risks
- **By mode:**
  - STA: NTP and DNS keep their own `write()`/`recvfrom()` calls, unchanged.
  - AP: the captive DNS uses `recvfrom()`/`sendto()`, unchanged.
  - Silent and Off: no UDP traffic. USB: nothing changes.
  - The only firmware change is a method with no caller. The licence and header texts change no behaviour.
- **UART:** the wire format is untouched, and there is no changelog row.
- **Memory gates:** N's four unit files plus twin[dev] at both stages, and the lead's full gate: zero MemoryError and zero "memory allocation failed". Nothing is fixed by `gc.collect()`, a threshold or `-X heapsize`. The removal allocates nothing.
- **Frozen image:** only asy_udp_socket.mpy changes (it shrinks).
  - The five header files have to stay at exactly three lines. A fourth line would shift the bytecode line tables.
  - A proves it with mpy-cross for its four files, and N does the same for the header commit.
- **Timing:** test_asy_udp_socket shrinks. The new and changed tests_scripts files each stay under about 2 s.
  - The doc checks read about 40 more lines.
  - A growth over 10 % and 0.5 s, or over 10 s, is made efficient, never by cutting strictness.

### P2.8 Blocks (60-80 calls; no file split across two blocks of one lane; each lane's last block runs its complete checks)
- **A1 (about 65-75 calls):** THIRD_PARTY_LICENSES.md only, steps in packet order. Checks: decision_vocabulary, citations, legacy_paths, vendored_microdot (including the R-5 plant).
- **A2 (about 60-75):**
  - files: LICENSE-captive_dns, the four headers, the new attribution test (seen failing first), the freezefs check, README;
  - merge <UDPHDR> first;
  - then: the mpy-cross compare and A's readers (all of them).
- **N1 (about 55-70):** <UDPHDR> first; then the test file (R-7), then the method removal; the four unit files at both stages; the main mypy pass.
- **N2 (about 40-55):** SPECIFICATION.md. Then N's complete checks: lint; the main pass; the four unit files plus twin[dev] at both stages on the head; SPEC readers; repo scans.
- **T1 (about 55-70):** pyproject.toml, both inis and the test (R-2, R-3, R-4, R-13); one full typecheck.sh run after the removals; the residual site list with path:line.
- **T2 (about 40-55):** the R-14 measurement (three runs); BACKLOG.md (R-15); then T's complete checks: lint.sh, typecheck.sh, T's readers, repo scans.
- **C1 (about 30-45):** the pin first, then ci.yml; lint.sh; C's readers.
- Commits are named `U34 lane <L>: <summary>`, one per step group. Branches are `audit/u34-{a,n,t,c}` in S/wt-u34{a,n,t,c}, built with S/u23/rebuild.sh.

### Base-time shards (on U33's close head; seconds are earlier units' figures or estimates, for balance only)
- **A (about 27 s):** tests/test_asy_udp_socket.py@-1 (7.2), tests_scripts/test_citations.py (13.3), test_ci_workflow (est. 2), test_vendored_freezefs (est. 0.5), test_vendored_microdot (est. 0.5), test_mypy_any_baseline (est. 1), test_lint_type_scopes (est. 2).
- **B (about 25 s):** tests/test_asy_udp_socket.py@32768 (7.2), test_decision_vocabulary (8.8), test_legacy_paths (est. 5), test_comment_block_cap (4.4).
- **C (about 24 s):** test_ruff_exemptions_live (est. 20), test_typecheck_sh (est. 3), test_third_party_attribution (new; measured after only, est. 1).
- No per-device rows.

### Not determinable read-only
- Whether each of the 8 zero-`Any` entries really holds no finding (T1's run settles it).
- The `disallow_any_unimported` counts (T2).
- How long typecheck.sh and test_ruff_exemptions_live take.
- Whether the new THIRD_PARTY text passes test_decision_vocabulary (A1).
- Whether mpy-cross output is unchanged for the header files (A2, N1).

## LEAD NOTES (lead, 2026-10-21)
1. Base: `147ea3f`, U33's integration head (U32's final tree `c6b8a07` plus U33's documents). Its BACKLOG.md,
   CLAUDE.md, SPECIFICATION.md and tests_hardware/README.md text is U33's final text, so lanes edit those files on top
   of it. U32's squash adds only `tests/test_asy_neopixel_driver.py`, `tests_js/` test files and audit records; U33's
   squash adds audit records: none is a U34 file. The lead merges U33's squash into `audit/u34-int` before the close;
   lanes never merge it.
2. P2's rulings R-1 to R-25 stand. R-7 is the register's carry (REGISTER.md:726, agent, 2026-10-20): the method and its
   tests leave in one commit; the lead re-records the twin record at the close. R-8: the first CI run after U34's push
   downloads the Playwright browser once, as OF-208's row expects.
3. R-2: a baseline entry leaves only when all three passes and the three single-file runs accept its removal. T1's
   hand-back lists every remaining module with its explicit-`Any` sites (path:line) and its config lines; the lead
   writes the routing rows (U35 or U36) from it.
4. Paired times: `S/wt-u33plan` is detached at `147ea3f` and rebuilt: it is U34's base worktree. Every file a lane grows
   or changes is timed base and head back to back in one run, alternating, so both see the same load. No base sweep.
5. The whole `tests_scripts` tier is the lead's, once, on `audit/u34-int` (U33 B3's precedent: the integration head
   holds exactly the lanes' changes). A lane's final block runs its readers, the 17 repo-wide scans and its own files'
   runs, not the tier.
6. The host is shared: U32's gate (one twin and the coverage leg), U33's tier, FX8 and FX9 run beside W1. Every
   wall-time-bound run obeys CHECKLIST 12 (at most 4 heavy processes on the host when it starts).
7. Nothing in `ext/` changes in U34 (steps 5 and 6 landed). mpy-cross for the byte compares: the pinned build under
   `/root/pico-toolchain` (run it, never write into that tree); output goes under `S/u34/lane<L>/`.
