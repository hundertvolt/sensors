# U34 plan, block P1 (agent, 2026-10-21; read-only at c6b8a07)

I used about 47 tool calls and covered all 37 steps (42 M.IDs), both open findings and the one REGISTER carry. Line numbers are at `c6b8a07` in `S/wt-u33plan`. My helper scripts are in `S/u34/plan_scratch/` (wo.py, wo2.py, wo3.py, hostnames.py).

## 1. Counts and step table
The work order (`audit/order/work_order.json`, unit U34) has 42 steps (29 explicit, 13 implicit), 19 actions and 28 files. Its hardware rounds are `{"R1": ["H25","H73"], "R3": ["H73"]}`. **None of U34's own edits needs the bench.** H25 and H73 come in only through carried actions A.U26.66 and A.U28.35, and those already landed in U26 and U28.

**[FW]** marks a `src/` edit. Header rewrites keep 3 lines → 3 lines and are comments only: mpy-cross drops comments and the line numbers stay the same, so the frozen image does not change.

| # | M.ID | files | verdict | evidence at c6b8a07 |
|---|---|---|---|---|
| 1 | DOCS.001 | THIRD_PARTY_LICENSES.md | to write | :3-7 still says "MIT overall with that one documented exception". The names it needs already exist: `UDPSocket` src/asy_udp_socket.py:38, `CaptiveDNS`/`DNSQuery` src/asy_captive_dns.py:52/:157. Use M.DOCS.001's "post-audit only" form, as SPEC:40-42 has it, not A.U34.01's "until the C side is reconciled". |
| 2 | DOCS.002 | THIRD_PARTY | part landed + conflicts | Landed at :15-22: tag `v2.7.0`, the test pointer, and the `ext/typings/microdot/` stubs. Left: name the three stub files and add "(type-checking only, never frozen)" and "on 2026-10-06" (the date CLAUDE.md:124 records). :19 "between `v2.0.1` and `v2.1.0`" is wrong: `git describe 482ab6d` in S/corpus/microdot-new gives `v2.0.6-4-g482ab6d`, which is before v2.0.7. That is U36's stage in the packet; it is the same sentence, and I suggest fixing it now. **Conflict:** test_vendored_microdot.py:21 and :40-43 need the literal "`ext/microdot.py`, pinned `vX.Y.Z`". The packet's wording ("`ext/microdot.py` and upstream's type stubs …, pinned `<tag>`") breaks that. Keep the tree's word order and add the stub names after it. |
| 3 | DOCS.003 | THIRD_PARTY | to write | :23-25 is the old wording. All five ext/freezefs sha256 values equal A.U34.08 (4)'s, and test_vendored_freezefs.py:10 gives `26be9e339a25…` (2025-10-25). The holders the entry quotes are in the tree: ext/freezefs/LICENSE:3 "Copyright (c) 2022 bixb922", and line 1 of archive.py, ffsextract.py and ffsmount.py "(c) 2023 Hermann Paul von Borries". Comment stripping is at archive.py:165-167, inside the :150-175 the entry cites. No fetch is needed. |
| 4a | DOCS.004 | THIRD_PARTY | to write | :29-31 still has "the one non-Adafruit file below" (:31). |
| 4b | DOCS.005 | THIRD_PARTY | to write | The first ISL entry (:36-41) is deleted. The second (:48-55) is rewritten; it still says "FRAM-persisted gain-ratio self-calibration" (:54-55). |
| 4c | DOCS.007 | THIRD_PARTY | to write | :78-81 still has "its own module docstring" and "this attribution predates…". The header itself is a `#` comment: src/asy_dns_client.py:1-3. |
| 4d | DOCS.009 | THIRD_PARTY | to write | Section :109-123; :120-123 is the "used to be listed" paragraph. All 20 legacy files the text names exist. Headers: SPDX present in legacy bmp3xx, scd30, sgp40 (both files), isl29125, mprls, shtc3, captive_dns and asy_udp_socket; absent in legacy asy_fram_driver, CommonDrivers/microdot, async_connect and all eight legacy/dev_drivers copies. This matches A.U34.10. |
| 5 | GEN.051 | ext/microdot.py, ext/LICENSE-microdot | landed | v2.7.0, with hashes at test_vendored_microdot.py:14-15. Whether a newer upstream tag exists is the dependency-refresh bullet's job, not this step's. |
| 6 | GEN.050 | ext/typings/microdot/*.pyi | landed | The three files are pinned at test_vendored_microdot.py:16-18. `ext/typings` is on mypy_path (pyproject.toml:367). No `microdot` import ignore remains (grep). |
| 7 | SCR.066 | scripts/build_firmware.py | landed (check-only) | build_firmware.py:44-62, :77-78, :94-105, :109-111 and :122 (sorted list). Only named modules are staged, so `ext/typings` is never frozen. |
| 8 | SCR.072 | scripts/build_frozen_html.sh | landed | Header :2-4, help :7-18, :29-32, :42-51, the 254 check :53-61, pinned clock and sorted walk :66-76. The old `:30` comment now has no "2.4", so A.U34.08 (3) is already met. |
| 9 | SPEC.005 | SPECIFICATION.md | part landed | U34's stage is one line: SPEC:61 "freezefs 2.4, unmodified" → "freezefs `main` at `26be9e3`, unmodified". Stages 1-2 landed (:37-50, :59-60, :80-82). Stage 4 belongs to U36: :35 datasheets (now stale: .gitmodules:1-3), :51 "(Part D)", :56-57 improved-quality, :62 "variant", :85. Small difference: :60 says "upstream v2.7.0 type stubs for it, unmodified (A.5)", where the packet has "…never frozen (B.15)". That is U0's stage; leave it for U36. |
| 10 | SRC_NET.005 | src/LICENSE-captive_dns | part landed, **needs upstream** | :1-3 paths and names landed. Left: :201 "Copyright 2019 p-doyle (Micropython-DNSServer-Captive-Portal contributors)", which needs the sourced year; and a NOTICE append at the end (:213), if upstream has a NOTICE file. |
| 11 | SRC_NET.002 | src/asy_captive_dns.py **[FW]** | to write, **needs upstream** | :1-3 header; :2 still scopes `Apache-2.0` to the whole file. The year is sourced from upstream, or dropped. |
| 12 | DOCS.010 | THIRD_PARTY | part landed, **needs upstream** | Landed: paths and names at :130-131, :138, :148, :201, and the §4(b) list at :147-152. Left: the SPDX scope sentence with holder, year and NOTICE, after :135-139. |
| 13 | SRC_NET.025 | src/asy_udp_socket.py **[FW]** | part landed | The docstring (:5-8) no longer has the context-manager clause. Left: header :1-3 (the discussion link). |
| 14 | DOCS.013 | THIRD_PARTY | part landed | Landed: :192-193 `UDPSocket` and its paths; :197 "locking, input validation"; :201 `asy_captive_dns.py`. Left: :208-210 → A.U34.06 (2). See REGISTER U30 below: :189-198 changes if `write_and_recvfrom()` goes. |
| 15 | SPEC.142 | SPECIFICATION.md | to write (stage 6), **after U33** | K.9 is at SPEC:9989. The bullet to rewrite is :10003-10004, "(SPDX header + attribution, matching the file's existing entries)". U33's new B.16 (after :2745-2746) moves these lines. K.5.1 is U36's: C.11.1 is still at :4186. A.U25.67 and A.U26.66 landed: tests_scripts/test_twin_fake_catalog.py, tests_hardware/conformance.py, flash/test_chip_conformance.py. |
| 16 | SRC_CORE.100 | src/asy_fram_driver.py **[FW]** | part landed | The docstring (:5-6) and the :8-10 comment are already the end state. Left: header :1-3 (the pointer line sits before the licence line). |
| 17 | SRC_SENS.014 | src/voc_algorithm.py | landed | The docstring at :5-7 landed (U12 2949ed9). U30 (06a8ae5) changed the last clause to "…the state codec answers False for what struct refuses". Keep the tree's text. |
| 18 | SRC_SENS.038 | src/asy_bmp3xx_driver.py **[FW]** | part landed | :6 `BMP3XX_Reader` and :7 sources landed. Left: header :1-3. |
| 19 | SRC_SENS.070 | src/asy_isl29125_driver.py **[FW]** | part landed | Imports :10-33 landed; the tree also has `CfgValue` under TYPE_CHECKING (:31). The only quoted annotations left name TYPE_CHECKING symbols (grep). Left: header :1-3. |
| 20 | TEST_UNIT.331 | tests/voc_reference_vectors.py | landed | :1-3 header names gas-index-algorithm 2ef9f13 and embedded-sgp e9ecd60 (U12). |
| 21 | TOOL.020 | .github/workflows/ci.yml | landed (check-only) | Action pins are in the table below. Local `./` uses stay: actionlint-py is 1.7.12.25 (pyproject:34) and .github/zizmor.yml keeps `self-repository: disable`. No `submodules:` key. OF-208 joins this file. |
| 22 | TOOL.028 | pyproject.toml | part landed | `ignore` (:69-150) is in U28 form; U33's row 29 checked it and E722 is not listed. Left: the CPY001 comment at :147-148, "carry SPDX headers" → "carry an attribution header (SPDX where a license is named)". U33 writes no pyproject change. Its CLAUDE.md E722 bullet text (A.U33.06, CLAUDE.md:902-905) does not affect this step. |
| 23 | TOOL.030 | pyproject.toml | part landed | The per-file block :180-353 is restructured. Left for U34: six `ANN401` entries and their category comments, :261-264, :267-271, :272-276 (tests/machine.py, digital_twin/machine.py, test_asy_uart_comm.py, test_asy_uart_driver.py, _bus_hazard_catalog.py, _sensortask_scenarios.py). They are still live, because those files still hold `Any`. They go only once the explicit-Any sweep clears them (see step 27). |
| 24 | DOCS.066 | BACKLOG.md | to write, **after U33** | The list is :518-975. U33 adds A.U33.04's paragraph after :609-612 and R-18's four files. U34 adds its own paragraph after the last one (:971-975, 2026-10-21), before :976. Contents: pyproject (CPY001 comment, ANN401 and baseline removal), the two ini baselines, ci.yml if OF-208 lands, the new L0 test. The list never named `test_vendored_freezefs.py` (U0, 8104062), which fits A.U34.08's "new L0 freezefs hash test — no leg affected". |
| 25 | SCR.026 | scripts/typecheck.sh | landed | Header :2-4, help :6-18, venv/python/summary :20-28, stage and trap :30-45, `exit 0` :197. The usage wording was later changed to "CI passes none". |
| 26 | SCR.028 | scripts/typecheck.sh | landed | :159-163 (`--no-sync`) and the passes :180-192, plus a later bench-conftest check at :190. |
| 27 | TOOL.033 | pyproject.toml | part landed | The decorator override is gone (no `disallow_untyped_decorators` left), and the `frozen_html` block is in place (:411-415). Left: the baseline :417-437 still exempts **15 modules**. Explicit `Any` counts by grep: `_sensortask_scenarios` 79, `test_asy_uart_comm` 26, `test_asy_uart_driver` 23, `_bus_hazard_catalog` 21, tests/machine.py 9, `test_bus_hazard_generated` 8, src/asy_system_service.py 7 **[FW, typing only]** (:229-230, :297, :480, :744), `test_bus_hazard_multi_device` 5, `_boot_contiguity_probe` 3, `_uart_link_contract` 2, and five device scripts with 0 (probably stale entries). |
| 28 | TOOL.079 | host_typecheck.ini | part landed + **conflicts** | `enable_error_code` (:36-37), the flag (:38) and the conftest comment (:14-15) landed. Left: baseline :43-55 (`conftest` 0 `Any`, `http_client` 0, `scripts._hardware_verdict` 1, `test_cross_browser_smoke_probe` 8). **Conflict:** the step adds `scripts` to mypy_path (:27). The tree instead imports `scripts.` package-qualified: scripts/_digital_twin_ci_suite.py:35-37, tests_hardware/twin_board.py:17, tests_scripts/test_twin_board.py:21 and 5 more. With `explicit_package_bases`, a nearer `scripts` base would rename `scripts/_twin_process.py` to `_twin_process`. **Conservative option (agent, 2026-10-21):** keep mypy_path as it is, and change scripts/_hardware_verdict.py:22 to `from scripts._summary_block import …`, the form its siblings use; its ignores at :22 and :73 then go. That file is not in U34's list. |
| 29 | TSC.065 | tests_scripts/test_comment_block_cap.py | check-only, **after U33** | U33's R-3: `_WRAP_WIDTH = None` stays until owner question 6 is answered, and the "(owner-reviewed, 2026-10-02)" tag is not written. The A.U34.07 headers are 3 lines each. |
| 30 | TSC.109 | tests_scripts/test_mypy_any_baseline.py | to write | The test is still in U8 form (:50-60). Adding "nothing sets the flag false" fails until all three baselines are empty. |
| 31 | TSC.139 | tests_scripts/test_third_party_attribution.py (new) | to write | The file does not exist. It depends on steps 11, 13, 16, 18 and 19. The six correct headers already pass it: sgp40, scd30, ntp_client, dns_client, voc_algorithm, and captive_dns line 3. |
| 32 | TSC.153 | tests_scripts/test_vendored_freezefs.py | landed (U0 8104062) | The pin is at :9-17. Optional, for consistency with test_vendored_microdot.py:40-43: a check that THIRD_PARTY_LICENSES.md names `UPSTREAM_COMMIT` once step 3 writes it. |
| 33a | DOCS.008 | THIRD_PARTY | to write | The VOC entry :95-107 still says "MIT terms are the operative ones" with no actor. Use the "(agent, 2026-08-20; not a verified legal conclusion)" form. |
| 33b | DOCS.011 | THIRD_PARTY | to write | Goes before :161. The upstream files are local: /root/pico-toolchain/micropython is at v1.29.0, and its seven submodule commits equal A.U34.09's. The rest also checks out: mbedTLS is dual Apache-2.0 OR GPL-2.0-or-later with no NOTICE file; the board manifests and mpconfigboard.cmake:5-17 match; mpconfigport.h:216-217 is as stated; cyw43 LICENSE.RP and LICENSE:12 match. CI uploads coverage and logs only (ci.yml:347, :604-668); package.json has devDependencies only. |
| 33c | DOCS.014 | THIRD_PARTY | to write | New section at the end. Its precondition holds: the datasheets submodule is at .gitmodules:1-3. |
| 34 | DOCS.060 | README.md | to write (U34 stage) | Licence bullet at README:931-935, with the "source couldn't be established" claim. Use M.DOCS.060's "post-audit only" wording. The map rewrite (:847-) is U36's. A.U32.01 landed (README:440). |
| 35 | SPEC.098 | SPECIFICATION.md | landed | SPEC:6427-6447: the successor, the 2ef9f13/e9ecd60 vectors, and the last sentence verbatim. |
| 36 | TSC.154 | tests_scripts/test_vendored_microdot.py | landed | :13-19, :28-31. |
| 37 | TWIN.075 | digital_twin/typecheck.ini | part landed | :1-10 (3+2+3 lines), :12, :17, :27-28 and :33 landed. Left: baseline :32-40 (`machine`, digital_twin/machine.py with 5 `Any`; `test_digital_twin_bus_hazard_concurrency` with 5). |

**Totals (42 M.IDs):**
- Landed: 12 (5, 6, 7, 8, 17, 20, 21, 25, 26, 32, 35, 36).
- Part landed: 14 (2, 9, 10, 12, 13, 14, 16, 18, 19, 22, 23, 27, 28, 37).
- To write: 15 (1, 3, 4a-d, 11, 15, 24, 30, 31, 33a-c, 34).
- Check-only: 1 (29).
- Overlays: after U33 on 15, 24 and 29; needs upstream on 10, 11 and 12; conflicts on 2 (test regex), 28 (`scripts` base) and 29 (U33's R-3).
- Hardware: none.

**Where the 19 carried actions land:**
- A.U34.01 → step 1.
- A.U10.37 and A.U10.38 → step 1 (names already in the tree).
- A.U34.12 → steps 2, 5-9 and 36.
- A.U34.08 → steps 3, 8, 9, 24 and 32.
- A.U34.03 → step 4a-c; A.U34.10 → step 4d.
- A.U34.09 → steps 7, 21, 33b and 33c.
- A.U28.35 → step 9 (landed: .gitmodules).
- A.U8.23 → step 9 (landed: pyproject:367).
- A.U34.05 → steps 10-12; A.U34.06 → steps 13-14.
- A.U25.67 and A.U26.66 → step 15 (code landed; K.5/K.5.1 is U36's).
- A.U34.07 → steps 15-19, 22, 29 and 31.
- A.U34.04 → steps 17, 20, 33a and 35.
- A.U34.11 → steps 23-28, 30 and 37.
- A.U32.01 → step 34 (landed); A.U34.02 → step 34.

**Pinned versions, tree today against the step text:**

| Item | Tree today | Step text |
|---|---|---|
| Microdot | `v2.7.0` (THIRD_PARTY:16, SPEC:59, test :14) | "the tag B0 leaves (`v2.6.2` if held)" — B0 left v2.7.0 |
| Microdot stubs | three files at v2.7.0 (test :16-18) | the same tag as the module |
| Legacy Microdot copy | `482ab6d` (CLAUDE.md; THIRD_PARTY:19 states it wrongly) | `482ab6d` |
| freezefs | `26be9e3` (test only; THIRD_PARTY says "main … 2026-09-10"; SPEC:61 says "2.4") | `26be9e3` |
| GitHub actions | checkout@v7 ×16, setup-node@v7 ×8, cache@v6 ×6, upload-artifact@v7 ×6, dorny/paths-filter@ceb8a2b (v4.0.3) | "the newest major" |
| ruff / mypy | 0.16.10 / 2.4.0 (pyproject:24, :23) | "the refreshed ruff", no number |
| Stubs package | board 1.29.0.post1, stdlib 1.29.0.post2 (versions.toml:16-17) | — |
| MicroPython | v1.29.0 (versions.toml:10) | v1.29.0 |
| actionlint-py / zizmor | 1.7.12.25 / 1.30.1 | `$/` uses only if actionlint accepts them |

**Needs upstream (one fetch for the lead):** `github.com/p-doyle/Micropython-DNSServer-Captive-Portal`, default branch. From it: the first commit of `main.py` (year and SHA, from `git log --reverse -- main.py`), whether a `NOTICE` file exists, and `LICENSE`. If it cannot be reached, the year is dropped in all three places and the failure goes on the OR4.a egress list. Nothing else needs fetching; local copies:
- Microdot: S/corpus/microdot-new at 7742db9 (v2.7.0).
- freezefs: S/pass4/F/ffs/freezefs at 26be9e3.
- gas-index-algorithm: S/corpus/gas-index-algorithm.
- MicroPython: /root/pico-toolchain/micropython at v1.29.0.

## 2. Open findings and carries
- **OF-96** (no freezefs hash pin). Closed by the tree: tests_scripts/test_vendored_freezefs.py:1-31 (U0, 8104062). It joins step 32; close it with that citation.
- **OF-208** (Playwright cache key has no runner-image identity). Open. The row cites ci.yml:175; the key is now at ci.yml:183 and also :244, :297 and :383 (four jobs, the first `web-unit-tests` at :153). Fix: an identity step like .github/actions/setup-micropython-toolchain/action.yml:19-21 (ImageOS, gcc, ldd) before each cache, with its output added to each key. It is its own step, in the same file as step 21. Optionally pin the form in tests_scripts/test_ci_workflow.py (Playwright checks at :284; not in U34's file list). The remaining `actions/cache` site gets checked for the same class.
- **REGISTER U30 carry** (REGISTER.md:726): `UDPSocket.write_and_recvfrom()` (src/asy_udp_socket.py:175, the `tries` guard at :187-188) has no caller in `src/`; its only callers are tests. **[FW, real bytecode change]** Removing it touches:
  - THIRD_PARTY:189-198 (the comparison sentence, joins step 14).
  - SPEC:6254 (mentions the method).
  - tests/test_asy_udp_socket.py:276-354, :454, :1410-1505, :1899-1913 and :1998-2010. This file is not in U34's list, and the NTP-shaped exchange tests at :1410-1505 would need rewriting onto `write()`/`recvfrom()`.
  - It is its own step; P2 rules on scope.

## 3. Packet vs code
**Moved sites (packet line → now):**
- THIRD_PARTY:

  | Packet | Now |
  |---|---|
  | :15-20 | :15-22 |
  | :21-23 | :23-25 |
  | :27-29 | :27-31 |
  | :34-39 | :36-41 |
  | :46-53 | :48-55 |
  | :76-79 | :78-81 |
  | :93-105 | :95-107 |
  | :107-121 | :109-123 |
  | :128-148 | :130-152 |
  | :157 | :161 |
  | :175-205 | :179-210 |
  | :188 | :192-193 |
  | :203-205 | :208-210 |

- SPEC: A.1 :33-92 → :34-93 (:63 → :61); K.9 :5937-5938 → :10003-10004; F.4 :3669-3676 → :6420-6447; C.11.1 :2348 → :4186.
- pyproject: ignore :53-195 → :58-150; CPY001 :192-193 → :147-148; per-file :214-351 → :180-353; overrides :408-413 → :411-437; mypy_path :365 → :367.
- README: :723-726 → :931-935; map :641 → :847. BACKLOG chroot list :515-613 → :518-975.
- typecheck.sh: :1-14 → :1-45; :99-130 → :159-197.
- The inis: host :1-36 → :1-55; twin :1-28 → :1-40.
- build_firmware.py: :39-108 → :44-123. build_frozen_html.sh: :30 → :66.

**Names:** the work order's file list still names `src/captive_dns.py`, which is now `src/asy_captive_dns.py`. The renames `AsyUDPSocket` → `UDPSocket` and `DNSServer` → `CaptiveDNS` landed in U10.

**Done by U0-U32:**
- U0: the Microdot re-vendor, the stubs and the freezefs pin.
- U8 and U19: the stub hash table.
- U12: the VOC vectors and F.4.
- U12, U15, U16, U18 and U30: the docstring halves of five headers.
- U20: the `frozen_html` override.
- U25 and U26: the twin catalog and the conformance probes.
- U27: the staging, the frozen site, typecheck.sh, `enable_error_code` and the decorator override's removal.
- U28: the datasheets submodule and the restructured lint scheme.
- U32: the reflash runbook.

**BACKLOG items touched:**
- Owner question 6, "Count a long comment line as several?" (BACKLOG.md:1296-1302): step 29.
- "Refactor targets not yet done", first bullet, "Mypy shall be configured to disallow `Any` types" (:21-30): steps 23, 27, 28, 30 and 37. Its "Deferred to a dedicated future session (project owner, 2026-09-11)" is overtaken by OR81.a (owner, 2026-09-28: "do it in this audit"; typing only, the frozen image behaves the same; PROJECT_AUDIT_PLAN.md:432-433). Rewriting that bullet is U36's job (A.U34.11's blast).
- The deferred chroot-list entry (:518-975): step 24.
- The deferred "`arduino/` and the C reconciliation are post-audit only" (:514): the wording source for steps 1 and 34.
- If A.U34.11 (4)'s `disallow_any_unimported` count is not zero, it becomes owner question 8 (CLAUDE.md decision rule 4).

**For P2 to rule:**
- (a) **The explicit-Any sweep is the bulk of U34's code.** 21 baseline modules remain in total: 15 main, 2 twin, 4 host. They include src/asy_system_service.py and test files outside the 28-file list. A.U34.11 (1) lists what is left for the OR2.c review, but OR81.a says every pass must be clean before B5.
- (b) The step 28 conflict and its conservative option.
- (c) Step 2's word order, so the test regex at test_vendored_microdot.py:21 still matches.
- (d) The scope of the `write_and_recvfrom()` removal.
- (e) The scope of OF-208's sweep (4 keys).
- (f) Whether U34 fixes the legacy Microdot commit text now, rather than in U36.

**Not determinable read-only:**
- Whether the baseline modules that show 0 `Any` still hold findings: the five device scripts, `http_client` and `conftest`. A typecheck run with each section removed settles it.
- The exact per-pass explicit-Any and `disallow_any_unimported` counts: needs a mypy run.
- p-doyle's year and NOTICE: needs the fetch above.
- Whether the new THIRD_PARTY text passes test_decision_vocabulary.py, which scans that file (`_LICENCE_FILE`, :29) and has no allowlist entry for it: an L0 run settles it.
- Whether newer upstream tags or action majors exist: the dependency refresh's job, not U34's.
- The source of the "owner-reviewed, 2026-10-02" tag that DOCS.011 carries: check it at landing, in the same spirit as U33's R-3.
