# U34 plan, block P2 (agent, 2026-10-21; read-only at c6b8a07)

I used about 55 tool calls. Line numbers are at `c6b8a07` in `S/wt-u33plan`. Lanes branch from U33's close head, so every BACKLOG and SPEC site is found by its quoted text, not its number. My helper scripts are in `S/u34/plan_scratch/`: p2_route.py, p2_files.py, p2_allow.py.

### P2.1 Findings that change the cut (beyond P1)
- **None of the 21 baseline modules is in U34's 28 files.** Only their config lines are (pyproject.toml, the two inis).
  - pyproject.toml is also held by U36 and U37. The two inis and test_mypy_any_baseline.py are held only by U37 (work_order.json).
  - U35's file list names `asy_system_service.py` by its bare name. U30 read such a bare name as the `src/` file (REGISTER.md:724).
- **Eight baseline modules hold no explicit `Any`** (grep):
  - the five device scripts (tests_hardware/device_scripts/{allocation_need_per_source, serving_at_default_gc, uart_crossover_exchange, uart_crossover_recovery, uart_driver_read_never_blocks_the_loop}.py);
  - tests_hardware/conftest.py, tests_hardware/http_client.py;
  - scripts/_hardware_verdict.py: its one grep hit is the :73 comment "Summary is Any to mypy".
  - Removing these eight entries is a config-only edit inside U34's own files.
- **The mypy-path conflict is real.** In mypy 2.4.0 (pyproject:23; installed copy at /home/user/sensors/.venv/.../mypy/find_sources.py:185-187), the crawl up from a file stops at the nearest explicit base. With `scripts` on mypy_path, scripts/_twin_process.py would get the name `_twin_process`. scripts/_digital_twin_ci_suite.py:37 imports it as `scripts._twin_process`, so one file would carry two module names.
  - Only two bare-sibling imports are left: scripts/_hardware_verdict.py:22 (its ignores are :22, :73, :131) and tests_hardware/manual/runner.py:18.
  - Neither file is in U34's list. build_firmware.py:36 already uses the package-qualified form.
- **Removing `write_and_recvfrom()` changes the frozen image.** Nothing in `src/` calls it:
  - the resolver uses `write()` then `recvfrom()` (asy_dns_client.py:167-171), and so does the NTP client (asy_ntp_client.py:261-264);
  - the captive DNS uses `recvfrom()` and `sendto()` (asy_captive_dns.py:92, :117).
  - Its tests are in tests/test_asy_udp_socket.py, which is outside the list (U35 and U36 hold it later). The removal and those tests must land in one commit.
  - The NTP-pattern section says its purpose is to "mirror each caller's documented, stable call shape" (:1408-1416). The callers no longer make this call, so the three tests (:1419, :1458, :1487) are now wrong models.
- **The attribution test (step 31) reads both THIRD_PARTY and the five headers**, including asy_udp_socket.py:1-3. That puts THIRD_PARTY and the headers with one owner, and the UDP header has to be published early.
- **The Firefox cache key (ci.yml:409-417) is a different case.** It is a conda-forge environment that brings its own libraries, and its monthly roll is a recorded decision (agent, 2026-09-30; ci.yml:409-411). Only the four Playwright keys (:183, :244, :297, :383) carry OF-208's flaw.
- **The "owner-reviewed, 2026-10-02" tag has a source.** FOLD_BRIEF.md:32-34 defines the tag form, and FOLD_ANSWERS.md:249-251 marks `licence-notices` (refs A.U34.04/.05/.09) status=ok. The same answer settles "Apache-2.0 AND MIT" scoped to DNSQuery.
- **Allowlist rows** (p2_allow.py): vocab :48 (SPEC:9991, K.9) and citation :69 (SPEC:56) sit near U34's edits but in no line it edits. Vocab :256-257 quote tests/test_asy_udp_socket.py:1364 and :1831, outside the removal ranges. All must stay intact; no allowlist change is expected.

### P2.2 The cut (one owner per file; four agents at most, four in W1)

**Lane A (attribution)**
- Files: THIRD_PARTY_LICENSES.md, README.md, src/LICENSE-captive_dns, src/asy_captive_dns.py, src/asy_fram_driver.py, src/asy_bmp3xx_driver.py, src/asy_isl29125_driver.py, tests_scripts/test_third_party_attribution.py (new), tests_scripts/test_vendored_freezefs.py.
- Steps written: 1, 2 (R-5, R-6), 3, 4a-d, 10, 11, 12 (R-11), 14 (with R-7's sentence), 16, 18, 19, 31, 32 (R-10), 33a-c (R-20), 34.
- Open findings: OF-96 closes (R-9).
- Size: about 60 lines added and 40 removed in THIRD_PARTY (two new sections), 5 in README, 4 headers at 3 lines each, a new test of about 100 lines, +6 in the freezefs test.
- Checks at -1/32768: none. The headers are comments only, kept at 3 lines so line numbers hold, and an mpy-cross byte compare of the four files at base and head proves no bytecode change. The lead's gate runs both stages.
- Readers:
  - THIRD_PARTY: test_decision_vocabulary, test_vendored_microdot, test_vendored_freezefs, the new test.
  - README: test_bench_restores_serving, citations, device_script_bench_facts, digital_twin_generated_boot, harness_mpremote_retry, legacy_paths, persistence_write_marker_completeness, setup_toolchain_env.
  - asy_captive_dns: buildgen_definitions, buildgen_validate, fault_or_warning_never_both, task_tops.
  - asy_fram_driver: buildgen_limits, device_tomls, lint_sh, lock_order.
  - bmp3xx and isl29125: buildgen_definitions, driver_registry, error_contract, limits, schema_ast, source_agreement, validate, web_tag, wiring, config_schemas, device_script_config_schemas, digital_twin_scenarios, import_graph, import_placement, memory_catalog, counter_steps, isl29125_copies, lint_ceilings.
  - Repo scans: test_comment_block_cap, test_no_variant_literals.
- Seen failing first:
  - the new test names asy_udp_socket.py's header until <UDPHDR> is merged;
  - it names the two ISL entries until 4b merges them;
  - a planted header with no entry is named;
  - the freezefs commit check fails until step 3's text lands;
  - planting the packet's step-2 word order makes test_vendored_microdot.py:40-43 fail, which proves R-5.
- Depends on: <UDPHDR>, merged before A2's green run.

**Lane N (UDP and SPEC)**
- Files: src/asy_udp_socket.py **[FW]**, tests/test_asy_udp_socket.py (taken in by R-7), SPECIFICATION.md.
- Steps written: 13 (the header, published first as <UDPHDR>), the REGISTER carry (R-7), 9 (R-17), 15 (R-16), SPEC:6253-6254.
- Size: about −22 lines in src; about −120 and +40 lines in the test file; 3 edits in SPEC.
- Checks at -1/32768: earlier units' figures for balance only; the base is still to measure.
  - test_asy_udp_socket 7.21/7.22 s (S/u31)
  - test_asy_dns_client 0.80/0.81 s (S/u30)
  - test_asy_ntp_client 23.6/24.9 s (S/u30)
  - test_asy_captive_dns 25.58/25.60 s (S/u30)
  - test_digital_twin_sensortask_integration[dev] 22.95/23.65 s (S/u32/base_times.tsv)
- Readers: test_lock_order, test_twin_entry_point_order; the SPEC readers U33 listed (citations, import_placement, level_containment, lock_order, memory_catalog, task_inventory, threat_model_statement, timing_budget, toml_schema_contract, tunables_register); the repo scans; the main mypy pass.
- Seen failing first: none is needed for removing dead code. The proof is that `git grep write_and_recvfrom -- . ':!arduino' ':!audit' ':!legacy'` comes back empty and the main pass is green (a leftover caller fails it with attr-defined).

**Lane T (typing config)**
- Files: pyproject.toml, host_typecheck.ini, digital_twin/typecheck.ini, tests_scripts/test_mypy_any_baseline.py, BACKLOG.md.
- Checked only: scripts/typecheck.sh (steps 25, 26), test_comment_block_cap (step 29).
- Steps: 22, 23 (confirm the six ANN401 entries are live, R-13), 24 (R-15), 27, 28 (R-4), 30 (R-3), 37 (both twin entries still hold `Any`: unchanged), A.U34.11 (4) (R-14).
- Size: −5 module lines in pyproject and the CPY001 comment (:147-148); −3 sections in the host ini; +25 lines in the test; +8 in BACKLOG.
- Checks: none at -1/32768. typecheck.sh (three passes and three single-file runs): base to measure.
- Readers:
  - pyproject: test_ci_workflow, config_paths_resolve, host_annotations, lint_ceilings, lint_type_scopes, mypy_any_baseline, no_variant_literals, preview_server, ruff_exemptions_live, script_metadata_pins, suppression_form, tool_pins, typecheck_sh.
  - inis: buildgen_validate, digital_twin_boot_contiguity (15.54 s, S/u32), config_paths_resolve, lint_type_scopes, typecheck_sh.
  - BACKLOG: test_citations. The test: test_lint_type_scopes (:23).
- Seen failing first: an extra `disallow_any_explicit = false` exemption in a tmp config is named by the new subset guard.
- Depends on: nothing.

**Lane C (CI)**
- Files: .github/workflows/ci.yml, tests_scripts/test_ci_workflow.py (taken in by R-8).
- Steps: OF-208 (R-8); step 21 checked only.
- Size: 4 identity steps of 4 lines each and 4 keys; +15 lines of test.
- Checks: lint.sh (actionlint, zizmor). No GC stages.
- Readers: test_build_firmware, ci_workflow, js_coverage_report_dir, lint_type_scopes, test_sh, uv_sync_retried_sh, plus the repo scans.
- Seen failing first: the new pin fails at base on all four keys.
- Depends on: nothing.

**Lead**
- Proves the four file sets are disjoint.
- Runs the base checks on U33's close head, then verifies the check-only steps (5, 6, 7, 8, 17, 20, 21, 25, 26, 29, 32, 35, 36) there and again at the gate.
- At the close: re-records twin_record.json (the `src/` files change), runs the silent-failure scan, and writes the open-findings and register rows.

### P2.3 Waves and order
- **W0 (lead):** set the base (U33's close head); prove the sets disjoint; open `S/u34/relay.md` with sections `## A`, `## N`, `## T`, `## C`.
- **W1:** A1, N1, T1 and C1 in parallel.
  - <UDPHDR> is N1's first commit: src/asy_udp_socket.py:1-3 only, relayed as `<UDPHDR> <hash>` under `## N`.
  - It is the only commit any other lane needs. A2's attribution test checks that header (M.TSC.139 Change).
- **W2:** A2 (merges <UDPHDR> first), N2 and T2.
  - T2's BACKLOG text names C's and A's changes from the rulings, not from their commits, so it has no merge dependency.
- **W3 (lead):**
  - merge A, N, T and C (disjoint);
  - re-record the twin record;
  - run the whole tests_scripts tier once through S/u29/tier.sh, never beside another tier;
  - run the full gate at both GC stages, the twin CI per device, the web tier and coverage;
  - push and watch CI. CI's first run is the one Playwright cache miss OF-208's row expects: "the browser re-installed once".

### P2.4 Rulings draft (agent, 2026-10-21)
- **R-1 The cut as in P2.2.** Process.
- **R-2 (a) The explicit-Any sweep.**
  - Baselines: main pass 15 modules (pyproject:420-436), twin 2 (digital_twin/typecheck.ini:32-40), host 4 (host_typecheck.ini:43-55). None of the 21 is in U34's 28 files.
  - What the step text requires of U34 (A.U34.11 (1)): run typecheck.sh, remove the emptied entries with their comment, and, for every module still listed, list its sites in the landing note and send it to the OR2.c review, "not removed silently".
  - So U34 does not clear other units' files. It trial-removes the 8 zero-`Any` entries (5 main, 3 host). It keeps every removal the three passes and the three single-file runs accept; an entry that still shows a finding stays and is listed.
  - The 13 modules that still hold `Any` go by the routing rule (grep counts are P1's):
    - **U35:** _sensortask_scenarios 79, test_asy_uart_comm 26, test_asy_uart_driver 23, _bus_hazard_catalog 21, tests/machine.py 9, test_bus_hazard_generated 8 (no later holder; test file), src/asy_system_service.py 7 (U35's bare-name entry; typing only), test_bus_hazard_multi_device 5, digital_twin/machine.py 5, test_digital_twin_bus_hazard_concurrency 5, test_cross_browser_smoke_probe 8 (no later holder; test file).
    - **U36:** _boot_contiguity_probe 3, _uart_link_contract 2.
    - **U37:** none.
  - So OR81.a's "the flag is on and all passes clean before B5" (PROJECT_AUDIT_PLAN.md:433; B5 is U37, :600) holds if U35 and U36 clear their modules.
  - Process point for the lead's routing rows: each row carries the module's own pyproject.toml lines (its ANN401 entry and its baseline line) or its ini section, to be removed in the clearing commit. Otherwise test_ruff_exemptions_live.py:123 fails on the stale ANN401 entry.
  - Settled by A.U34.11 (1), the routing rule and OR81.a.
- **R-3 Step 30's U34 form.** Each pass's exempted set must be a subset of a named residual set: the 13 modules above, split by pass. A new exemption then fails, and leaving the baseline needs no edit to the test. The "nothing sets false" form lands when the residual set is empty: U37, which holds the test (A.U37.02).
  - Settled by M.TSC.109's own Change "(a new per-module exemption fails)" and by SPEC:2664-2666 ("only shrinks and which … pins"). Today that sentence is unpinned: the test checks only existence (:56-60).
- **R-4 (b) Step 28.** mypy_path stays as it is, and so does the :21-22 comment: the packet's "the scripts' sibling modules" clause would be false. The `scripts` sections leave by R-2. Settled by find_sources.py:185-187 and host_typecheck.ini:24-27.
  - The two bare imports go to the next holder: _hardware_verdict.py:20-22, :73, :131 to U37 (no later holder; not a test file), and runner.py:18 to C (work_order.json). The fix shape is the one in _digital_twin_ci_suite.py:31, :36: a repo-root path entry plus `from scripts._summary_block import`.
  - Conservative: no config change.
- **R-5 (c) Step 2's word order.** Keep "`ext/microdot.py`, pinned `v2.7.0`" (test_vendored_microdot.py:21, :40-43). After it, add the three stub file names, "(type-checking only, never frozen)" and "on 2026-10-06" (CLAUDE.md:124). Settled by the test.
- **R-6 (f) The legacy Microdot text is fixed now.** THIRD_PARTY:19 becomes "upstream commit `482ab6d`, an untagged snapshot four commits after `v2.0.6`, before `v2.0.7`".
  - Sources: CLAUDE.md:119-121, and `git describe` of S/corpus/microdot-new, which gives v2.0.6-4-g482ab6d.
  - Step 2 rewrites this same entry, and the stale-doc agreement plus PQ1 ("factual doc drift fixed in place") apply.
  - The lead records U36's stage for this sentence as done.
- **R-7 (d) Remove `write_and_recvfrom()` and its `tries` guard** (asy_udp_socket.py:175, guard :186-189).
  - Settled by the carry at REGISTER.md:726 (agent, 2026-10-20) and by the callers' code (P2.1).
  - In the tests:
    - delete :276-354, :1899-1912 and :1998-2010;
    - rewrite the three NTP-pattern tests onto `write()` and `recvfrom()` in the shape asy_ntp_client.py:261-264 uses;
    - reword the comments at :454, :1408-1412 and :1913.
  - SPEC:6253-6254 drops "(and so `write_and_recvfrom()`)". THIRD_PARTY:189-198 drops the paired-method comparison.
  - The test file is taken in because the method and its tests must land in one commit (precedent: U32's R-20). Keep :1364 and :1831.
- **R-8 (e) OF-208.**
  - The four Playwright keys gain `${{ steps.ident.outputs.id }}`.
  - Each of the four jobs (:153, :212, :273, :353) gets the identity step from action.yml:18-21, its text identical.
  - The pin in test_ci_workflow.py: every key on `~/.cache/ms-playwright` names the identity, and every identity run line equals the action's.
  - The Firefox key stays (P2.1). Conservative: one more cache download per change to `ImageOS` or the compiler/glibc versions.
  - test_ci_workflow.py is taken in as the fix's own test. CLAUDE.md's workflow puts tests first, and no later unit holds the file.
- **R-9 OF-96 closes with no edit**, citing tests_scripts/test_vendored_freezefs.py:9-31 (U0, 8104062).
- **R-10 test_vendored_freezefs** gains a check that THIRD_PARTY names `UPSTREAM_COMMIT` (:10), the same pattern as test_vendored_microdot.py:40-43. Consistency fix ('Change, don't flag', owner, 2026-09-25).
- **R-11 Captive DNS:** 2019, p-doyle, no NOTICE file (S/u34/upstream_captive.md).
  - LICENSE-captive_dns:201 keeps its year and gets no append.
  - The header is `Apache-2.0 AND MIT`, with Apache-2.0 scoped to DNSQuery (FOLD_ANSWERS.md:250).
  - Steps 10-12 no longer need upstream.
- **R-12 Step 29 is check-only.** U33's R-3 holds while owner question 6 is open (BACKLOG:1296-1302).
- **R-13 Step 23:** the six ANN401 entries (pyproject:261-276) and their category comments stay while they fire. They leave with their files under R-2.
- **R-14 `disallow_any_unimported` (A.U34.11 (4)).**
  - T2 measures it per pass and puts the count and sites in the landing note. The lead writes the OR2.c register row, and U34's close report names the count.
  - OR81.a's owner question ("what remains") is entered by U37, where the sweep ends, because the U35/U36 edits may clear more of it.
  - Conservative: no question is asked on a count that will still change.
- **R-15 Step 24.** A BACKLOG paragraph after U33's last one, with no audit IDs (test_citations). It names:
  - the CPY001 comment;
  - the removed baseline entries and sections (lint and typecheck legs);
  - the subset guard and the new attribution test;
  - test_vendored_freezefs.py, never listed so far ("no leg affected", A.U34.08);
  - ci.yml (CI only, no chroot leg).
- **R-16 Step 15:** the K.9 bullet is found by its text "(SPDX header + attribution, matching the file's existing entries)". K.5.1 is U36's.
- **R-17 Step 9:** only SPEC "freezefs 2.4, unmodified" becomes "freezefs `main` at `26be9e3`, unmodified". The other A.1 drifts stay in U36's stage 4: a sentence U34 does not rewrite (unlike R-6).
- **R-18 Steps 1 and 34** use M.DOCS.001/060's "post-audit only" wording (BACKLOG:514). The README map stays U36's.
- **R-19 Step 33b** writes "(agent, 2026-09-30; owner-reviewed, 2026-10-02)". Settled by FOLD_BRIEF.md:32-34 and FOLD_ANSWERS.md:249-251.
- **R-20 Every new THIRD_PARTY sentence with decision vocabulary carries its actor or source.** That file is scanned with no allow-list row (`_LICENCE_FILE`). No text anywhere carries an audit ID or "Step N" (test_citations).
- **R-21 No # @tunable, error_catalog, UART changelog or allowlist change.** If a lane orphans an allowlist row, it relays that to the lead.
- **R-22 Hardware: none.** H25 and H73 landed through U26 and U28.
- **R-23 Check-only steps** are verified at the base and again at the gate. A red there is a regression, routed by the rule.
- **R-24 The work order's `src/captive_dns.py`** is the old name of `src/asy_captive_dns.py`. The lead notes it.
- **R-25 For the owner: none.**
- Every P1 "conflicts" row is ruled: step 2 by R-5, step 28 by R-4, step 29 by R-12.

### P2.5 Risks
- **By mode:**
  - STA: NTP and DNS keep their own `write()`/`recvfrom()` calls, unchanged.
  - AP: the captive DNS uses `recvfrom()`/`sendto()`, unchanged.
  - Silent and Off: no UDP traffic. USB: nothing changes.
  - The only firmware change is a method with no caller. The licence and header texts change no behaviour.
- **UART:** the wire format is untouched, and there is no changelog row.
- **Memory gates:** N's four unit files plus twin[dev] at both stages, and the lead's full gate: zero MemoryError and zero "memory allocation failed". Nothing is fixed by `gc.collect()`, a threshold or `-X heapsize`. The removal allocates nothing.
- **Frozen image:** only asy_udp_socket.mpy changes (it shrinks).
  - The five header files have to stay at exactly three lines. A fourth line would shift the bytecode line tables.
  - A proves it with mpy-cross for its four files, and N does the same for the header commit.
- **Timing:** test_asy_udp_socket shrinks. The new and changed tests_scripts files each stay under about 2 s.
  - The doc checks read about 40 more lines.
  - A growth over 10 % and 0.5 s, or over 10 s, is made efficient, never by cutting strictness.

### P2.8 Blocks (60-80 calls; no file split across two blocks of one lane; each lane's last block runs its complete checks)
- **A1 (about 65-75 calls):** THIRD_PARTY_LICENSES.md only, steps in packet order. Checks: decision_vocabulary, citations, legacy_paths, vendored_microdot (including the R-5 plant).
- **A2 (about 60-75):**
  - files: LICENSE-captive_dns, the four headers, the new attribution test (seen failing first), the freezefs check, README;
  - merge <UDPHDR> first;
  - then: the mpy-cross compare and A's readers (all of them).
- **N1 (about 55-70):** <UDPHDR> first; then the test file (R-7), then the method removal; the four unit files at both stages; the main mypy pass.
- **N2 (about 40-55):** SPECIFICATION.md. Then N's complete checks: lint; the main pass; the four unit files plus twin[dev] at both stages on the head; SPEC readers; repo scans.
- **T1 (about 55-70):** pyproject.toml, both inis and the test (R-2, R-3, R-4, R-13); one full typecheck.sh run after the removals; the residual site list with path:line.
- **T2 (about 40-55):** the R-14 measurement (three runs); BACKLOG.md (R-15); then T's complete checks: lint.sh, typecheck.sh, T's readers, repo scans.
- **C1 (about 30-45):** the pin first, then ci.yml; lint.sh; C's readers.
- Commits are named `U34 lane <L>: <summary>`, one per step group. Branches are `audit/u34-{a,n,t,c}` in S/wt-u34{a,n,t,c}, built with S/u23/rebuild.sh.

### Base-time shards (on U33's close head; seconds are earlier units' figures or estimates, for balance only)
- **A (about 27 s):** tests/test_asy_udp_socket.py@-1 (7.2), tests_scripts/test_citations.py (13.3), test_ci_workflow (est. 2), test_vendored_freezefs (est. 0.5), test_vendored_microdot (est. 0.5), test_mypy_any_baseline (est. 1), test_lint_type_scopes (est. 2).
- **B (about 25 s):** tests/test_asy_udp_socket.py@32768 (7.2), test_decision_vocabulary (8.8), test_legacy_paths (est. 5), test_comment_block_cap (4.4).
- **C (about 24 s):** test_ruff_exemptions_live (est. 20), test_typecheck_sh (est. 3), test_third_party_attribution (new; measured after only, est. 1).
- No per-device rows.

### Not determinable read-only
- Whether each of the 8 zero-`Any` entries really holds no finding (T1's run settles it).
- The `disallow_any_unimported` counts (T2).
- How long typecheck.sh and test_ruff_exemptions_live take.
- Whether the new THIRD_PARTY text passes test_decision_vocabulary (A1).
- Whether mpy-cross output is unchanged for the header files (A2, N1).
