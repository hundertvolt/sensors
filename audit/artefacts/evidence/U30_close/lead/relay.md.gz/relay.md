# U30 relay: one part per lane; a lane writes only where its brief says, the lead writes the rest

## lead
- <BASE> = 5ba138c (U29's squash, pushed 2026-10-20). <API> = audit/u30-api at c253487 (C1 475d9ac + the lead's pyproject line: asy_print_log.py's ruff entry gains PLW0603). <W1> = (after wave 1).

## C
- (lead, from S2's final 7838df9, checked) `_rearm_timer()`'s comment in `src/asy_base_classes.py` says "At boot start_timers()
  runs before the tasks"; the generated `main()` starts the tasks first (`start_tasks()`, then `start_timers()`,
  `build/generated_src/sensortask_wozi.py`'s `main`). The helper is right either way; the comment states the order wrong.
- (lead, from S1's interim 48c81cc) OF-51's store half is yours: `src/asy_config_manager.py`'s `_get_values()` (CFG_NOT_VALID)
  and `_get_typed_values()` (CONTRACT) persist and print on every call while the store is invalid, so a config-damaged
  BMP3XX episode logs every cycle (S1's R-16 change covers the reader half only; `err_s` stores each call). The
  scan rule applies: one entry and one console line per episode, the next good read clears it, seen failing first.
- C1 475d9ac (audit/u30-c). API: `asy_print_log.report_if_fatal(e)`/`fatal_reported()`; `SystemService.is_reset_decided()`; `RouteSources.is_reset_decided` (5th field, after `system_cmd`; generated `is_reset_decided=sysfunct.is_reset_decided`); `_FramManager.get_pause()`; `SensorReader._rearm_timer()` (S2: replace each two-line re-arm `if self._timer_error is not None: self._timer_error = None; self.start_timer()` with `await self._rearm_timer()`).
- For the lead (pyproject.toml, outside my set): ruff reports `PLW0603` at `src/asy_print_log.py:409:12` (`global _fatal` in `report_if_fatal()`, the step's module flag). Needed line beside the two existing ones: `"src/asy_print_log.py" = ["PLW0603"]`, and the block comment "One module flag each, with one writer: the UTC-valid flag the NTP client sets, and this boot's reset bits that begin_boot() reads once (PLW0603)." gains ", and the C-stack fatal flag report_if_fatal() sets".

- (C, ce87287) For the lead: `tests_scripts/test_watchdog_feed_sites.py` (outside my set) goes red in its two bite tests, whose anchors quote the old escalation call; the supervisor's one `_reboot(` is now `await self._reboot(escalate, message, system_reset)`. Needed, verified green (22 passed) in a scratch copy: line 353 anchor `'                await self._reboot(_RR_TASK_BUDGET, "Reboot triggered", system_reset)\n'` -> `'                await self._reboot(escalate, message, system_reset)\n'`; line 362 both strings -> `'await self._reboot(escalate, message, system_reset)'` and `'await self._reboot(escalate, message, system_reset, fed=True)'`.
- (C, ce87287) For the lead or X: `tests_hardware/bench/test_reset_reasons.py:178-186` (`test_a_c_stack_exhaustion_is_attributed`, its comment "src/ has no code of its own for a stack exhaustion ... the attribution is the budget's (agent, 2026-10-14)") and `tests_hardware/device_scripts/reset_code_stack_exhausted.py`'s docstring expect ResetReason 5; the first recorded death now reboots with 20 (E25 entry). Hardware: parked, not run.

- (C final, afef401) For the lead: `src/asy_udp_socket.py`'s `UDPSocket.write_and_recvfrom()` (no lane's file) has no `src/` caller since the resolver checks `write()` itself (c78c936); only `tests/test_asy_udp_socket.py` uses it. Dead-code removal or keep is yours.
- (C final) For the lead's REGISTER (class 4, pair mode "mempause landing while a ResetErrors write waits"): `PrintLogHistoryStore.reset()` checks the pause before it clears; a pause set while the clear's write waits for the store's write lock or the chunk's op lock (another write of the same chunk in flight) is still refused after RAM was cleared, as before the fix. Conservative fix: on a refused write with the pause now held, restore the pre-clear count and ring. Not fixed here (needs a snapshot allocation in the reset path).
- (C final) For X: E25 STACK_EXHAUSTED, ResetReason 20, E73 NTP_DNS_NOT_SENT, E74 NTP_DNS_NXDOMAIN (catalog rows landed); `resolve_ipv4()` returns `(address | None, cause)` with `DNS_RESOLVED/NOT_SENT/NXDOMAIN/FAILED`; `SystemService.is_reset_decided()` and `RouteSources.is_reset_decided` (SPECIFICATION.md:915); a FRAM-backed store's `reset()` clears nothing while the pause holds (DEVICE_REFERENCE.md:159-161 is yours); a ConfigManager read failure persists once per run; `report_if_fatal()`/`fatal_reported()` and `tests_scripts/test_fatal_report_sites.py`; `tests_hardware/README.md:938` and `tests_hardware/bench/test_reset_reasons.py:178-186` as above.
- (C final) `tests_scripts/test_fatal_report_sites.py` at afef401: 97 findings, all in other lanes' files (bmp3xx 11, captive_dns 4, fram_manager 6, isl29125 21, notification 3, scd30 17, sgp40 5, uart_comm 2, webserver 10, wifi 16, voc_algorithm 2); 0 in the generated modules.

## N
- N (step 105, expected until the lead's Part N edit at W1): tests_scripts/test_tunables_register.py:253 `SPECIFICATION.md:11020: gc.threshold_bytes: Sites list [...] the tags say [...]` - the row lists ('tests/test_asy_webserver_service.py', '32768'), whose nine `# @tunable gc.threshold_bytes = 32768` tags left with the threshold calls; remove that one site from the row.
- (lead) `tests/test_asy_uart_driver.py` is yours now (files_N.txt): its `cobs_uart(max_frame=1 << 30)` construction provokes a
  genuine allocation failure that FramingCOBS now prints. Record it with `record_prints()` and assert the line, as
  `tests/test_asy_base_classes.py` does for its genuine one, so the deliberate failure is asserted, never only hidden.

## S1
- 9ac2b84 (final): 48c81cc memory part, bb41930 the <API> merge, 9ac2b84 report_if_fatal in 11 BMP3XX and 21 ISL29125 handlers.
- 48c81cc (interim): the memory part; 14 steps wait for <API> (report_if_fatal in 11 BMP3XX and 21 ISL29125 handlers).

## S2
- 7838df9 (final): b42a097 memory steps, 0bd91fb the <API> merge, 7838df9 report_if_fatal and the re-arm.

## G
- (G) Checker rows beyond A.U30.16's list, each a baseline (its heap reading follows the collect) unless named: tests/
  test_asy_base_classes.py `test_piecebuffer_retains_nothing_after_construction`; test_asy_system_service.py `_call_cost`,
  `_settled_alloc`, `test_the_reports_outputs_allocate_nothing`; test_asy_uart_comm.py
  `test_a_declared_size_over_max_transfer_bytes_is_refused_before_any_allocation.measured`,
  `test_repeated_maximum_size_and_over_cap_trains_keep_the_heap_flat`; test_asy_uart_driver.py
  `test_a_read_retains_nothing.grown`; test_async_harness.py `_growth_over_awaited_tasks.scenario`;
  test_digital_twin_unix_port_unretrieved_report.py `_call_cost`, `_settled_alloc`, `test_the_reports_outputs_allocate_nothing`;
  test_digital_twin_sensortask_integration.py `_heap_floor` (R-11); digital_twin/run_generic_integration.py
  `_print_shutdown_line` (collect, then mem_info()); device_scripts uart_dma_ring_interrupts_off.py `_sweep`, `_window`
  (before a timed window); unretrieved_task_exception_handler.py `_at_threshold`, `_locked_reports`, `_settled_alloc`;
  loop_stretch_timing.py `_main` (measured collection pause, R-11). Re-derived names: allocation_need_per_source.py
  `_measure` (packet `_run`); `_shared/heap_probe.py` `_report`, `dump_map`, `largest_block` (the moved probe/map
  functions); the f9 soak's `...memory_flat.free_after`; the twin link rows without `.scenario`. Not written:
  `_shared/map_dump.py` (no gc call). Removed, no reading after it: uart_link_under_concurrent_system_load.py `_main`'s
  collect. Rows in C/N/V files: microtest.py `_reset_process_state` (C), test_asy_uart_driver.py and the f9 soak (N),
  the twin runner's `<module>`, `_mem_sampler`, `_print_shutdown_line` (V): a rename there stales a row.
- (G) Pending-list lines my steps retire (tests_scripts/test_import_placement.py, now red "_PENDING entries that no longer
  occur"): :63 `("tests/test_digital_twin_uart_link.py", "_hammer_with_the_graph_running", "gc")`, :64
  `(... "test_many_back_to_back_transfers_do_not_degrade_or_leak", "gc")`, :67 `("tests/test_uart_comm_hazard.py",
  "_hammer_clean", "gc")`, :68 `(... "_hammer_faulted", "gc")`, :69 `(... "_measure_retention", "gc")`, :70
  `(... "_under_threshold", "gc")`.
- (G) For the lead's Part N edit (tests_scripts/test_tunables_register.py red, f221308): SPECIFICATION.md:11020
  `gc.threshold_bytes`'s Sites lose `tests/test_uart_comm_hazard.py — 32768` and `tests/test_digital_twin_uart_link.py — 32768`
  (both in-body threshold sites gone); rows withdrawn with the integration file's wall-clock run bounds (each wait inside
  counts polls or yields): :11391 `l2.sensortask_integration_run_bound_s`, :11392 `..._long_run_bound_s`, :11395
  `..._supervisor_run_bound_s`, :11398 `..._hotspot_run_bound_s`, :11399 `..._reboot_run_bound_s`.
- (G) Live tree at f221308: `scripts/_check_gc_collect_sites.py` exits 1 on 26 sites, all lane N's threshold calls in
  tests/test_asy_webserver_service.py (its step 105); red with it: test_gc_collect_sites.py's live-tree case and
  test_lint_sh.py's clean run. No root cause in src/asy_fram_manager.py: the 40-cycle loop retains nothing per cycle.

## X
- (lead, from S2's final 7838df9) For I.2's catalog and the await-depth test: the SGP40 devices gain `VOCAlgorithm` (35
  attributes) and a 268 B backup buffer as construction survivors (the H44 survivor figure is re-read at the bench);
  `_exchange()` adds one await level. `voc_algorithm.py`'s `unpack_from()` lets MemoryError propagate (the read path
  logs `str(e)`), and both codec handlers also catch OverflowError (a huge offset raises it on v1.29.0).
- (lead, from S1's interim 48c81cc) Facts for the docs: SPEC G.2 gains `I2C`/`I2CDevice.get_register_into()` ("for a burst
  the caller decodes at once into a buffer of its own"); I.2: the held scratch view (one slice per register access), no
  view for a whole-buffer transfer, construction survivors `_pt_burst` 8 B, `_rgb_burst` 6 B and `_config_burst` 3 B
  (the snapshot is valid until the next one).
- (lead, from S1) Yours as code: `tests_hardware/device_scripts/c_stack_budget.py`'s `_I2C_LEAVES` lacks
  `get_register_into`, now the leaf of the BMP3XX burst and the ISL29125 counts and snapshot; its docstring says every
  bus leaf is wrapped.
- (lead, from N's final df79dc6) Facts for the docs: `report_if_fatal(e)` now leads 42 broad handlers in N's files
  (webserver: 9 arms, the catch-all and the gathered outcomes; Wi-Fi 16; captive DNS 4; FRAM manager 6; notification 3;
  UART comm 2), and handlers that clean up and re-raise carry none (`asy_fram_driver.py`, `asy_spi_driver.py`). ResetErrors
  reads `routes.is_reset_decided()`, `_shutdown_accepted` is gone, and the refusal still answers "Failed". A heap failure
  in `_body_as_dict` re-raises, so the catch-all persists it and answers 500. The first failed server start is persisted
  as well as the last; the rebound print skips only the timeout the proxy's read arm already traced. With no check
  buffer, a FRAM read returns block 0 without rewriting block 1 and logs ALLOC once per run (the verify path too). The
  codec and the FRAM manager print a caught exception as `str(e)`; the COBS scratch prints
  `FramingCOBS scratch allocation failed: <text>` and catches OverflowError too. Changelog B79 (UART comm) and B80
  (codec): no C impact.
- (lead, from N) OF-123 for F.2's network facts: after `tcp_write()` queued the bytes, `tcp_output_nagle()` can fail on rp2
  (ERR_RTE on a link-down netif, ERR_IF on a >1 s CYW43 credit stall, ERR_BUF on an empty-ACK header alloc;
  `lib/lwip/src/core/tcp_out.c:1294-1297, 1366-1371, 1321-1322`); the bytes are never sent twice through `src/`: the
  OSError reaches asyncio's `drain()`, nobody retries, Microdot re-raises it and `_serve()` persists the error and closes, so the
  client sees a response cut short against its Content-Length. No code; the bench half stays in hardware session 1 (H39).
- (lead, from C's final afef401) For the docs: a recorded C-stack overflow reboots through the supervisor with
  ResetReason 20 and one E25 STACK_EXHAUSTED entry; E73 NTP_DNS_NOT_SENT and E74 NTP_DNS_NXDOMAIN; `resolve_ipv4()` returns
  `(address | None, cause)`; a FRAM-backed store's `reset()` clears nothing while the pause holds (DEVICE_REFERENCE.md:159-161);
  a ConfigManager read failure persists once per run of failures; `tests_scripts/test_fatal_report_sites.py`.
  `tests_hardware/README.md:817` (row 5) still describes the stack exhaustion as the budget's reboot: the bench
  test and its device script now expect code 20 (lead commit a4f6517 on W1). CORRECTED (lead, 12:58): `:938` is not
  about the stack; it says a garbage DNS reply and silence log the same code, still true (both `DNS_FAILED`, E67; only
  NOT_SENT and NXDOMAIN got E73/E74): re-read it, change it only if a word is now wrong. The resolver now calls `write()` and
  `recvfrom()` itself; `UDPSocket.write_and_recvfrom()` stays, with no src/ caller and its own tests (SPEC:6030 stays true).
- (lead, from G's final f221308) For the docs: `scripts/_check_gc_collect_sites.py` is now one gc policy checker over src/,
  tests/, digital_twin/, tests_hardware/ and the generated modules (each boot entry one module-level
  `gc.threshold(<int literal>)`), for collect, threshold-set, disable and enable, with 47 categorised rows; an empty
  scope, no device, a device that fails to generate or a file that fails to parse exits 2; a row whose file is gone is
  stale; it reads a fresh stamped `build/generated_src/`, never a stale one. Stale now: SPECIFICATION.md:8323-8335
  (I.4(f.1)'s checker paragraph) and CLAUDE.md:397-398. BACKLOG.md needs a chroot-list line for this `scripts/` change.
  The sensortask integration file's waits count polls or yields (no wall-clock bound; a hang is the per-file
  timeout's); its five Part N run-bound rows are withdrawn (lead commit 9a706d9). The UART hazard and twin link hammers
  run at their file's GC stage. R's B.14.6, F.7 row 31 and E.5.2 sentence are landed on W1: keep them as they stand.
- (X final, head c1e3e5f) Part N row for the lead (a register table of your choice; the tag sits in an L0 check):
  | `mem.max_await_depth` | 28 levels | `tests_scripts/test_await_depth.py` — `28` | the C-stack budget (F.1): the board peak from `c_stack_budget.py` held to half the 7,936 B limit (`flash/test_memory_stress.py`) | measured 2026-10-20, the longest static await chain `tests_scripts/_await_depth.py` finds over src/ and every device's generated modules at f594679 (a `GET /status` through Microdot's dispatch to the FRAM manager's log of a lost chip); the per-level cost is owed to the flash tier | none: a tripwire at the measured depth | a chain grows past it, or the board reading lands |
  `tests_scripts/test_tunables_register.py` stays red until it lands: "tests_scripts/test_await_depth.py:12: mem.max_await_depth is tagged but has no SPECIFICATION.md Part N row".
- (X final) Two stale allow-list rows for the lead to delete, `tests_scripts/_decision_vocab_allowlist.txt` (red: `test_decision_vocabulary.py::test_the_allowlist_only_shrinks`); the edits the packet set for these two sentences removed them:
  line 28: `HEAP_FRAGMENTATION_MEASUREMENTS.md	**It holds method, not results.** Current-state facts and rules live where they`
  line 71: ``SPECIFICATION.md	The comparable 1.28 figure is the 2026-09-08 hammer-load `mem_free` floor of 91,``
- (X final) Left at f594679's state, since ## V and ## L carried no line at hand-back: I.4(e) fold (6) states the unit tier at
  its W1 level with option 1 ("are to log at ERR or above") as the target, and digital_twin/README.md's Run 12 has no
  stack cell. Once V's cell (d) and L's option-1 commits land, the next docs pass adds code 20 to Run 12 and rewrites that sentence to the landed state.

## V
- (V, 1c4fbb8) For the lead (tests_scripts/test_twin_runner_test_flags.py, no lane's file): red at :108 since the runner's
  TestFlags grew two fields (--test-hold-system-entry, --test-kbd-traceback); green once the bite's anchor reads
  `on = source.replace("_NO_TEST_FLAGS = TestFlags(False, None, None, None, None, False, False, None, False)", "_NO_TEST_FLAGS = TestFlags(False, None, None, None, None, False, False, None, True)")`.
- (V) For the lead (scripts/_twin_process.py, no lane's file; OF-215 stage 1 and stage 2's host half): shutdown() sends a
  second SIGINT before the kill and records its outcome (exit 1 with nothing printed: the first was never consumed;
  another exit: raised and absorbed; still running: neither acted on), sending KBD_TRACEBACK on stdin first; the
  verdict stays the kill's (-SIGKILL, run.killed). Patch with its test (3 cases in my
  test_digital_twin_ci_suite_errcount.py, seen failing 3 of 3, then 94 passed in 2.9 s), verified on 14512c5:
  S/u30/laneV/of215/of215_stage1.diff. It adds two tags needing Part N rows: `l2.kbd_traceback_wait_s` 1.0 s and
  `l2.second_sigint_wait_s` 2.0 s (estimated (agent, 2026-10-20): the runtime's second-interrupt exit is immediate,
  a KBD_TRACEBACK line needs one 50 ms stdin poll). With it, Context.boot can arm `--test-kbd-traceback` on every boot.
- (V) For the lead (scripts/_twin_process.py spawn(), new finding, class 4 / twin and tooling): a twin argument of 256
  bytes or more kills the interpreter before the runner starts ("FATAL: uncaught NLR", exit 1): the Unix port interns
  every argv element as a qstr (ports/unix/main.c:412, v1.29.0) and qstr_from_strn() raises "name too long" outside any
  handler (py/qstr.c:319-321; MICROPY_QSTR_BYTES_IN_LEN 1, py/mpconfig.h:369). The harness reads it as "the twin exited
  before ever serving: exit code 1". Reproduced: a --device label or any state path of 256+ bytes, on W1 too. The
  state paths are logs_dir/<scenario name>/state_NN/..., so a deep logs dir or a long scenario name reaches it.
  Conservative fix: spawn() refuses an argument of 256+ bytes naming it and the limit.
- (V) For X (digital_twin/README.md "Runner flags"): rows
  `| \`--debug-level N\` | off | every logger built at level N, until the stored \`DebugLevel\` applies |`,
  `| \`--test-hold-system-entry ERRNO\` | \`ENTRY_HELD\`, \`ENTRY_RELEASED\` | SystemService's logger holds its entry with that errno until an \`ENTRY_RELEASE\` line arrives on stdin (the supervisor's escalation entry) |`,
  `| \`--test-kbd-traceback\` | \`KBD_CAPTURED <bool>\`, \`KBD_TRACEBACK\` | the interpreter's one KeyboardInterrupt object, caught at start by a SIGINT to itself; a \`KBD_TRACEBACK\` line on stdin prints where the newest interrupt was raised |`;
  item 12 (Run 12) gains "a C-stack overflow raised in one read of the plan's first bus device reboots through the
  supervisor and the relaunch reads code 20 with SYSTEM's one STACK_EXHAUSTED entry"; the harness paragraph: every
  boot logs at error level (the runner's --debug-level 1 and a stored DebugLevel 1 planted before the spawn, owner,
  2026-10-20: "Option 1 is good"), but the scenario reading the device's defaults, which boots unplanted on its own twin.

## V2
- (V2, 95ed89f) Part N rows for the two tags in scripts/_twin_process.py, after `l2.kill_reap_timeout_s`:
  | `l2.kbd_traceback_wait_s` | 1.0 s | `scripts/_twin_process.py` — `1.0` | `shutdown()`'s wait, once a twin ignored its SIGINT, for the `KBD_TRACEBACK` printout of where its interrupt was raised (`--test-kbd-traceback`, armed on every scenario-harness boot) before the second SIGINT | estimated (agent, 2026-10-20): the runner reads a trigger line within one `l2.twin_test_stdin_poll_ms` poll (50 ms) — measurement owed: the printout's latency on a twin that ignored its SIGINT, L2 | against that measurement, once taken | the code under test or the host class changes |
  | `l2.second_sigint_wait_s` | 2.0 s | `scripts/_twin_process.py` — `2.0` | `shutdown()`'s wait for a twin's exit after the second SIGINT, before the kill | estimated (agent, 2026-10-20): the runtime exits at once on a second SIGINT while the first is still pending (`ports/unix/unix_mphal.c:65-69`, v1.29.0) — measurement owed: the second SIGINT's exit latency, L2 | against that measurement, once taken | the code under test or the host class changes |

## L

## R
- (lead) pairs2 finished (`S/u30/lead/gcstack/pairs2/pairs.tsv`, 120 rows, two rounds, trees swapped in round 2): every
  result identical between the builds and zero markers. At -1, 14 of 15 files are within 0.1 s (system_service is
  0.5 s faster); voc_algorithm averages +0.06 s over the two swapped rounds, so the earlier +0.2 s was round 1's tree.
  At 32768 every file is faster, 52 s across the 15. test_neopixel_wifi_integration.py ran only on the fresh tree:
  wt-u30n's generated stamp is stale. Your five alternating voc runs still stand as the brief's check.
- (R final, a16fafd) Part N row for the L1 table, beside `l1.unix_heapsize`:
  | `l1.unix_gc_stack_entries` | 1024 entries | `toolchain/micropython_overrides.py` — `1024` | `MICROPY_ALLOC_GC_STACK_SIZE` in the generated Unix variant header that `build-standard`, `build-settrace` and `build-lwip` compile with, read back after each build by `verify_unix_gc_stack_in_build()` (B.14.6); what a stack overflow costs scales with `l1.unix_heapsize` | measured 2026-10-20, Unix port v1.29.0, `build-standard` against 1024- and 4096-entry scratch builds, paired runs, two rounds with the trees swapped: at 32768 `test_voc_algorithm.py` 20.0 → 6.3 s, `test_asy_scd30_driver.py` 43.0 → 28.8 s, `test_asy_webserver_service.py` 12.4 → 7.2 s, `test_digital_twin_uart_link.py` 79.4 → 70.3 s, results identical; 4096 saved 1.6 %, 0.0 % and 2.3 % beyond 1024 on the first three | upstream's own large-heap value (`ports/rp2/mpconfigport.h:94`); 4096 saves under 3 % more, below the 10 % that would justify it (agent, 2026-10-20) | the pin moves, `l1.unix_heapsize` changes, or a file's time at 32768 grows |
- (R final) For the lead: `tests_scripts/test_tunables_register.py` stays red on the new tag until that row lands ("toolchain/micropython_overrides.py:162: l1.unix_gc_stack_entries is tagged but has no SPECIFICATION.md Part N row"); its second red line, `gc.threshold_bytes`'s Sites listing `tests/test_asy_webserver_service.py`, is already red on 64cd620 (N's step 105). A tree with a16fafd sees the shared toolchain as stale (`scripts/_unix_port.sh check` names "stale micropython_overrides.py", `ensure` reruns setup) and its `build/generated_src` as stale (the generator's stamp hashes `micropython_overrides.py`; outputs identical but `_BUILD_DATE`): install the three binaries at the sync point before any lane's tree carries the commit, then `rebuild.sh` each tree.
