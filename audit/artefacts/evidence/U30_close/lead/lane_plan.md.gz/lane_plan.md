# U30 (MEM) lane plan: the planning agent's hand-back as received (preliminary packet at fd4ac55)

> Lead note (2026-10-20, after the owner's instruction on review lists): the planner's line "all go on the owner's review list" does not stand. A ruling that a source, project consistency or an owner decision settles is recorded in REGISTER, not reviewed; only a judgment with real impact that none of them settles goes to the owner, in plain words. Re-sort R-1..R-37 on that rule at U30's start.

U30 (MEM) lane plan. Agent, 2026-10-20. Read-only, sites quoted from S/wt-u29 at fd4ac55 (preliminary). Lanes locate sites by quoted text once the lead regenerates the packet on U29's head. Nothing was written outside S/u30/plan_scratch/. That folder holds three python3 -I helpers: summ.py, units.py (prints step Unit slots), gcsites.py (lists gc policy calls) and broad.py (counts broad handlers).

1. COUNTS
- Placed: all 145 changes in 142 steps. Step 19 is the one co-landing group of 4. All 28 carried actions (all_acts.txt) are in a lane.
- Already landed at fd4ac55 (28 steps), with evidence:
  - 2: bench/test_heap_under_connection_ceiling.py:43, :91.
  - 19b M.TEST_HELP.033: tests/_webserver_concurrency_scenarios.py is absent; scripts/_digital_twin_scenarios.py is present.
  - 22: uart_driver_read_never_blocks_the_loop.py:165 (_trial), :195 (main).
  - 23: uart_idle_poll_rate.py:59, :105.
  - 24: uart_link_under_concurrent_system_load.py:128, :237, :254-258 (no churn collect).
  - 25: heap_headroom_after_full_system_build.py:14 includes _shared/heap_probe.py:28-57.
  - 26: heap_layout_after_full_boot_sequence.py:68.
  - 27: allocation_need_per_source.py:70, :82, :94, :132.
  - 28: serving_at_default_gc.py:95.
  - 29: scripts/lint.sh:72-89 (grep_guard), :94 (checker call).
  - 68: flash/test_memory_stress.py:113-121.
  - 79: scripts/test.sh:62-77 (GC_THRESHOLD range).
  - 87: SPECIFICATION.md:9030 (RegionBuffer).
  - 100: tests/test_asy_sgp40_driver.py:13 (FastAsyncSleep).
  - 111, 120: scripts/test.sh runner and pytest tier (U27).
  - 113: asy_ names in use (scripts/_check_gc_collect_sites.py:27-28).
  - 125: tests_scripts/test_lint_sh.py:1-22 (no gc case left).
  - 126: digital_twin/machine.py:520, :548 accept any buffer.
  - 127: digital_twin/_sgp40_chip.py (wire-identical).
  - 128-129: digital_twin/launch.py:92-96, :210-211.
  - 132: digital_twin/run_device_script.py:126.
  - 133-134: segfault_stress_repro.py and unix_port_gc_unwedge.py are absent.
  - 135: digital_twin/README.md:261.
  - 137: digital_twin/README.md:957-959.
  - 139: tests/test_digital_twin_launch.py:129, :284.
- Nothing to write, a check only (6 steps):
  - 3: c_stack_budget.py landed at U26 in a wider form (leaves :42-43, facts :76-80). X verifies it against the analysis (R-35).
  - 76 and 138: the I2C changes are wire-identical; the L3 sweep and the L2 twin hazard file must pass unchanged.
  - 97: A.U30.07's test lines hold as they are.
  - 106: A.U30.08 changes no result.
  - 140: the twin SCD30 tests decode their own way.
- To write: 111 changes. C 21, N 19, S1 24, S2 17, G 6, X 22, V 2.
- Real hardware: 11 steps (2, 3, 22-28, 68, 76). All landed in their U26 form; the readings are parked in §5.
- Steps whose site is in a lane-T file (19):
  - CLAUDE.md: 1, 21 (the memory bullets, not "Standing backstop").
  - tests_hardware/README.md: 4.
  - SPECIFICATION.md: 5, 6, 7, 16, 30 (E.9, beside lane T's E.1/E.3), 31, 77, 86, 87, 112, 117, 118, 121.
  - scripts/test.sh: 79, 111, 120 (all three already landed).
  - Part N rows implied by steps 105, 110, 114/115 and 142 belong to the lead, after U29 lands.
- Open findings: 30 rows target U30. The brief's list holds 30 IDs, not 31; I checked it against the table. OF-145 and OF-146 are decided (owner, 2026-10-13, "1 b, 2 b") with U30 as target in their state cell, so 32 rows in all. OF-60, -70, -181 and -184 (target C) and OF-122 (an owner question whose option (b) would land in U30) name U30 too.
- lanes_prelim.txt cannot be used as the cut. Its union-find ran on stale or bare names: lanes 5, 18, 19 and 20 name src/system_service.py, src/base_classes.py, src/config_manager.py and src/api_response.py, all absent; lane 6 holds bare names. The cut below is by file family.

2. THE CUT (one owner per file; the API stop is the only edge between lanes)

Lane C — core, catalog, NTP and DNS
- Files: src/asy_print_log.py, src/asy_system_service.py, src/asy_base_classes.py, src/asy_config_manager.py, src/asy_api_response.py, src/asy_ntp_client.py, src/asy_dns_client.py, buildgen/error_catalog.json, tests/microtest.py, tests/test_asy_{print_log,system_service,base_classes,config_manager,api_response,ntp_client,dns_client}.py, tests_scripts/test_error_catalog.py, new tests_scripts/test_fatal_report_sites.py.
- Steps: 8-15, 17, 18, 32-36, 41, 94, 107-109, 116. The first commit is C1 (the API).
- Open findings: 36 (kept), 50 (base half), 62 (closed), 77 (DNS arm), 78, 80, 88, 145, 146 (the accessor).
- Size: about 650 changed lines in 18 files.
- Checks, at -1 and 32768:
  - The tests/ files above, plus test_microtest_hooks.py, test_ntp_fram_system_integration.py and test_reset_call_site_invariant.py.
  - tests_scripts: test_fatal_report_sites.py (red until W1 by design), test_error_catalog.py, test_watchdog_feed_sites.py (still two feeds in _supervise), test_counter_steps.py, test_readiness_gates.py, test_buildgen_definitions.py.
  - Seen failing first: the fatal-report check at base (116 handlers in 19 src files lack the call); the supervisor L1 (the flag is set but no reboot with code 20 happens); OF-145's L1 (a ResetErrors during mempause, then a post-pause store, loses the history); OF-146's L1 (a ResetErrors during the escalation's log write clears the logs).
- Depends on: nothing.

Lane N — web, network, FRAM storage
- Files: src/asy_webserver_service.py, src/asy_wifi_service.py, src/asy_captive_dns.py, src/asy_uart_comm.py, src/asy_notification_service.py, src/asy_framing_codecs.py, src/asy_fram_manager.py, buildgen/codegen.py, UART_C_PORT_CHANGELOG.md, tests/test_asy_webserver_service.py, tests/test_asy_fram_manager.py, tests/test_asy_framing_codecs.py, and the buildgen test that pins RouteSources (found at L0).
- Steps: 37-40, 42-53, 56, 57, 105.
- Open findings: 63, 77 (the codec at :84, the FRAM manager at :104), 97, 98, 123 (analysis), 146 (the wiring).
- Size: about 600 lines in 13 files.
- Checks, at both stages:
  - test_asy_webserver_service.py (base 16.0 s / 16.6 s; it ends with 9 fewer tests), test_setter_microdot_integration.py, test_asy_webserver_connections.py, test_asy_wifi_service.py, test_asy_captive_dns.py, test_asy_uart_comm.py, test_asy_notification_service.py, test_asy_fram_manager.py, test_asy_fram_wire_trace.py.
  - tests_scripts: test_buildgen_generate.py, test_buildgen_reproducible.py, test_digital_twin_generated_boot.py.
  - Seen failing first: a handler raising the stack error answers 500 and sets the flag; OF-146's refusal through the shared state; OF-98's first start failure. Step 105 is a pure migration (green at both stages).
- Depends on: report_if_fatal and the accessor, after <API>.

Lane S1 — I2C, BMP3XX, ISL29125
- Files: src/asy_i2c_driver.py, src/asy_bmp3xx_driver.py, src/asy_isl29125_driver.py and their three tests/test_asy_*.py.
- Steps: 54, 58-62, 69-75, 78, 80, 90-93, 95, 96, 98, 123, 124.
- Open findings: 51 (the BMP3XX half), 56.
- Size: about 550 lines in 6 files.
- Checks:
  - The three files at both stages.
  - The four-tier L1 and L2 files, unchanged and green: test_bus_hazard_multi_device.py, test_bus_hazard_generated.py, test_digital_twin_bus_hazard_concurrency.py (151.6 s / 155.2 s base, wall-time-bound).
  - test_digital_twin_bmp3xx.py and test_digital_twin_isl29125_autorange.py.
  - Seen failing first: buffer identity (asy_i2c_driver.py:368 passes memoryview(buf)[start:end]); one scratch view (:185 wraps the scratch per read); get_register_into() absent.
- Depends on: <API>, for the handler steps only.

Lane S2 — SCD30, SGP40, VOC
- Files: src/asy_scd30_driver.py, src/asy_sgp40_driver.py, src/voc_algorithm.py, tests/test_asy_scd30_driver.py, tests/test_asy_sgp40_driver.py, tests/test_voc_algorithm.py.
- Steps: 55, 63-67, 81-84, 88, 89, 99, 101-104.
- Open findings: 50 (the SCD30 and SGP40 halves), 51 (the SCD30 half), 64, 90, 152.
- Size: about 500 lines in 6 files.
- Checks:
  - The three files at both stages (SCD30 22.2 s / 43.8 s, SGP40 29.8 s / 31.0 s base).
  - test_digital_twin_scd30.py, test_notification_scd30_integration.py, the L1 hazard file.
  - tests_scripts/test_digital_twin_boot_contiguity.py: with the VOC algorithm now a construction survivor, it must pass unchanged.
  - Seen failing first: the algorithm built at construction (asy_sgp40_driver.py:671 is `= None`, :773-775 the lazy block); the decode without slices (asy_scd30_driver.py:861-863); a word read without a list or a float sleep (asy_sgp40_driver.py:691-699).
  - OF-90's identical output is a guard, proven with a planted bite.
- Depends on: <API>, for the handler steps only.

Lane G — GC sites and test-tier hygiene
- Files: scripts/_check_gc_collect_sites.py, tests_scripts/test_gc_collect_sites.py, tests/test_fram_integration.py, tests/test_digital_twin_sensortask_integration.py, tests/test_uart_comm_hazard.py, tests/test_digital_twin_uart_link.py, tests_hardware/device_scripts/uart_idle_poll_rate.py, tests_hardware/device_scripts/uart_link_under_concurrent_system_load.py, tests_hardware/flash/test_uart_crossover.py.
- Steps: 19 (M.SCR.015, M.TEST_UNIT.266 and M.TSC.095 in one commit), 110, 141, 142, and the checker rows of steps 22-28 and 131.
- Open findings and register rows: OF-01, 03, 04 (evidence for the lead's close), 47, 149, 187, 188, 196, 202, 205; REGISTER:791 X01.
- Size: about 450 lines in 9 files; the effort is mostly the proof runs.
- Checks:
  - test_gc_collect_sites.py and test_lint_sh.py.
  - A.U30.15's proof: each prop-free file ten times at -1 and ten at 32768, with zero markers. That covers test_fram_integration.py (1.7 s / 2.1 s base) and the twin integration file (60.8 s / 63.5 s, wall-time-bound, plus settrace runs).
  - test_uart_comm_hazard.py and test_digital_twin_uart_link.py (67 s / 78 s, wall-time-bound) at both stages.
  - pytest --collect-only tests_hardware.
  - The live tree stays red on N's 26 webserver threshold calls until W1.
- Depends on: nothing to start; its live-tree check goes green only after W1 (N's step 105).

Lane X — docs and the two L0 analyses (wave 2)
- Files: SPECIFICATION.md (everything except Part N), CLAUDE.md, BACKLOG.md, HEAP_FRAGMENTATION_MEASUREMENTS.md, DEVICE_REFERENCE.md, digital_twin/README.md, tests_hardware/README.md, new tests_scripts/test_memory_catalog.py, new tests_scripts/test_await_depth.py, and tests_hardware/device_scripts/c_stack_budget.py (only if R-35 applies).
- Steps: 1, 3 (verify), 4, 5, 6, 7, 16, 20, 21, 30, 31, 77, 85, 86, 112, 114, 115, 117, 118, 119, 121, 122, 136.
- Size: about 850 lines in 10 files. The I.2 allocation-site catalog is the largest single item: every src/ module, the generated modules and the boot entry, plus U22's 896 B overlay row (REGISTER:596).
- Checks: the two new tests (one shared device generation, under 10 s each); test_citations.py, test_decision_vocabulary.py, test_comment_block_cap.py; one scratch dev-twin run for I.2's FRAM-buffer peak under ResetErrors.
- Depends on: <W1>.

Lane V — twin verification (wave 2)
- Files: scripts/_digital_twin_ci_suite.py, scripts/_digital_twin_scenarios.py, digital_twin/run_generic_integration.py, and the tests of those three (found at L0).
- Steps:
  - 130: Run 12 cell (d). `--fault <inst>:<op>:stack` exits 3 and the relaunch reads ResetReason 20, on every device.
  - 131: the sampler comment names the check.
- Open findings: 146 (the twin half, both paths, every device), 215.
- Size: about 300 lines in 6 files.
- Checks: Run 12 and the scenario job per device at both stages, one twin at a time, with at most 4 heavy processes; the brief authorises these runs.
- Depends on: <W1>.

Lead
- L0 after U29 lands: regenerate the packet, re-derive the site names, prove the files_<L> sets disjoint, run the base timing sweep of every file a lane grows at both stages, and open the relay S/u30/relay.md.
- Merge C1 as <API>.
- Part N rows, after U29's Part N lands: mem.max_await_depth; the withdrawn gc.threshold_bytes sites of steps 105, 110 and 142; the new tags from G and V.
- <W1>: rebuild; run the whole tests_scripts tier once; the L1 and L2 hazard files at both stages; fatal-report, gc-sites and catalog checks green.
- <W2>: the unit gate (the work order's seven items), push, CI.
- Records: REGISTER (:56, X01), open_findings, the review list.
- SPECIFICATION.md: X carries every U30 SPEC step; the lead edits only Part N.

3. WAVES AND ORDER
- W0: the lead's L0.
- W1: C, N, S1, S2 and G start at once (5 agents).
  - C's first commit is C1: report_if_fatal()/fatal_reported() in asy_print_log, microtest's _fatal reset, the flag's L1 test, and SystemService's shutdown-state accessor with its L1.
  - The lead merges C1 as <API>. N, S1 and S2 merge <API> before their report_if_fatal steps; their memory steps need nothing from it.
  - Inside C, the catalog rows E25/RR20 land in one commit with their constants, because test_error_catalog.py:719-721 pairs rows and codes both ways. The two NTP codes land with their constants too.
- W2: X and V on <W1> (2 agents). <W2> merges them, then the gate runs.
- Why these dependencies:
  - 19 src files import the one primitive.
  - OF-146's wiring reads C's accessor.
  - The gc checker's live tree needs N's step 105 and G's steps 110 and 142.
  - test_fatal_report_sites.py needs every lane's handlers.
  - The I.2 catalog, test_memory_catalog.py and test_await_depth.py read the landed tree; S2's _exchange() adds an await level.
  - Run 12 (d) needs C's supervisor branch and the readers' handlers.

4. RULINGS DRAFT (agent, 2026-10-20; each the conservative, reversible option; all go on the owner's review list)
R-1 The cut is as in §2: at most five agents at once, the file sets disjoint.
R-2 report_if_fatal lives in asy_print_log, not base_classes as A.U30.19 says. Placing it in base_classes closes an import cycle (M.SRC_CORE.034's ruling).
R-3 The C-stack reboot shares the task-budget block. That means one entry, the re-check, one feed, starve, then `_reboot(code)`; `escalate` becomes an int code and there is no `return` (M.SRC_CORE.016 Resolved (b)).
R-4 The codes are shared E25 STACK_EXHAUSTED and ResetReason 20, both reserved (REGISTER:133, :438).
R-5 voc_algorithm.py's two `except Exception` are narrowed, with no asy_print_log import (M.SRC_SENS.017).
R-6 The fatal-report check also walks the generated modules, though codegen emits no broad handler today (codegen.py:404, :877).
R-7 OF-146 (owner "2 b"): one accessor turns true at either reset decision, before its first await. For a system command that is acceptance (_feed_owned, asy_system_service.py:365); for the supervisor, the escalation decision, before its entry write at :521. codegen passes it as one RouteSources field. The webserver's _shutdown_accepted (:560, :834, :871) goes; the refusal's answer stays as it is today.
R-8 OF-145 (owner "1 b"): reset() of a FRAM-backed store clears nothing and returns False while the manager's pause holds. It reads the pause through get_pause, as asy_fram_manager.py:85 already does. X rewrites DEVICE_REFERENCE.md:159-161 with the owner's quote and the question.
R-9 The UART changelog row is B79: rows B63-B78 are taken (UART_C_PORT_CHANGELOG.md:186-201). It reads "no C impact", numbered at landing.
R-10 The gc allow-list rows are re-derived on the landed tree by A.U30.16's categories.
  - A site whose next statement reads the heap is a baseline row.
  - A collect with no reading after it props a test up: it is removed and root-caused.
  - Rows beyond A.U30.16's list are the scope's own content; each is named to the lead (CHECKLIST 4: the check tightens, nothing is loosened).
R-11 Two rows the packet did not plan:
  - `_heap_floor` stays as a baseline row (tests/test_digital_twin_sensortask_integration.py:249-250).
  - loop_stretch_timing.py `_main` (:61) gets its measured-pause row now, not at U31: the file has been present since 0c0ad52.
R-12 OF-62 closes with no code. asy_print_log.py:133-136 already prints the text through console(). A counted entry cannot live in a 0-slot ring, so ErrCount with an empty history is the trace.
R-13 OF-77 and OF-88: the caught exception's text goes through console() as str(e), never the class name. Every injected MemoryError is worded clear of both markers.
R-14 OF-63: with no check buffer, the read logs ALLOC once per episode and rewrites nothing.
R-15 OF-50: the stored E17 is persisted once, before the re-arm, in one shape at all four sites.
R-16 OF-51: one bool per reader gives one entry and one console line per episode; the next good read clears it.
R-17 OF-56 and OF-64: the 3-byte CONFIG snapshot buffer and the SGP40 backup buffer are allocated once, at construction.
R-18 OF-90: the per-sample `_f16(<constant>)` values are computed once at construction through the existing _f16(). Output stays bit-identical on both ports; literal constants would change rp2's float32 rounding. The rp2 frame cost and collect rate are parked to H44.
R-19 OF-78 and OF-80: resolve_ipv4() returns its cause. NTP persists two new NTP-band codes, NTP_DNS_NOT_SENT and NTP_DNS_NXDOMAIN; every other DNS failure keeps E67, and no state is added.
R-20 OF-97: the rebound print is skipped only for the exception the proxy's arm already traced, in the smallest form, with no new task or timer.
R-21 OF-98: the first start failure (W62) is persisted as well as the last; the handler arms persist with existing codes.
R-22 OF-123: a read-only reachability analysis at the pin; code only if the case is reachable on rp2; the bench half stays C (H39).
R-23 OF-167: no product change. OF-60's R2 [H17] reading decides whether a blank read gets an RDID probe; the row moves to U35, the next holder of the file.
R-24 OF-36: the default stands, with no /status counter; the gates read supervised task ends (tests_hardware/error_log_helpers.py:106-144). The owner's question stays pending; the row moves to U31.
R-25 OF-69: no metric change; the board's own reading (H44) decides. The row moves to C and to U36.
R-26 OF-83: no code; the bench's repeat-rate reading decides whether a latch is needed. The row stays C, since asy_print_log.py has no later unit.
R-27 OF-149 and OF-188: the file runs on build-settrace within A.U30.15's proof. If neither reproduces, they are recorded and move to U35; if one does, G root-causes it.
R-28 OF-187: the detection floor is lowered by more deaths or a per-death slope; the 2048 B bound stays, and the file stays within 10 % of its base time.
R-29 OF-47: the remaining wall-clock bounds become yield or iteration counts.
R-30 OF-215 in its own order:
  - a second SIGINT, with its outcome recorded;
  - the traceback-on-stdin flag;
  - then --stop-file with SIGINT as the fallback, seen failing first on a twin spawned with SIGINT blocked.
R-31 OF-196, -202, -205: zero generated modules exits 2; a row whose file is gone is stale; the modules are generated once per run.
R-32 M.SPEC.129 fold (6): the text states each tier's log level as found, and U30 changes no runner level. The unit tier's loggers start off (asy_print_log.py:75, :370; REGISTER:670). The unit tier's level becomes a row for U35.
R-33 A.U26.22's save-primitive sentence stays at Stage 10 (U35/U36); U30 writes only C.7 (11).
R-34 The CRC row keeps the landed figures, 160 B for CRC8/CRC16 and 416 B for CRC32 (SPECIFICATION.md:8045-8047).
R-35 c_stack_budget.py is extended only if test_await_depth.py's deepest leaf is not among its wrapped leaves. The 2× margin stays.
R-36 _MAX_AWAIT_DEPTH is measured on <W1>.
R-37 Runs:
  - The L2 hazard file runs in S1 and once more by the lead at <W1>; S2 runs L1 only.
  - The lead runs the whole tests_scripts tier once.
  - The base times come from the lead's L0 sweep.
None of these needs the owner. OF-36 and OF-122 stay the owner's pending questions from U11 and U21, with their defaults kept.

5. RISKS
- Firmware behaviour, by operating mode (STA, AP, Silent, Off, USB):
  - A.U30.19 applies in every mode. A recorded C-stack overflow reboots with ResetReason 20 (its label comes from the catalog), and the reboot is suppressed while a command owns the watchdog.
  - OF-145 and OF-146 apply in STA and AP; Silent, Off and USB have no REST client.
  - A.U30.04 changes boot on the SGP40 devices: the VOC algorithm becomes a construction survivor.
  - OF-64 (the restore wait) applies where NTP never syncs: AP, Silent and Off.
  - OF-62, 63, 77 and 88 add console lines at every log level, which widens OF-83's exposure when a USB host holds the port unread.
  - OF-78 and OF-80 apply in STA only; OF-97 and OF-98 in STA and AP.
  - A.U30.05, 06, 07 and 21 and OF-56 and 90 remove allocations, wire-identical, in every mode.
- UART wire format: no step changes it. asy_uart_comm.py (steps 50, 52, 53) gains only the call and its import; asy_framing_codecs.py:84 gains a console line. Both are Class B rows, "no C impact".
- Memory gates: A.U30.15 removes test props in the unit and twin tiers, at both stages. tests/test_fram_integration.py:170-173 records an exhaustion after about 7 cycles without its prop: any MemoryError is root-caused, never patched with a collect or a -X heapsize change. Also touched: A.U30.12 and 13 (each process runs at its own stage), A.U30.14 (threshold calls confined), R-13's console texts, R-32's tier levels, and the boot contiguity test after A.U30.04.
- Timing:
  - Likely to grow: the twin integration file (OF-187), V's scenario jobs and Run 12 (to be checked against U29's new lane-T budgets), the three new tests_scripts files, test_gc_collect_sites.py and test_lint_sh.py (three new scopes), test_asy_sgp40_driver.py.
  - Likely to drop: test_asy_webserver_service.py, test_uart_comm_hazard.py, the twin UART link file, and test_voc_algorithm.py at 32768.
- Parked for hardware session 1 (R1). Each needs the owner's go-ahead in its own conversation, the FRAM evidence saved first, and the wear gates.
  - H23: test_memory_stress.py::test_c_stack_peak_is_within_half_the_limit on the U30 image; its reading fills F.1's measured clause.
  - H44: the heap scripts (now counting the VOC survivor), OF-69's board reading, OF-90's frame cost.
  - H25 plus the L4 bench run (test_bus_concurrency_under_api_load.py): the I2C call forms.
  - H37: OF-01 and OF-03's new facts, in both CRC modes.
  - Also: H83 (the MemFree floor), H40, H13/H14 (the command path's refusal, R-7), H72 (OF-145 on the real chip), H39 (OF-123's bench half), OF-83's USB repeat rate, and the rp2 CRC per-call figure.

6. OPEN FINDINGS
- OF-01 → G: uart_idle_poll_rate.py:73-76. A listener that needed a cancel becomes a fact; test_uart_crossover.py fails on it.
- OF-03 → G: uart_link_under_concurrent_system_load.py:118. A False is counted; the host check at :190 asserts 0.
- OF-04 → the lead closes it, already landed: uart_idle_poll_rate.py:105 and test_uart_crossover.py:152 (_setup_ok); uart_link_under_concurrent_system_load.py:254-258.
- OF-36 → U31 (R-24). OF-47 → G (R-29). OF-50 → C and S2 (R-15). OF-51 → S1 and S2 (R-16).
- OF-56 → S1 (asy_isl29125_driver.py:1233-1239). OF-62 → C, closed (R-12). OF-63 → N (asy_fram_manager.py:102-107, :160).
- OF-64 → S2 (asy_sgp40_driver.py:259, :292). OF-69 → C and U36 (R-25).
- OF-77 → C (the DNS arm) and N (framing_codecs.py:84, fram_manager.py:104). OF-78, OF-80 → C (R-19).
- OF-83 → stays C (R-26). OF-88 → C (asy_base_classes.py:382-383). OF-90 → S2 (voc_algorithm.py:218, 103 call sites).
- OF-97, OF-98 → N. OF-123 → N analysis (R-22). OF-145 → C and X (R-8). OF-146 → C, N and V (R-7).
- OF-149, OF-188 → G (R-27). OF-152 → S2 (the self-test wait and the general-call settle, asy_sgp40_driver.py:731). OF-167 → U35 (R-23).
- OF-187 → G (R-28). OF-196, 202, 205 → G (scripts/_check_gc_collect_sites.py:96-141).
- OF-215 → V (R-30).
- Also routed: X01 → G. REGISTER:596 → X's I.2 catalog. OF-60, 70, 181 and 184 stay C, since no hardware has run. OF-122 keeps its default (a).

7. PACKET VS CODE AND LATER DECISIONS
- Stale names: M.SRC_CORE.003/.034, M.TSC.001, M.TEST_UNIT.230/.292/.309 and the work order's `files` use pre-rename names. At fd4ac55 they are src/asy_*.py and tests/test_asy_*.py.
- M.DOCS.024 labels the U30 changelog row "B63", but that number is taken (UART_C_PORT_CHANGELOG.md:186); R-9 makes it B79.
- A.U30.16 / M.TSC.095 against the live tree:
  - `_shared/map_dump.py` has no gc call, so its planned row would be stale.
  - The heap-probe functions now live in _shared/heap_probe.py (:28, :38, :43).
  - Live collect sites missing from the packet's list:
    - tests/test_asy_base_classes.py:483-491
    - tests/test_asy_system_service.py:3686, :3703, :3785
    - tests/test_asy_uart_comm.py:2476, :2479, :2574, :2577
    - tests/test_asy_uart_driver.py:2485, :2488
    - tests/test_async_harness.py:39, :47
    - tests/test_digital_twin_unix_port_unretrieved_report.py:88, :126, :179
    - tests/test_digital_twin_sensortask_integration.py:249
    - digital_twin/run_generic_integration.py:380
    - allocation_need_per_source.py:94
    - uart_dma_ring_interrupts_off.py:364, :368, :393
    - unretrieved_task_exception_handler.py:75, :167, :214
    - loop_stretch_timing.py:61
- A.U30.15's prop sites (:543-546, :627, :705, :779) are now :477, :548, :730, :765, :795. That is five props; two of them sit in tests added at U25. M.TWIN.144 expects no checker row for that file, but `_heap_floor` (:249) is a baseline.
- A.U30.11 gives CRC32 as 160 B; the landed SPEC says 416 B (SPECIFICATION.md:8045-8047).
- M.SPEC.129 fold (6) says every memory-gated tier runs at DebugLevel ≥ 1. The unit tier's loggers start at level off (asy_print_log.py:75, :370).
- A.U30.03's allowed rows name `SystemService.set_level_setters`, which is gone, and `AsyConnTime`, now `WifiService` (asy_wifi_service.py:221).
- c_stack_budget.py wraps I2C and FRAM leaves only (:42-43, :58-65), so it drives no REST-handler chain, which A.U30.18 (3) allows as the deepest path.
- M.SRC_NET.123 (step 45) omits U23's refusal (asy_webserver_service.py:834), which the owner's later decision OF-146 replaces with the shared state. The carried items OF-145 and OF-146 are not in the packet.
- Old line numbers for the GC-stage steps:
  - A.U30.12 → :2247-2271 and :3677-4025 (26 calls that set a threshold, plus 13 reads, = the packet's 39).
  - A.U30.13 → test_uart_comm_hazard.py:1358-1362 and test_digital_twin_uart_link.py:238, :273.
- M.SCR.015 puts the measured-pause row at U31, but loop_stretch_timing.py is already present.
- A.U30.04's site (:648-650) is now :671 and :773-775.
- OF-04 is still marked open, though it landed at U26.
- Cannot be determined read-only:
  - the deepest await chain;
  - whether a prop's removal reproduces a MemoryError;
  - whether OF-149 or OF-188 reproduce;
  - OF-123's reachability on rp2 (I did not read lwIP);
  - which buildgen test pins RouteSources (L0 finds it).
LEAD NOTE (2026-10-20, during U29's gate): the re-sort is done in S/u30/rulings_resort.md. No ruling reaches the owner. R-32 stands as the planner wrote it (an uncaught task death reaches every PC gate: microtest.py installs the always-printing handler); one narrower question, a caught MemoryError in a logger-bearing class at OFF, is measured at L0.

LEAD NOTE (2026-10-20, after the read-only cut audit): verified edges and their sequencing, now in files_<L>.txt and the briefs.
- C1 also carries: the `_FramManager` Protocol's `get_pause` with three test fakes (neopixel, notification, uart_link tests), OF-50's base helper (S2 uses it), step 139's constant compare (launch test). N waits on six C1 files, test_asy_webserver_connections.py (OF-97/98) and test_asy_notification_service.py included.
- C owns four files no lane held: the DNS resolver stubs (test_ntp_wifi_dns_integration.py, test_ntp_fram_system_integration.py, tests_hardware/bench/test_network_resilience.py) and test_microtest_hooks.py. report_unretrieved keeps `except Exception: pass` (the contract test pins it); the fatal-report check exempts it by name.
- OF-146's refusal L1 moves to N (the webserver refuses); C keeps the accessor's L1.
- G owns test_lint_sh.py (its sandbox meets R-31's exit 2).
- Steps 39 (1) and 66 (1) were dropped at U16 (REGISTER A-26): N and S2 skip them.
- Lead at W1: re-record the twin record once (every src change stales it); the Part N edit for gc.threshold_bytes (test_tunables_register red on N/G until then); re-run test_gc_collect_sites on the merged tree (G's rows name functions in C/N/V files).

LEAD NOTE (lead, 2026-10-20, R-32's option 1): the L0 map is `S/u30/option1_l0_map.md` (read-only agent at 442a564;
its mechanism checked by the lead in the source: `SystemService.setup()` re-applies the stored DebugLevel, a fresh
config writes 0, so `debug=1` alone is undone and each opted-in boot also plants `config_SYSTEM.cfg` = `{"DebugLevel": 1}`).
It lands in W2 lane L (logging), after W1's merge, on the files in `S/u30/files_L.txt` (25); every overlap is a W1
lane's (C1_extra, N, G), none a W2 lane's. Lane V takes the map's three V files (the runner's debug flag with its
Protocol, `Context.boot`'s plant before `spawn`, the runner test). Opt-in keywords, never a changed default; the
scenarios that pin DebugLevel 0 (the map's section 2) keep it by not opting in. Tests first: each opted-in file is
seen printing an injected ERR line it was silent on before. A marker the change makes visible is a finding, root-caused.
