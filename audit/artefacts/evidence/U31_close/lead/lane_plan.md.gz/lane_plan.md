U31 (PERF) lane plan. Agent, 2026-10-20. Read-only at 442a564 (S/wt-u29, U29's final tree); U30 has not run. Sites are quoted from 442a564. Lanes re-locate every site by its quoted text on U30's squash (<BASE>). Nothing was written outside S/u31/plan_scratch/, which holds three python3 -I helpers: summ.py (packet steps and changes), sleepforms.py (the src/ sleep sites A.U31.19's rule refuses) and setupsleeps.py (timed waits reachable from setup()).

1. COUNTS
- Placed: all 100 changes in 67 steps. Step 17 is a co-landing group of 32 changes and step 61 a group of 3; the other 65 steps hold one change each. All 28 carried actions are placed.
- Already landed at 442a564 (24 steps, U31's part complete), with evidence:
  - 1: `_WDT_TIMEOUT_MS` and its tag are at buildgen/validate.py:94-95 and are imported at buildgen/codegen.py:17. The tags are at codegen.py:24-31 and the imports at :11 and :16; `_KNOWN_SIGNALS` is gone.
  - 2: codegen.py:836-880. This includes the KeyboardInterrupt record of fold (1), at :873-879.
  - 4: tests_hardware/bench/test_end_to_end_timing.py:117-118, :126, :128.
  - 5: tests_hardware/flash/test_system_commands.py:141-152 (the erase feed-gap facts, reported through result_note).
  - 6: tests_hardware/device_scripts/loop_stretch_timing.py, all of it (`_ROUTINE_STALL_US` at :36; landed in 0c0ad52).
  - 7: loop_lag_under_combined_load.py:33 (`_SCRATCH_REGIONS`) and :121-125 (the facts).
  - 9: heap_headroom_after_full_system_build.py:14 (`# @include _shared/heap_probe.py`).
  - 13: src/asy_system_service.py:606-611 (`feed_watchdog`) and :306-309 (`_own_feed`).
  - 15: SPECIFICATION.md:125-130 (A.2: "at the first end past the threshold, the supervisor feeds the watchdog once"). A.2 names no `parse_cmd_request`.
  - 28: tests/_fast_sleep.py:31-41 (patches both `sleep` and `sleep_ms`).
  - 29, 30, 33, 35, 37 (its header), 41, 46: each file imports the shared `FastAsyncSleep`. `test_setup_applies_custom…` is gone.
  - 42: tests/test_asy_captive_dns.py:40-80. 43: :807.
  - 47: tests/test_asy_system_service.py:2736 and :2819.
  - 51: tests_scripts/test_watchdog_feed_sites.py:261-315.
  - 52: tests_scripts/_devices.py:25 and :42.
  - 54: digital_twin/network.py:25-27 (the tag and the 5 s budget comment) and the U25 singleton form.
  - 56: scripts/_digital_twin_scenarios.py:153-188.
  - 64: SPECIFICATION.md:406-409.
  - Landed inside step 17 (3 of 32):
    - M.SRC_CORE.016: asy_system_service.py:490-538 escalates inside the scan and feeds once; :686 has `sleep_ms(1000 // len(task_starters))`.
    - M.SRC_SENS.059 and .069: asy_sgp40_driver.py:815 `sleep_ms(_HEATER_OFF_MAX_MS + 1)`. `_reset()`'s int-second sleep stays at :731.
- Depends on U30, verified at L0 (3 steps and 1 change):
  - 14: tests_hardware/bench/test_reset_reasons.py:175-186 still reads TASK_BUDGET (code 5) until A.U30.19's code 20 lands (REGISTER:670).
  - 18: M.SCR.015's measured-pause row for loop_stretch_timing.py `_main` (:61). It is absent at 442a564; U30 R-11 lands it.
  - 24: M.SRC_NET.011 (`report_if_fatal` in the captive DNS handlers), U30 lane N.
  - M.SRC_SENS.068: asy_sgp40_driver.py:699 is still `asyncio.sleep(round(delay_ms * 0.001, 3))`; U30 S2 lands `_exchange()`'s `sleep_ms`.
  - Each one U30 leaves undone is landed by U31's owning lane (R-17).
- Check only (4 steps):
  - 19: A.5 names no `wait_for`.
  - 49: the wear guard finds a write-mode `open()` without help (tests_scripts/test_persistence_write_marker_completeness.py:530).
  - 58 and 59: real-time NeoPixel and twin WDT 0 hold. Their files get edge edits listed under the lanes.
- To write: 36 steps, 65 changes. C 6, S 20, W 17, F 0 (two open findings), T 6, D 15, lead 1 (Part N).
- Real hardware (9 steps: 4-11 and 14): written or landed, runs parked.
  - Round R1: H10/H12/H15 (reset codes), H20 (loop lag), H21 (no-yield stretches), H22 (FRAM holds), H23/H44 (heap and C stack), H55 (estimated tunables, `boot.unfed_stretch_*` among them), H73.
  - Round R3: H21 (flash-write gap, `persistence_write`), H50 (forced config repair: the `boot.setup_unit_stretch_ms` worst case), H68.
  - Round R5: soak and H19 (trigger spacing).
  - Each run needs the owner's go-ahead in its own conversation, the FRAM evidence saved first, and the wear gates.
- Steps whose files U30 also changes (27; each re-located after U30): 12, 16, 17, 18, 20, 21, 22, 23, 24, 26, 27, 31, 32, 34, 36, 37, 38, 55, 57, 59, 60, 61, 62, 63, 65, 66, 67.
  - Also re-checked: the landed anchors 13, 15, 19, 47, 51 and 64 (U30 C rewrites the escalation block, R-3; U30 X edits SPEC), and step 14 (code 20).
  - 10 of U31's 12 src files are U30's: system_service, base_classes, webserver, wifi, captive_dns, notification, i2c, bmp3xx, scd30 and sgp40. Only asy_udp_socket.py and asy_neopixel_driver.py are not.

2. THE CUT (one owner per file; wave 1 runs five agents)

Lane C — core, build checks, the sleep-form guard
- Files:
  - src/asy_system_service.py, src/asy_base_classes.py, tests/test_asy_system_service.py, tests/test_asy_base_classes.py, tests/_sensortask_scenarios.py.
  - buildgen/validate.py, tests_scripts/test_buildgen_validate.py, tests_scripts/test_buildgen_error_contract.py.
  - New tests_scripts/test_src_sleep_forms.py.
  - tests_hardware/bench/test_reset_reasons.py (only under R-17).
- Steps: 3, 14 (contingent), 17 (M.TSC.128 and the M.SRC_CORE.016 check), 25 (the time.sleep case), 27 (A.U31.03's assertion), 48, 53.
- Open findings: OF-26 (R-9); OF-29, the system half and the helper (R-10); OF-222 (U30 carry, section 9).
- Size: about 450 lines in 10 files.
- Checks, at -1 and 32768:
  - The four tests/ files, and test_sensortask[<device>] for all six devices.
  - test_ntp_wifi_dns_integration.py and test_ntp_fram_system_integration.py (arm_tick_timer's other callers).
  - tests_scripts: test_buildgen_validate.py, test_buildgen_error_contract.py, test_device_tomls.py, test_src_sleep_forms.py, test_watchdog_feed_sites.py, test_fatal_report_sites.py (U30's), test_error_catalog.py.
  - test_src_sleep_forms.py is red until W1 by design: 26 sites at 442a564, 25 after U30.
  - `--collect-only tests_hardware` and the host mypy pass, if test_reset_reasons.py is edited.
- Seen failing first:
  - The sleep-form check on <BASE>. It names each site; bites: `asyncio.sleep(0.05)` and a stray `time.sleep_ms(1)` in tmp modules.
  - A dev-shaped TOML with poll_idle_ms 900: tolerance 1000 − (4 + 900 + 21) = 75 ms, below 2 × 200 ms, yet it builds at base.
  - OF-26: a supervisor whose `_log_dead_task` raises leaves no SYSTEM entry.
  - OF-29: N fallback passes print N "Could not arm uptime timer" lines (record_prints).
  - A.U31.03: a planted `sleep_ms(10)` in a setup() fails, as a bite.
- Depends on: nothing. The first commit is <CORE>: `arm_tick_timer(..., quiet=False)`, a keyword with a default, asy_base_classes.py:377-385.

Lane S — sensors, LED, notification
- Files:
  - src/asy_i2c_driver.py, src/asy_bmp3xx_driver.py, src/asy_scd30_driver.py, src/asy_neopixel_driver.py, src/asy_notification_service.py.
  - Check only: src/asy_sgp40_driver.py.
  - tests: test_asy_i2c_driver.py, test_asy_bmp3xx_driver.py, test_asy_scd30_driver.py, test_asy_neopixel_driver.py, test_asy_notification_service.py, test_notification_neopixel_integration.py, test_notification_scd30_integration.py, test_notification_scd30_sgp40_integration.py, test_notification_sgp40_integration.py, test_ticks_rollover.py, test_digital_twin_bus_hazard_concurrency.py, tests/_bus_hazard_catalog.py.
  - Check only: test_asy_sgp40_driver.py, test_asy_isl29125_driver.py, test_bus_hazard_multi_device.py.
- Steps: 17 (M.SRC_SENS.007, .013, .023, .027, .028, .031, .034, .037, .040, .048, .050, .055, .057; check .059, .068, .069), 31, 32, 34, 36, 37, 44, 45; checks 29, 30, 33, 35, 41.
- Open findings: none.
- Size: about 300 lines in 18 files.
- Edges (tests that pin the old forms):
  - test_asy_bmp3xx_driver.py:53, :168-182 (a `_SleepRecorder` on `sleep` only), :594 (0.128939), :613-615, :2300.
  - test_asy_scd30_driver.py:48, :720, :731, :1580 (`_SOFT_RESET_WAIT_S`).
  - test_asy_neopixel_driver.py:114, :147 (`neopixel_dt`).
  - test_asy_notification_service.py:1305-1326 (`_next_sleep_s`) and :42 (`_NEXT_SLEEP_MIN_S`).
  - `neopixel_dt` writes: test_notification_neopixel_integration.py:79, test_notification_scd30_integration.py:62 and :86, test_notification_scd30_sgp40_integration.py:70, test_notification_sgp40_integration.py:102, test_ticks_rollover.py:210 (and `_next_sleep_s` at :246-252).
  - test_digital_twin_bus_hazard_concurrency.py:366-379: `_FastSleep` patches `sleep` only. Without a `sleep_ms` patch the 2.5 s SCD30 reset and the 100 ms probe settles run in real time.
  - tests/_bus_hazard_catalog.py:645-652: `_Asyncio.sleep_ms` advances its fake clock. The probe settle becomes `sleep_ms(100)`, so its accounting is re-read.
- Checks, at both stages:
  - The files above. Base times: SCD30 22.2/43.8 s, SGP40 29.8/31.0 s; twin hazard 151.6/155.2 s, wall-time-bound.
  - test_bus_hazard_generated.py, test_digital_twin_bmp3xx/scd30/sgp40.py, test_notification_fram_integration.py.
  - tests_scripts: test_digital_twin_boot_contiguity.py (the survivors change: one heap float, `neopixel_dt`, becomes a small int), test_const_mirrors.py.
  - test_tunables_register.py is red until the lead's Part N edit; relay the exact line.
- Seen failing first:
  - The ×32/×32 recorder sees `sleep_ms(129)`, not 0.128939 s.
  - The poll steps are recorded as 2 ms; SCD30's command waits as `sleep_ms(50)`.
  - `driver._frame_ms == 50`.
  - `_next_sleep_ms` returns an int in 59000..60000, and 100 at the floor.
- Depends on: nothing. The first commit is <LED>: the neopixel `_frame_ms` change.

Lane W — network and web
- Files:
  - src/asy_wifi_service.py, src/asy_captive_dns.py, src/asy_udp_socket.py, src/asy_webserver_service.py.
  - tests: test_asy_wifi_service.py, test_asy_udp_socket.py, test_asy_webserver_service.py, test_asy_webserver_connections.py, test_neopixel_wifi_integration.py, test_digital_twin_sensortask_integration.py. Check only: test_asy_captive_dns.py.
  - tests_hardware/bench/test_hotspot_role_reversal.py.
- Steps: 17 (M.SRC_NET.004, .007, .026, .027, .077, .081, .085, .087, .089, .092, .118, .119, .126, .127), 38, 39, 40; checks 42, 43, 59.
- Open findings: OF-29's WiFi sibling (R-10); REGISTER:109 (the client pattern's ms form, asy_wifi_service.py:169-172).
- Size: about 450 lines in 11 files.
- Edges:
  - test_asy_udp_socket.py:119, :357, :949, :1708 (`src_float("_RETRY_BACKOFF_S")`).
  - test_asy_webserver_service.py:372-383: `_VirtualClock.timers()` has no `wait_for_ms`. :2503 constructs the proxy with 0.05, :2540 with 1.0, and :2983 sets the `_s` attributes.
  - test_asy_webserver_connections.py:304: `_ASYNCIO_NAMES` lacks `wait_for_ms`.
  - test_asy_wifi_service.py:39-40 (`_src_pattern` reads `_ON_S`/`_OFF_S`), :59, :2301-2317, :2416-2420 (patches `sleep`).
  - test_neopixel_wifi_integration.py:59 (`neopixel_dt`) and :95-110 (records the wifi LED durations from `sleep`).
  - test_digital_twin_sensortask_integration.py:106 (`_STA_CONNECT_POLL_S`) and :382-389 (`_SteppedWifiAsyncio` caps `sleep` only).
  - test_hotspot_role_reversal.py:439, :573 (`src_number(... "_STA_CONNECT_POLL_S")`).
  - Comment drifts: asy_wifi_service.py:146, :153 ("20 * 0.5s", "10 * 0.5s").
- Checks, at both stages:
  - The tests above. Base times: webserver 16.0/16.6 s before U30 (U30 removes 9 tests); twin integration 60.8/63.5 s, wall-time-bound.
  - test_asy_dns_client.py, test_asy_ntp_client.py, test_ntp_wifi_dns_integration.py, test_setter_microdot_integration.py, test_website_build_integration.py, test_digital_twin_wifi_modes.py (read only).
  - tests_scripts: test_request_timeout_ceiling.py, test_buildgen_generate.py (unchanged).
  - `--collect-only tests_hardware` and the host mypy pass.
- Seen failing first:
  - The LED patterns recorded in ms: 2900/100, 1500/1500, 100/2900.
  - `_TimeoutStreamProxy` takes ms; the stand-ins answer `wait_for_ms`.
  - The UDP and captive DNS backoffs recorded as 500, 1000, … ms.
  - OF-29's WiFi pass prints the helper's line every pass while unarmed.
- Depends on: <LED> before test_neopixel_wifi_integration.py:59; <CORE> before the OF-29 sibling. The first commit is <NET>: the wifi `_MS` constants and `_flash_led`/`_run_led_pattern(on_ms, off_ms)`.

Lane F — twin network fidelity
- Files: digital_twin/network.py, tests/test_digital_twin_network_neopixel.py, tests/test_digital_twin_wifi_modes.py.
- Steps: checks 54 and 58, plus :56's edge.
- Open findings: OF-217, OF-218 (R-13).
- Size: about 150 lines in 3 files.
- Edges:
  - test_digital_twin_network_neopixel.py: 27 direct `connect()` calls (:110-546), many on a STA never activated. OF-217's EPERM breaks them, so each test activates first. Example: :411-425 calls `connect()` without `active(True)`.
  - The same file at :405-430 holds a link across `set_access_point_up(up=False)`: OF-218 changes that expectation.
  - test_digital_twin_wifi_modes.py:226-295 is re-read.
  - :56 reads `_STA_CONNECT_POLL_S`.
  - The product is safe: `_trigger_sta_connect()` activates first (asy_wifi_service.py:801-803).
- Checks, at both stages: the two files, the twin integration file (read only), and one scenario job (first device).
- Seen failing first: `connect()` on an inactive STA raises `OSError(EPERM)` (`lib/cyw43-driver/src/cyw43_ctrl.c:637-640`, `extmod/network_cyw43.c:308-311`, read at v1.29.0); a linked station reads disconnected once the AP goes down (`cyw43_ctrl.c:402-413`, `cyw43_lwip.c:296-298`).
- Depends on: <NET> for :56 only.

Lane T — twin runner, harness, hardware instruments
- Files:
  - digital_twin/run_generic_integration.py, scripts/_digital_twin_scenarios.py.
  - tests/test_digital_twin_run_generic_integration.py, tests_scripts/test_twin_runner_test_flags.py, tests_scripts/test_digital_twin_scenarios.py.
  - tests_hardware/flash/test_memory_stress.py, new tests_hardware/device_scripts/flash_write_loop_gap.py, tests_hardware/device_scripts/fram_command_hold_timing.py (the :30 comment).
- Steps: 8, 10, 11, 55, 57, 60; checks 49, 56.
- Open findings: OF-198 (R-12).
- Size: about 550 lines in 8 files.
- Edges:
  - `TestFlags` is built whole and positionally: run_generic_integration.py:166-174, :184, :188, :366; the help text at :227-230 counts too.
  - Positional constructions in tests: tests/test_digital_twin_run_generic_integration.py:120, :125; tests_scripts/test_twin_runner_test_flags.py:107 (a literal) and :54 (one flag per field).
  - U30 V may add a field for OF-215's stdin-traceback flag, so these sites are re-located after U30.
  - A new harness family needs a COVERS_TWIN_SCENARIOS counterpart or an E.6.6 row (tests_scripts/test_level_containment.py:50-62). Loop lag's counterpart is test_memory_stress.py:23, in this lane.
- Checks, at both stages: the runner test, the flag and scenario L0s, test_level_containment.py, and the scenario job of each device (base 439/511 s, dev in CI).
  - Scenario runs: one twin at a time, at most 4 heavy processes.
  - Device-script L0s: test_device_script_facts.py, _watchdog, _gc_threshold, _config_flush, _fram_regions, test_persistence_write_marker_completeness.py.
  - The mypy device-script pass and `--collect-only tests_hardware`.
- Seen failing first:
  - The flag-table row for `--test-loop-lag-ms`.
  - The lag verdict bitten with `--test-stall-loop-ms` above the bound.
  - Each OF-198 scenario bitten with its knob unset.
- Depends on: nothing. T relays README rows to D.

Lane D — docs and the timing-table check (wave 2)
- Files: SPECIFICATION.md (all but Part N), CLAUDE.md, BACKLOG.md, digital_twin/README.md, tests_hardware/README.md, new tests_scripts/test_timing_budget.py.
- Steps: 12, 16, 20, 21, 22, 23, 26, 50, 61 (M.DOCS.064 and M.SPEC.097), 62, 63, 65, 66, 67; check 19.
- Open findings: OF-35 (R-11); folds SF-A07 and SF-M4-09 (R-23).
- Size: about 500 lines in 6 files.
- Sites at 442a564:
  - A.7: SPEC:807-809, :816, :850-852. C.9.1: :3949. D.4/D.5: :4357-4366. E.9: :5515-5519.
  - F.1: :5899-5900. F.2: :6024-6030. F.3: :6109-6119. I.3: :8096. L.3: :9759.
  - CLAUDE.md:256; BACKLOG.md:254; twin README :252-254 and :445-461; hardware README :1385-1388.
- Checks: test_timing_budget.py (seen failing on <W1> with no table; one bite per failure class), test_citations.py, test_decision_vocabulary.py, test_comment_block_cap.py, test_toml_schema_contract.py, test_tunables_register.py, test_twin_fake_catalog.py.
- Depends on: <W1> and the lead's Part N edit.

Lead
- L0 on U30's squash:
  - Regenerate the packet.
  - Apply U29's OF-217/218 rows if they are absent (S/u29/close/of_rows_draft.md:11-12).
  - Verify the U30-contingent items, OF-145/146 closed, OF-36's move, the `TestFlags` field count, and R-32's level edits in tests/_sensortask_scenarios.py.
  - Prove the files_<L> sets disjoint.
  - Run the base timing sweep of every file a lane grows, at both stages.
  - Open S/u31/relay.md.
- Merge <CORE>, <LED> and <NET> as each is published.
- Part N (M.SPEC.156): R-24's list.
- <W1>:
  - Rebuild, then re-record tests_hardware/twin_record.json once (every src and device-script change stales it).
  - Run the whole tests_scripts tier once, and the L1/L2 hazard files at both stages.
  - Confirm test_src_sleep_forms.py, the gc sites, the fatal-report check and the tunables register are all green.
- <W2>: merge D, then the work order's 7-item gate, push, CI.

3. WAVES AND ORDER
- W0: the lead's L0.
- W1: C, S, W, F and T (5 agents).
  - S's first commit is <LED>, W's is <NET>, C's is <CORE>; the lead merges each.
  - W waits on <LED> only for test_neopixel_wifi_integration.py:59 (the attribute must exist, else the test silently sets a dead attribute and runs at 50 ms frames), and on <CORE> only for the WiFi sibling.
  - F waits on <NET> for :56.
- W2: D, on <W1>.
- Why:
  - The guard reads the converted tree.
  - Part N must hold every renamed ID before test_tunables_register.py and the F.3 table's Part N column can pass.
  - Docs state the code W1 landed.
  - test_timing_budget.py parses the F.3 table that D writes.

4. RULINGS DRAFT (agent, 2026-10-20; each names what settles it)
- R-1 The cut is as in §2. Process.
- R-2 `_WDT_TIMEOUT_MS` stays in validate.py:94-95. Moving it into codegen.py would close an import cycle (codegen.py:17 imports validate). Settled by a fact.
- R-3 A.U31.08 lands as its own rule, `bus.i2c-timeout-consumer`, beside U20's `bus.i2c-timeout-max`, which is the boot-clear bound (validate.py:600-607).
  - The check: 2 × each I2C bus timeout (absent: `_DEFAULT_TIMEOUT_US`, already read at :202) must not exceed the device's smallest hard consumer.
  - With a `uart_link`, that consumer is `_DEFAULT_TIMEOUT_MS − (2·poll_wait + poll_idle + _GC_PAUSE_WORST_MS)`. Otherwise it is `_WDT_TIMEOUT_MS − _TASK_CHECK_TIME×1000`, read from asy_system_service.py:62.
  - Settled by consistency: one cause per rule id, as validate.py's `bus.boot-clear-budget` and `bus.i2c-timeout-max` already are.
- R-4 The FRAM block budget stays at 25,000 µs, `l3.fram_command_hold_block_budget_us` (fram_command_hold_timing.py:29-30, SPEC:11972). A.U31.01's 30,000 µs `fram.block_hold_budget_us` is not added. Settled by the standing rule that a check tightens and never loosens, and by the later recorded value.
- R-5 flash_write_loop_gap.py writes a relative `_stretch.bin`, which is the board's root on silicon. Settled by a source and a rule: the twin runs device scripts in a scratch cwd (tests_hardware/twin_board.py:74), so `/_stretch.bin` would write the host's `/` (the owner's host-wear rule, 2026-09-17).
- R-6 Renamed tags keep the landed tag-on-the-line-above form (asy_captive_dns.py:40-47). Settled by consistency.
- R-7 Every conversion keeps its value, except two:
  - BMP3XX's reset settle goes from 2 to 3 ms, and its conversion wait rounds up (int(4.939) = 4 becomes 5 ms).
  - Settled by sources: `sleep(t) = sleep_ms(int(t*1000))` and `sleep_ms` sets `ticks_add(ticks(), t)` (extmod/asyncio/core.py:53-63, v1.29.0); tstartup 2 ms (S/dstxt bmp3xx__bst-bmp388-ds001.txt:344-348). Lane S reads the PDF first.
  - `_CFG_FAIL_INTERVAL_S` becomes `const(600)` (A.U31.14).
- R-8 Step 17's "one commit" is met by the unit squash. Inside the unit the guard stays red until W1. Process.
- R-9 OF-26: catch at `_supervise()`'s top, with `report_if_fatal(e)` first, then one persisted SYSTEM `TASK_RAISED` naming the supervisor.
  - The task then ends unfed, so the watchdog resets with ResetReason 2, which the catalog already labels "watchdog without a record".
  - No new code and no new state. `CancelledError` is a BaseException (core.py:18), so cancellation passes untouched.
  - Settled by the scan procedure's minimal-first rule (OR149).
- R-10 OF-29: `arm_tick_timer()`'s own console line prints once per episode, through `quiet=`.
  - The system loop uses its existing `reported` flag (asy_system_service.py:458-463). WiFi (:409-414) adopts it; NTP's sibling is bounded by its task end.
  - The persisted entries keep their current per-site rule.
  - Settled by the scan rule: a class found once is swept project-wide.
- R-11 OF-35 closes with F.3's `stall.console` row (≤ 500 ms per write, about 2 s per line, the exits of A.5), with no code. Settled by an owner decision: the accepted debug-mode limitation (owner, 2026-09-30).
- R-12 OF-198: one runner `--test-` flag sets `Timer.drop_next_soft_callbacks` (digital_twin/machine.py:1360-1363) before the arm.
  - Three scenarios run on the first generated device (E.2.1's device-independent clause):
    - Reset timer and boot sequencer: a watchdog reset, exit 3 and a trigger.
    - NTP retry: its documented loss (asy_ntp_client.py:279).
  - Settled by the finding's own text and E.2.1.
- R-13 OF-217 raises `OSError(EPERM)` from `connect()` on an inactive STA. OF-218 drops a held link when the AP goes down. Settled by the cyw43 sources cited in §2 (F).
- R-14 Loop lag runs per derived device with A.U31.06's 60 s, 10 s and 50 ms. Its bound comes from the TOML: con.uart_reply on a device with a `uart_link`, con.watchdog otherwise.
  - Its twin logs at ERR or above, so the twin gate sees a caught allocation failure under that load (the harness boots at DebugLevel 0, scripts/_digital_twin_scenarios.py:714). Settled by the owner's 2026-10-20 "Option 1", applied for consistency, and the rule that every memory gate is machine-checked (owner, 2026-09-26).
  - Its family is covered by test_memory_stress.py.
- R-15 Efficiency: every grown file is timed before and after at both stages. Past +10%, it is made efficient without cutting strictness; a window is never shortened and a bound never loosened. Settled by the owner's efficiency requirement.
- R-16 The asyncio stand-ins gain `sleep_ms` and `wait_for_ms` with the same virtual semantics (`wait_for_ms(aw, t)` is `wait_for(aw, t, core.sleep_ms)`, funcs.py:54-55). Settled by the source.
- R-17 Each U30-contingent item U30 left undone lands in U31 under its own U30 ruling. Process.
- R-18 OF-36 stays the owner's pending U11 question; the default is kept and the row moves on. Process.
- R-19 `_neopixel_freq` is not written: the public `neopixel_freq` at asy_neopixel_driver.py:83 is an earlier stage's. U31 adds only `_frame_ms`.
- R-20 `ServingLimits` keeps seconds; the ms values are stored once in `__init__`, and codegen does not change. Settled by A.U31.18.
- R-21 The F.3 rows are re-derived from the landed code; the code wins. Settled by the docs rule.
  - Examples: `con.uart_rx_ring`; `con.uart_reply` from asy_uart_comm.py; `rate.persisted_log` from asy_print_log.py; `hold.fram_block` per R-4; `stall.lwip_send` with the B.14 override.
- R-22 Consistency drifts outside the packet are fixed, not flagged (owner, 2026-09-25).
  - tests_hardware/README.md:1385-1388, and SPEC:816, :3949 and Part N :12070 ("1/N s").
  - F.2's wait_for_ms list gains the overlay wait at asy_neopixel_driver.py:92.
- R-23 SF-A07 and SF-M4-09: the rows `con.uart_tx` and `stall.wlan_switch`, with owed cells and no code. Settled by the fold text.
- R-24 Part N (the lead's):
  - Tag renames `_s`→`_ms`: i2c.probe_settle, bmp3xx.status_poll, bmp3xx.reset_settle (now 3), scd30 ×3, notify.min_sleep, udp.retry_backoff, dns_server.recv_backoff_initial/_max, wifi ×9; notify.cfg_fail_interval_s takes the value 600; l1.asy_notification_service_next_sleep_min_ms = 59000.
  - New rows: `boot.setup_unit_stretch_ms`, the R-3 rule row (`i2c.timeout_consumer_us`), and T's new l2 tags.
  - `loop.sync_wait_max_us` is "Checked by" test_src_sleep_forms.py, and its Dependants gain the boot clear.
- R-25 A.U31.03's assertion rides `_scenario_boot_feeds_the_watchdog`'s boot (tests/_sensortask_scenarios.py:749-757), "one assertion, not two tests". setupsleeps.py finds no timed wait in any batch unit; the protocol classes' waits run in tasks. Settled by A.U31.03's text.
- For the owner: none.

5. RISKS
- By operating mode:
  - Every mode: the conversions are value-identical (R-7), and BMP3XX gains at most 1 ms. One heap float per call leaves each converted sleep: the webserver allocated one per stream call, SCD30 one per register read, BMP3XX one per poll, NeoPixel one per frame.
  - STA: the connect poll stays 10 × 500 ms and the disconnect wait 20 × 500 ms; DNS and NTP UDP retry after 500 ms; the webserver still bounds at 5 s per call and 15 s overall.
  - Risk: a test's tiny seconds value rounding to 0 ms. Lane W greps for it.
  - AP: the captive DNS backoff (500 to 5000 ms), the stations settle (100 ms), and the 2900/100 and 1500/1500 patterns are identical.
  - Silent: the LED stays dark and the cadence is unchanged.
  - Off (no configuration): the 100/2900 pattern is identical.
  - USB: OF-29 cuts console lines at a raised level; OF-26 adds no level-0 line; OF-35 is documented.
  - Boot is untouched. OF-26 applies only once the supervisor is running.
  - Twin-only flags stay out of the image (test_twin_runner_test_flags.py).
- UART wire format: untouched. No protocol file changes and no changelog row is needed; the F.3 UART rows are docs only.
- Memory gates, at -1 and 32768:
  - Run-phase churn drops. Construction survivors drop by one float (`neopixel_dt`); the boot-contiguity test must pass unchanged.
  - The new twin code is bounded (a fixed histogram, no list growth).
  - Zero `MemoryError` and zero "memory allocation failed". Never a `gc.collect()`, a threshold or `-X heapsize` as a fix.
- Timing:
  - Grows:
    - The scenario jobs: loop lag adds about 70 s plus a boot per device, against the dev base of 439/511 s.
    - The OF-198 scenarios add about 45 s on the first device.
    - The `runner.scenarios_timeout_s` basis (5× the slowest job, 2555 s) is re-measured at CI.
    - test_asy_system_service.py and test_buildgen_validate.py / error_contract grow slightly; test_digital_twin_network_neopixel.py gains 2-4 tests of 0.7 s connects.
    - The two new tests_scripts files cost under 1 s.
  - Neutral or faster: the twin hazard file, once its fast sleep covers `sleep_ms`.

6. OPEN FINDINGS
- OF-26 → C (R-9). OF-29 → C and W (R-10). OF-35 → D (R-11).
- OF-36 → lead, after U30 moves it (R-18).
- OF-145, OF-146 → lead verifies U30 closed them; if not, C and W (R-17).
- OF-198 → T (R-12). OF-217, OF-218 → F (R-13).
- OF-40: target C, no U31 work.
- REGISTER:109 → W. REGISTER:743 (SF-A07) and :777 (SF-M4-09) → D.
- REGISTER:433 → S (BMP3XX's seconds-form wait). REGISTER:512 → W and lead.

7. PACKET VS CODE
- Stale names in the work order and actions: `src/system_service.py`, `src/captive_dns.py`, `print_log.py`, `tests/test_system_service.py`, `tests/test_captive_dns.py`. These are now asy_* and tests/test_asy_*. `_TASK_CHECK_TIME` is at asy_system_service.py:62.
- Every SPEC line number is stale: F.3 is at :6109, A.7 at :637, L.3 at :9594 (table :9759), D.4 at :4357, E.9 at :5483, F.1 at :5655, F.2 at :6007, I.3 at :8076, C.9.1 at :3917.
- M.DOCS.064's site is BACKLOG.md:254, not :345-471.
- A.U31.08: the rule id and the Part N name are taken (validate.py:600-607; `i2c.timeout_max_us` at SPEC:11002); see R-2 and R-3.
- A.U31.06's region 0x3FF00 landed as `fram_max_size − 0x200`.
- M.SRC_NET.077 Resolved (2): `_WIFI_REFRESH_S` stays an int (asy_wifi_service.py:199, :432).
- `_next_sleep_secs` is `_next_sleep_s` (asy_notification_service.py:296).
- Helper renames in steps 34, 35 and 36 (`_make_service`, `_make_driver`) are U35's; U31 converts the ms parts only.
- Sites the packet misses are the §2 edges.
- Landed early: A.U31.17, .07, .10, .04, .05/.06's scripts and two of the three flash tests, and A.U24.58 (SPEC:5808-5809).
- OF-217/218 are not in open_findings.md at 442a564.
- Cannot be determined read-only:
  - U30's landed state (TestFlags, code 20, the gc row, R-32's levels).
  - The base times and the scenario-job growth.
  - Any tiny timeout rounding to 0 ms.
  - The loop-lag twin values.
  - Whether OF-217's EPERM reaches any connect site beyond the two named files.

8. BLOCKS (lead, 2026-10-20). Owner, 2026-10-20: "81% of re-reading really is much, try to improve here as you suggested. But don't cut back on quality or depth ever." and "And yes, do smaller packing and try to use fresh agents in most cases."
- Each block is a fresh agent of about 60-80 tool calls. It starts from the previous block's hand-back (extracted to S/u31/handbacks/) and the tree; it does not re-read earlier blocks' packet steps. A lane's blocks run one after the other, so concurrency is unchanged.
- The seams are the published commits and file groups; no file is split across two blocks of one lane:
  - C1: <CORE> (asy_base_classes.py) and its test. C2: the sleep-form guard (test_src_sleep_forms.py) and buildgen/validate.py with its two tests. C3: asy_system_service.py (OF-26, OF-29's half and the helper), _sensortask_scenarios.py, test_reset_reasons.py if R-17 applies, then C's full checks.
  - S1: <LED> (neopixel), notification and the five integration files' `neopixel_dt` writes. S2: i2c and bmp3xx with their tests. S3: scd30, the hazard edges, the sgp40/isl29125 checks, then S's full checks.
  - W1: <NET> (asy_wifi_service.py, its tests, test_neopixel_wifi_integration.py, test_hotspot_role_reversal.py). W2: asy_udp_socket.py and asy_captive_dns.py with their tests. W3: asy_webserver_service.py, its two test files and the twin integration file, then W's full checks.
  - F and T: one block each, with CHECKLIST item 21 as the valve.
  - D1: the F.3 table and test_timing_budget.py. D2: A.7, C.9.1, D.4/D.5, E.9, F.1-F.3. D3: I.3, L.3, CLAUDE.md, BACKLOG.md, both READMEs, then D's full checks.
- Quality stays whole: the last block of each lane runs the lane's complete check list from section 2 at both stages over every file of the lane, not only its own block's, and its silent-failure scan covers the lane's whole file set.
- Reuse: a block goes to the previous block's agent only when that agent's history is directly relevant to it, and then the message first tells it to compact its context; the lead confirms the drop in its transcript, else a fresh agent takes the block.

9. U30 CARRIES (lead, 2026-10-20)
- OF-222 to lane C, block C3 (the next holder of asy_system_service.py, REGISTER:699): a C-stack overflow at a lock's `release()` leaves the lock held; the escalation's entry write (`asy_system_service.py:537` at U30's head) then waits forever and the watchdog reboots with no code 20. Seen failing first (an escalation whose entry write waits on a held lock must still reach `_reboot()` within the watchdog's budget and leave code 20), then a bounded wait on that write. Pre-existing; F1b's finding (b), read from the code.
- Base: U30's squash. Regenerate the packet from it at L0 and re-verify every line above; U30 moved lines in 10 of U31's 12 src files.
- L0 (lead, 2026-10-20): the packet regenerated on the U30 tree (`S/u31/tools/step_packet.py`, the U28 form) is byte-identical to `pk/U31.md` (67 steps, 100 changes), so it stands. Steps 18 and 24 are landed by U30 (`scripts/_check_gc_collect_sites.py`'s `loop_stretch_timing.py` `_main` row; every `src/asy_captive_dns.py` broad handler reports first, :104, :133, :143, :195) and join the landed set. Lane excerpts `pk/lanes/lane_<L>.md` (`S/u31/tools/lane_excerpts.py`): each of C, S and W reads step 17's head and only its own changes (C: M.SRC_CORE.016, M.TSC.128; S: the 16 M.SRC_SENS; W: the 14 M.SRC_NET). Base: U30's squash plus its CI fix (the cross-browser installer, no test file a lane grows).
