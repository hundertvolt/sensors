# U35 lane plan (P1a-P1d and P2, agents, 2026-10-21; read-only at 1dd6dd5). LEAD NOTES at the end.

## P1a

# U35 plan, block P1a: steps 1-45 (agent, 2026-10-21; read-only at 1dd6dd5)

I used about 70 tool calls and covered all 45 steps. Every line number is at `1dd6dd5` in `S/wt-u33plan`, except `tests/test_asy_neopixel_driver.py`, which I read at `970b63b` (copied to `S/u35/plan_scratch/a/neo_970.py`). My helper scripts are in `S/u35/plan_scratch/a/` (wo.py, wo2.py, has.py). The order in the work order (U35 `order[0:45]`) matches the packet's step order. Nothing in the tree was edited.

Tags used in the table:
- **[UART]**: the step edits `src/asy_uart_comm.py` or `UART_C_PORT_CHANGELOG.md`. None of these steps changes an emitted byte, an accept/reject rule or a recovery timing; all are comments or Class B "no C impact" rows.
- **[TAG]**: the step adds or removes a `# @tunable` tag.
- **[CAT]**: the step adds or removes a row in `error_catalog.json`.
- **[TWIN]**: the step changes an input of `tests_hardware/twin_record.json`, so that file must be re-recorded.

Verdict counts: landed 16 (1, 2, 7, 11, 12, 13, 14, 15, 16, 18, 19, 30, 31, 33, 38, 42), check-only 1 (17), to write 6 (21, 22, 23, 32, 36, 39), part landed 22. Steps 3, 5, 6 and 7 also need the bench.

## 1. Step table
| # | M.ID | files | verdict | evidence at 1dd6dd5 |
|---|---|---|---|---|
| 1 | HW_BENCH.050 | tests_hardware/error_log_helpers.py | landed | Docstring :1-3. `code` re-export :15-16. Comment and both tags :47-52. `reset_all_error_logs(dut_ip, reason)` calls `save_errcount()` first (:159-162). `save_errcount` is at :170-173. |
| 2 | HW_BENCH.052 | same | landed | `_nonempty` is gone (no match in tests_hardware or tests_scripts). The `clean` helper and its comment are at :78-83; the only wording difference is "deliberately". |
| 3 | HW_BENCH.068 | tests_hardware/bench/test_end_to_end_timing.py **[TWIN]** | part landed; hardware R1, the backup-reset test R3 H68 | Already done: burst probe :112-113; banners :117-119, :126, :128; owner tag :132; reasons :140, :171; `recover_by_reset` :155, :167; `persistence_write` :138. **Left (A.U35.40 (1))**: :159 `assert_module_error_log_empty(dut_ip, "FRAM")` becomes `assert_module_error_log_clean(dut_ip, "FRAM", allowed_warnings=(code("W", "FRAM_BLOCK_INVALID"),), allowed_errors=(code("E", "FRAM_STATUS_BYTE"),))` with the owner comment. The import at :12 gains `assert_module_error_log_clean` and `code`. The code mapping is in section 4, item 2. |
| 4 | HW_BENCH.131 | tests_hardware/README.md | part landed | Fold (1) bullets are at :1283-1298, under the heading at :1020. **Left (U35)**: the torn-write bullet. It is absent: `test_real_hard_resets…` appears only at :1870, in another section. U36's parts are also still open: the hotspot-fallback bullet (absent) and the BACKLOG session citation at :1224. |
| 5 | HW_DEV.090 | device_scripts/bus_topology_autodetect_and_hazard_sweep.py, device_scripts/_shared/bus_reader_loops.py **[TWIN]** | landed + OF-02/OF-05 to write; hardware R1 (H73 rerun) | Already done: constants :40-46; `BENCH` :128-130; `recover()` step :92-101; heater-off :165-167; fact keys :174; fold facts :180-182; host asserts in flash/test_bus_concurrency.py:243-245. The open findings are in section 3. |
| 6 | HW_DEV.092 | device_scripts/bmp3xx_alone_survives_a_general_call.py; tests/test_bus_hazard_multi_device.py | part landed; hardware R1 H29 | The script was added at U26 (`0c0ad52`): `arm()` :43, `BENCH` :44-47, general call through `I2CDevice(i2c, 0x00)` :61, facts :76-82, `done()` :87. The twin record has its entry at twin_record.json:182. **Left (A.U35.21 (3))**: delete the mock test `test_general_call_absent_sibling_bmp3xx_alone_on_the_bus_survives_a_broadcast_too` (test_bus_hazard_multi_device.py:248-289). |
| 7 | HW_DEV.080 | tests_hardware/flash/test_bus_concurrency.py | landed; hardware R1 H29 | Timeouts :24-37. Markers :98, :200-202. PRST comment :218. Sweep facts :232-245. New tests :250, :267, :339, :358. CS comment :291. Bench-counterpart lines throughout. |
| 8 | HW_BENCH.117 | tests_hardware/README.md | part landed | Already done: c_stack_budget :791, loop_stretch :805, flash_write_loop_gap :815, held SDA :921, sgp40 cadence :1322, and the F.3 rows line :836-839 (it says "Four", not "three"). **Left (U35)**: no bullet for `bmp3xx_alone_survives_a_general_call.py`, and :1737-1739 still credits the topology script's self-hazard branch for the lone-BMP case. Rewrite that bullet to name the script (L3, no write, no flash cycle, ungated). |
| 9 | SPEC.054 | SPECIFICATION.md | part landed | Already done: :3139-3145, :3150, :3161-3164, :3171-3177, :3181, :3187, :3195. **Left (U35, stage 7)**: :3158-3161 "`ConfigManager` carries three defensive catches … — don't remove them, covered independently by `tests/test_asy_config_manager.py`." becomes "Type mismatches are rejected statically: …". The scope paragraph ("one explicit scope", absent) is U36's. |
| 10 | SPEC.065 | SPECIFICATION.md | part landed | Already done: :3845-3859 owner decision with heater-off; :3861 standing rule; :3867 recovery ladder; :3933 every writer; :3955 `98dc1b2`; :3981, :3984. **Left (U35)**: in :3845-3859, add "a flash-tier script checks that a BMP3XX alone on its bus keeps its configuration and readings across the broadcast" (REGISTER:476 parks this for U35). U36's parts are open too: "derived, never listed" (absent) and "Session 6.2" at :3994. |
| 11 | SPEC.083 | SPECIFICATION.md | landed (check-only) | E.6.6 table :5502-5530. The lone-BMP case is in the `flash-only-bus-checks` row at :5522. |
| 12 | SRC_CORE.036 | src/asy_base_classes.py | landed | :400-430: no `logger=`; `module.max_error` tag :404; `_data_lock`, `_set_lock`, both callback dicts, ladder state, `_timer_error`. `tests/test_asy_base_classes.py` has no `logger=`. |
| 13 | SPEC.071 | SPECIFICATION.md | landed (U35 part) | :4301-4302 "before `make_logger()`". A.U22.02 has landed: no `last_value` or `.triggered` in src, buildgen, digital_twin or the test. U36's parts are open: :4278-4280 and :4308-4309. |
| 14 | SRC_CORE.048 | src/asy_config_manager.py | landed | :71, :75, :342-358, :360-369, :428-459, `get_dict` KeyError only at :443. A.U35.43 (1) is done: comment :394, test test_asy_config_manager.py:2912. A.U35.43 (2) is done: excepts :404, :530, :588, :618 carry no TypeError or AttributeError. See section 4, item 13. |
| 15 | SRC_CORE.090 | src/asy_fram_manager.py | landed | :454-495, with the narrowing comment at :464-465. |
| 16 | SRC_CORE.087 | same | landed | :507-620: tuple order, `utc_now()` :565/:600, the bare pack and unpack at :614/:553, the signed-age comment :567, narrowings :534, :550, :617. |
| 17 | GEN.034 | buildgen/error_catalog.json **[CAT: none]** | check-only | U35's only part is retiring the timestamp-pack code, and no such row exists: it is absent at U2 (`43aced0`) and now. Rows from other stages are present: E25, E28, W69, E91-93, W80, E65 retired, ResetReason 20/21. `FRAM_FULL` is absent; that is U16's stage. |
| 18 | SRC_CORE.101 | src/asy_fram_driver.py | landed | :38-114: `const()` command bytes, tags :74-81, status bits, codes. |
| 19 | SRC_CORE.107 | same | landed | `verify_present()` :477-502: `wait_for_ms` :485, no `id_error`. There is no errno-98 row (E98 absent). |
| 20 | SRC_CORE.116 | src/asy_crc_checks.py | part landed | Already done: tag :8, `_crc(…, poly)` :33-36, `_crc_wide` :52-74, callers pass `self._poly` at :89, :108, :124, :142, :170. **Left**: delete :37-38 `if self._poly is None: return crc` (REGISTER:336). |
| 21 | SRC_CORE.117 | same | to write | Bounds-first is already done (:100-103, :133-137). Unwrap the `try`/`except ValueError` around `pack_into` at :91-95 (`add()`) and :109-113 (`add_into()`). |
| 22 | DOCS.024 | UART_C_PORT_CHANGELOG.md **[UART]** | to write (U35 row) | The table holds B1-B86, numbered by landing order, which differs from the packet's numbers. **Left**: a new row after :209 (B87): "`CRCBase._crc()` takes the polynomial its caller already checked, and `add()`/`add_into()` no longer wrap `pack_into` in an unreachable catch \| No emitted byte changes" (Class B, `applied-python`). |
| 23 | SRC_CORE.131 | src/asy_crc_checks.py (+ tests/test_asy_crc_checks.py) | to write | :24-28 sets `_num_bytes` before validating the polynomial, so an out-of-range poly still reports `length() == num_bytes`. Fix: compute the mask, check the poly against it, then set every width field from the result. Add one test per width. **[UART]**: no valid config changes, since a TOML can select only `none` or `crc16`. I propose a Class B row B88 (agent, 2026-10-21; the changelog logs Python-internal changes too). |
| 24 | SRC_NET.164 | src/asy_uart_comm.py **[UART: comment only]** | part landed | Already done: sync `_note_valid_frame` :629-632, its call sites, owner tag :1021. **Left**: at :1007 `if buf is None:`, add "# Unreachable: _prepare_tx() returned False if the TX buffer were missing - kept to narrow the Optional for the type checker." (the premise holds at :664-666). |
| 25 | SRC_NET.166 | same **[UART: comment only]** | part landed | **Left**: comment at :758 `if err or rx is None:` covering the `rx` half (the premise holds: `_read_frame` returns False on a missing RX buffer, :723-725). Comment at :783 `if not fits:`; see section 4, item 10. |
| 26 | SRC_NET.167 | same **[UART: comment only]** | part landed | Already done: gate first :1104, shared-tail comment :839, stream comment :1191, B71 at changelog:194. **Left**: complete the inline comment at :1110 with "- kept to narrow the Optional for the type checker." |
| 27 | SRC_NET.168 | same **[UART: comment only]** | part landed | Already done: `exp` :578, `_note_valid_frame()` :586. **Left**: comment at :575 `if rx is None:`. Add the same comment at :712 (`_read_answer_header`), which A.U35.47 does not list; this follows D.10 (agent, 2026-10-21). |
| 28 | TEST_HELP.026 | tests/_bus_hazard_catalog.py | part landed | Already done: public reserved ranges :40-44, `reset_id` :55, BMP constant :103, ERR_REG and EVENT seeding :114-122, `exercise_raises` :171, heater-off :269, altitude :355. **Left (U35, item 5)**: `releases_bus_mid_read` (True for sgp40) and `default_address` on `I2CHazardAdapter` (:158-180). U36's item 8 is open: comment :343-344. |
| 29 | TEST_HELP.027 | same | part landed | Already done: every writer :489-497, both Skips :494/:590, SPI catalog :401-407, recovery scenario :721, sweep :740-763, C.8 tag :585. **Left (item 5)**: `sibling_inside_window()`; the `switches >= len(occupants)` floor at :456-457 should apply only to buses with no flagged occupant. |
| 30 | TEST_HELP.052 | tests/_fast_sleep.py | landed | `FastAsyncSleep` :26-35. Its parameter is `clock`, not a per-caller count. |
| 31 | TEST_HELP.064 | tests/_ticks30.py | landed | :20-38. |
| 32 | TEST_HELP.065 | new driven clock + self-test | to write; name conflict | See section 4, item 7. |
| 33 | TEST_HELP.011 | tests/machine.py | landed | :1369-1509: WDT bound :1369, `feed_times`, the `Simulated*` classes, `mem_backup`, `power_on`, both registers :1429-1430. |
| 34 | SPEC.111 | SPECIFICATION.md | part landed | The watchdog entry is at :7470-7481 and its shutdown-ownership part has landed. **Left (U35)**: A.U35.30's sentence naming the planted-failure scenarios, which do not exist yet. Also absent is item 10's shared-codec sentence ("Each driver constructs its own codec"); the packet gives it to "U35/U36", and I propose U35. |
| 35 | TEST_HELP.022 | tests/_fram_chip_fake.py | part landed | Already done: `drop_next_wren` :42, `write_transactions` :61 (A.U35.28's counter), page citations, sizes as `SIZE` plus the subclass at :157. **Left**: `cut_after_bytes`/`bytes_written` (a local copy exists at test_asy_system_service.py:1043-1079), the opcode `match=` key, ":100 '1.29'" → "v1.29.0", and `TEST_API`. |
| 36 | TEST_HELP.067 | new tests/_cancel_sweep.py | to write | Absent. It depends on step 38, which has landed. |
| 37 | SPEC.064 | SPECIFICATION.md | part landed | Already done: lock table :3770, :3756-3757, :3811, cancellation paragraph :3836-3843. **Left (U35, item 5)**: "A test sweep cancels every such path at each of its awaits (agent)." Also left from U16: :3794 "(owner's decision, 2026-09-18)" → "(owner, 2026-09-18)". |
| 38 | TEST_HELP.043 | tests/_async_harness.py | landed | `cur_task` refusal :91, tracking :95-96, `cancel` :223, `cancel_all` :234, `run` :248, `run_timed` :253, `CoroutineOf` :22. |
| 39 | TEST_UNIT.016 | tests/test_asy_bmp3xx_driver.py | to write | The test is at :1410-1435 and only counts acquires; its comment :1415-1417 says the interleaving "can't be reproduced". Fold (1) has landed at :1399. |
| 40 | TEST_UNIT.028 | tests/test_asy_dns_client.py | part landed | Tags :44-54, constructed asserts :410/:542/:552/:584/:594, mask comment :430, :503, :545, :678 and :737 have landed. **Left**: `test_cancelling_a_resolve_at_each_await_leaves_no_socket_open`, which needs step 36. |
| 41 | TEST_UNIT.034 | tests/test_asy_fram_driver.py | part landed | The lost-flag assertions have landed. **Left**: the lock-busy test (:1010-1048) runs `_RecordingWaitFor` on a real 1 ms bound; it should run on the driven clock: `advance(999)` not done, then `advance(1)` gives False. |
| 42 | TEST_UNIT.043 | tests/test_asy_fram_manager.py | landed | Order :970/:989/:1077/:1769; :2364, :2373; negative age :3003; the four removed tests are gone. |
| 43 | TEST_UNIT.079 | tests/test_asy_neopixel_driver.py (970b63b) | part landed | :228/:268, :300, :941, :1203, :1213 have landed. **Left (A.U35.13)**: replace the local `_YieldOnlyAsyncio` (:59) and `_DrivenClock` (:92) with the shared clock. |
| 44 | TEST_UNIT.080 | same | part landed | :545-556, :580, :675, :708, :733, :784, :814 and :898 have landed. **Left**: real sleeps at :497 `sleep(1.5)` and :512 `sleep(1.1)` move to `advance`; :628 `>= 30` becomes `== 31`. |
| 45 | TEST_UNIT.082 | tests/test_asy_notification_service.py **[TAG]** | part landed | Imports :7-19, `ValueRef` :148, `_FakeValue` :70 and shared `FakeTime` have landed. **Left**: `_make_coordinator` (:129, 64 uses) becomes `_make_service` (drop `debug=`, call `setup()`); `_one_cycle` real `sleep(wait)` at :166, and :1024/:1220/:1254, move to driven time. Decide per literal which tags at :35-42 and :152 go with their literals (Part N rows withdrawn, A.U35.13 Blast); `_MAX_ROUNDS` stays as the hang guard. |

## 2. Carried actions
| Action | Steps | State |
|---|---|---|
| A.U35.40 | 1, 2, 3, 4 | Parts (1) and (4) are left (steps 3 and 4). (2) and (3) have landed. |
| A.U35.50 | 5, 7 | This is the four-tier matrix in `audit/b3/conformance.md`; `audit/b3/` does not exist yet. It goes with the B3 working files (A.U35.01). |
| A.U35.21 | 6, 7, 8, 10, 11 | (1), (2) and the E.6.6 row have landed. Left: (3) the mock deletion, the README line and the C.8 sentence. |
| A.U35.09 | 7 | The L2 scenarios go in `scripts/_digital_twin_scenarios.py` plus the matrix row. They are outside this block's files; P2 places them with the twin lanes. |
| A.U35.43 | 9, 14 | Code and test have landed. The SPEC sentence is left (step 9). |
| A.U35.45 | 12, 13 | Landed. |
| A.U22.02 | 13 | Landed. |
| A.U35.47 | 15, 16, 24-27 | The FRAM half has landed. The UART half (5 comments + :712) is left. |
| A.U35.55 | 16, 17, 42 | Landed. There was no catalog row to retire. |
| A.U35.42 | 18, 19 | The FRAM half has landed. **The math_helpers half is left**: there are no stand-in tests in `tests/test_math_helpers.py` (P2: grep ArithmeticError there). |
| A.U35.44 | 20, 21, 22 | All left. |
| A.U35.16, A.U35.19 | 28, 29 | Left: the hand-written floors at test_bus_hazard_multi_device.py:130-131/:173-174, and the reserved test :689-691 still using constants. |
| A.U35.10 | 30, 31, 32 | Left: step 32. |
| A.U35.30 | 33, 34 | Left: the four scenarios in `tests/_sensortask_scenarios.py` and the G.2 sentence. |
| A.U35.28 | 35 | Its write counter has landed. The load ledger and scenario sit outside this block's files. |
| A.U35.48 | 36, 37, 38, 40 | Helper, SPEC sentence and DNS sweep are left. |
| A.U35.11 | 39 | Left. |
| A.U35.13 | 43, 44, 45 | Left. |

## 3. Open findings in this block's files (REGISTER rows too)
- **OF-02** (open). bus_topology…py:114-120 `except OSError: pass`: a NAKed general call is swallowed. Joins step 5. Fix: count sent and NAKed broadcasts as facts (as bmp3xx_alone…py:76-78 does), and have the host test (flash/test_bus_concurrency.py:232-245) require at least one sent.
- **OF-05** (open). _shared/bus_reader_loops.py:79-81: `read_scd30` returns None after any `read_measurement()`. Joins step 5. Fix: range-check against `BENCH["bounds"]`, as the BMP reader at :89-93 does. The shared reader feeds other scripts too, so re-record the twin record.
- **OF-81** (open). asy_base_classes.py:115-128 `Lockable.__aexit__` swallows `RuntimeError`. Joins step 36: the sweep's lock invariant plus a pin in tests/test_asy_base_classes.py, which a later block holds; P2 joins them. The row asks for a pin, not a product change.
- **OF-167** (open, routed to U35 by M.SRC_CORE.087/.090; steps 15/16 have landed). A blank-chunk read cannot be told from an undriven bus (asy_fram_manager.py:28, :197). P2 to decide. The smaller option is an RDID probe via `verify_present()` on a blank read; a non-zero blank marker changes the FRAM layout and needs a migration. It must be seen failing first against the twin's undriven level (digital_twin/_fram_chip.py:266-267).
- **OF-60** (open, C R2 H17). Its read-path probe option sits with these steps. Not done (agent, 2026-10-21): the silicon latency is not measured yet; it is the same decision as OF-167.
- **OF-70** (open, C R2 H37). A comm-side cause string only if the bench shows it is needed. Parked as hardware; the bench session runs after U35 (REGISTER:722).
- **OF-225** (open). The config flush in asy_config_manager.py is one non-yielding stretch. Chunking it re-derives J.6's `uart.rx_ring_floor`, a local construction refusal (B68), not the wire. It is not on step 14's sites; give it to the config-manager lane (P1b step 82 holds the file).
- **OF-232** stays with U37: its source module has no U35 edit; only its test is touched (step 45).
- **REGISTER:336**: the `_crc()` guard was left for U35 → step 20.
- **REGISTER:476**: U15 lane D 19, the BMP3XX broadcast sentence → step 10.
- **REGISTER:233**: local stand-ins until the shared helpers land → steps 32 and 43-45.
- **REGISTER:691/:722**: firmware is final at U35's end. The firmware edits in this block are steps 20, 21, 23 (asy_crc_checks) and 24-27 (comments in asy_uart_comm). Added comment lines shift the line tables in the frozen bytecode; behaviour is unchanged.

## 4. Packet vs code
1. **Step 1**: the save is `evidence.save_text(f"errcount-{reason}.json", body…)`, the verbatim body, not `save_json`. The import is `from tests._error_codes import code` after appending the repo root (:15-16), not an append of `tests/`. Both forms work.
2. **Torn-write codes.** In `699836e` (`_set_check_sb`, err=30), E31 is "Read status byte is not idle but X", which is today's E46 `FRAM_STATUS_BYTE`. It is **not** the write failure (that is E102 `FRAM_STATUS_WRITE`, HEAD's E32). HEAD's W71 and W72 ("Invalid data in block 0/1") are both today's W63 `FRAM_BLOCK_INVALID` (asy_fram_manager.py:213-241). So the allowed set is one error and one warning, and the comment becomes "the status byte left busy and the block-invalid recovery warning". (agent, 2026-10-21: mapped by message identity to the owner's settled trace.)
3. **README** (steps 4 and 8): the "Real-hardware coverage: sensors, FRAM and the API end to end" heading no longer exists. The F.3 line says four rows, not three.
4. **E.6.6**: the lone-BMP case sits in the combined `flash-only-bus-checks` row (:5522); there is no `bmp3xx-general-call` row.
5. **Changelog numbering**: the tree's B33-B86 are in landing order (for example, tree B64 is the PieceBuffer chunking). U35's rows are therefore B87 and B88.
6. **Catalog**: neither the timestamp-pack code nor the errno-98 ID-check code ever had a row (absent at `43aced0` and now), so steps 17-19 retire nothing.
7. **Name conflict (step 32).** `DrivenTime` already exists at `tests/_fake_time.py:15`. It is a ticks-only clock with no sleep or `wait_for` driving, imported by 9 files (U24 `aa3530f`). The packet wants a second `DrivenTime` in a new `tests/_driven_time.py`. Conservative choice (agent, 2026-10-21; CLAUDE.md "check Part G's catalog first … reuse"; G.2): extend the existing class in place. Its time-only use stays the default; the `asyncio` shim, `advance`, `run_until`, `jump` and the `wait_for`/`wait_for_ms` shims are opt-in. Its models are the neopixel `_YieldOnlyAsyncio` (970b63b:59-105), test_asy_webserver_connections.py:249 and test_asy_webserver_service.py:367. The self-test still goes in `tests/test_driven_time.py`.
8. **Step 35**: sizes come from a class attribute and a subclass, not a `size=` keyword. The power cut is a local subclass in test_asy_system_service.py.
9. **Step 30**: `FastAsyncSleep(clock=…)` is the parameter, not a per-caller count.
10. **Step 25**: the dest bound moved to :776-785 (U17's PieceBuffer). It is still unreachable: `_get_unlocked` refuses a short caller buffer at :279-281, and `_recv_train` bounds the copy by `exp_size` at :763. There is no Optional here, so the comment cannot say "narrow the type". Proposed comment: "kept: it guards the copy into a caller's buffer" (agent, 2026-10-21).
11. **Step 14**: test_asy_config_manager.py:1981 (the non-dict data test) pins `compare_before_write()`'s BAD_ARG. That guard is not among A.U35.43's removed excepts, so the test is kept (agent, 2026-10-21).
12. **Already done by earlier units**: steps 6 and 7 at U26 (`0c0ad52`); 12-19 at U11/U16; 33 and 38 at U24; 42 at U16.
13. **Not determinable read-only**:
    - The H29 and H68 results (bench).
    - Whether driven frame counts equal `_YieldOnlyAsyncio`'s; running the neopixel and notification files at both GC stages settles it.
    - Which notification tags lose their literal; settled at the edit.
    - Whether `tests/test_math_helpers.py` already has stand-in tests; a grep settles it.

## 5. Files (current names → steps)
- tests_hardware/error_log_helpers.py: 1, 2
- tests_hardware/bench/test_end_to_end_timing.py: 3
- tests_hardware/README.md: 4, 8
- tests_hardware/device_scripts/bus_topology_autodetect_and_hazard_sweep.py and device_scripts/_shared/bus_reader_loops.py: 5 (OF-02/OF-05)
- tests_hardware/twin_record.json (re-record): 3, 5
- tests/test_bus_hazard_multi_device.py: 6, 28/29 (A.U35.16, A.U35.19)
- SPECIFICATION.md: 9, 10, 34, 37 (11 and 13 check-only)
- src/asy_crc_checks.py and tests/test_asy_crc_checks.py: 20, 21, 23
- UART_C_PORT_CHANGELOG.md: 22 (and 23's row)
- src/asy_uart_comm.py: 24-27
- tests/_bus_hazard_catalog.py: 28, 29
- tests/_fake_time.py (+ new tests/test_driven_time.py): 32
- tests/_fram_chip_fake.py: 35
- tests/_cancel_sweep.py (new): 36
- tests/test_asy_bmp3xx_driver.py: 39
- tests/test_asy_dns_client.py: 40
- tests/test_asy_fram_driver.py: 41
- tests/test_asy_neopixel_driver.py (base 970b63b): 43, 44
- tests/test_asy_notification_service.py: 45
- tests/_sensortask_scenarios.py: 34 (A.U35.30)
- tests/test_math_helpers.py: 18/19 (A.U35.42)
- No U35 edit needed (landed): src/asy_base_classes.py, src/asy_config_manager.py, src/asy_fram_manager.py, src/asy_fram_driver.py, buildgen/error_catalog.json, tests/machine.py, tests/_async_harness.py, tests/_fast_sleep.py, tests/_ticks30.py, tests/test_asy_fram_manager.py, the flash test and the lone-BMP script.

## P1b

P1b record, U35 steps 46-110 (agent, 2026-10-21). Tree: S/wt-u33plan at 1dd6dd5; tests/test_asy_neopixel_driver.py read as 970b63b. All 65 steps were located; ~68 tool calls. Paths are repo-relative. "nsd" = notification service test, tests/test_asy_notification_service.py.

## 1. STEP TABLE

| # | M.ID | file(s) edited (current names) | verdict and evidence |
|---|---|---|---|
| 46 | TEST_UNIT.088 | tests/test_asy_notification_service.py | **part landed.** Landed: :988 renamed tuple-order test; fold (1) `test_the_sample_reports_why…` :1566; fold (2) :658. **Left (driven time):** `_one_cycle()` :162-170 still does `await asyncio.sleep(wait)` with the 3-line "real wall-clock time" comment; waits 3.5/1.2 s at :941,:959,:981,:1001; `test_flashes_run_strictly…` still sleeps 0.05/1.3 s at :1021,:1024 |
| 47 | TEST_UNIT.089 | nsd | **part landed.** Landed: `_in_window` table :1088; 23:30 cycle :1103; clock-step test :1128; CALLBACK :1184; `"FlashDur": 0.01` gone. **Left:** the gating tests still use `_one_cycle`'s real 0.1 s default (:1053,:1082,:1143,:1162,:1179,:1197) |
| 48 | TEST_UNIT.090 | nsd | **part landed.** Landed: `src_int(...,"_MAX_OVERRIDE_TIME")` :1280; `_OVERRIDE_SECS` tagged :37-38. **Left:** real sleeps 0.05/1.1/0.05 at :1216,:1220,:1224 and :1252,:1254,:1260. **Tag removal:** `# @tunable l1.asy_notification_service_override_bound_ms = 3200` :40-41 and its Part N row (3 SPEC hits) are withdrawn with the literal |
| 49 | TEST_UNIT.092 | nsd | **part landed.** Landed: `test_no_signals…` :1358; one CALLBACK slot :1395; the pre-finalize test is gone. **Left:** real `sleep(0.1)` :1366; the cb-raising cycle still real |
| 50 | TEST_UNIT.103 | tests/test_asy_ntp_client.py | **landed**: `_FakeUDPSocket` :1266; forwards test :1306; NTP_NOT_SENT :1337; SOCKET_TEARDOWN :1344; cancelled fetch :1356; `ready.wait()` :1399; 48-byte reply :1407; ipoll comment :375; tags :93-:108; invalid-addr tests gone |
| 51 | TEST_UNIT.037 | tests/test_asy_fram_driver.py | **landed**: event gate :1557-1572; limit comment :1608; typed `capture` :1694 (no noqa); codes :1713 |
| 52 | TEST_UNIT.076 | tests/test_asy_isl29125_driver.py | **part landed.** Landed: `_gather` typed :4024; comment cut :4062-4063; new tests :4088,:4118,:4143. **Left:** :4046 `await asyncio.sleep(0)  # let the reader get partway…` becomes an Event gate; :4075 comment becomes "# one yield lets configure() park on the held lock (a limit, not an interleaving claim)" |
| 53 | TEST_UNIT.078 | tests/test_asy_neopixel_driver.py (970b63b) | **part landed.** Most scenarios already run under the file-local `_DrivenClock` (:92-105, the shared `_fake_time.DrivenTime` plus `_YieldOnlyAsyncio` :61-89). **Left:** 15 real sleeps at :396,:429,:445,:466,:479,:497,:512,:643,:661,:664,:666,:1024,:1061,:1084,:1099; the :1183 comment becomes "a limit"; `cancel_all` is used where the packet says `cancel(*tasks)`. **Conflicts** (stale packet text): it drops `debug`, but `_event_driver()` passes `debug=4` (:55); it writes `_neopixel_freq`, but the product attribute is `neopixel_freq` (src/asy_neopixel_driver.py:83) |
| 54 | TEST_UNIT.106 | tests/test_asy_ntp_client.py | **landed**: `_refresh_loop` tests :1741-1831; `_FIRED_PROBE_S` :95-96,:1780; `_ASYNC_INTERVALS` :88-89; stale :1852; inverted :1870; age restart :1899; due counter :1923 |
| 55 | TEST_UNIT.110 | tests/test_asy_ntp_client.py | **part landed.** Landed: :2526,:2602,:2624,:2639. **Left:** `test_the_sync_task_survives_a_cancel_at_every_await`; it needs tests/_cancel_sweep.py, which is absent |
| 56 | TEST_UNIT.111 | tests/test_asy_ntp_client.py | **part landed.** Landed: redirect :2719; shared server :311-314; tags :97-115. **Left:** `await asyncio.wait_for(…, 5)` at :2723,:2775,:2813,:2827 becomes `assert await server.serve_once(reply) is True`. Lands after step 57 |
| 57 | TEST_HELP.058 | tests/_ntp_frames.py | **part landed.** Landed: shared builder :14-16. **Left:** `async def serve_once(self, reply: "bytes | None") -> None:` (:36) gets the bool return: `return True` after answering (:47), `return False` once the budget runs out. The constructor is `FakeNtpServer(port, *, poll_ms, poll_tries)` (:22): the caller owns the budget |
| 58 | TEST_UNIT.124 | tests/test_asy_scd30_driver.py | **part landed.** Landed: wire names :2291-2293; `_gather` :2285. **Left:** :2340 `await asyncio.sleep(0)  # let the reader get partway…` becomes an Event gate |
| 59 | TEST_UNIT.166 | tests/test_asy_uart_comm.py | **part landed.** Landed: `session_lock` :3094,:3111. **Left:** write the sweep test. UART: test only; no emitted byte, accept/reject rule or recovery timing changes |
| 60 | TEST_UNIT.171 | tests/test_asy_uart_driver.py | **to write.** :988-990 `await asyncio.sleep_ms(400)` becomes an un-set Event, with cancel in `finally`; add the one comment line. `_SHORT_CANCEL_ACK_MS` is already tagged (:52-53). UART: test only, no wire/rule/timing change |
| 61 | TEST_UNIT.177 | tests/test_asy_uart_driver.py | **to write** (new sweep). UART: test only |
| 62 | TEST_UNIT.184 | tests/test_asy_uart_link_driver.py | **to write** (new sweep). UART: test only |
| 63 | TEST_UNIT.187 | tests/test_asy_udp_socket.py | **landed**: `_FIRST_ATTEMPT_S` tag kept :84-85; no `wait_time_ms`; withdrawn IDs absent from file and SPEC |
| 64 | TEST_UNIT.190 | tests/test_asy_udp_socket.py | **part landed.** Landed: disconnect test :1594-1617. **Left:** the join test :1631 `await asyncio.sleep(_FIRST_ATTEMPT_S)` moves to driven time with `run_until` then `advance(500)`. That needs an asyncio shim, which the tree's DrivenTime lacks (§4) |
| 65 | TEST_UNIT.193 | tests/test_asy_udp_socket.py | **to write** (new sweep) |
| 66 | TEST_UNIT.208 | **moved:** tests/test_asy_webserver_connections.py | **landed (U19 form)**: :968 (file-local `_DrivenClock`); :1038; `_EagainWriter` :206. **U35 part, open:** swap in the shared driven clock. It depends on the §4 DrivenTime decision; until then **check-only** |
| 67 | TEST_UNIT.209 | the webserver tests | **to write** (sweep over `_serve()`). File choice (agent, 2026-10-21): use test_asy_webserver_connections.py, which holds `_serve()`'s reader/writer doubles. A.U35.48 names test_asy_webserver_service.py |
| 68 | TEST_UNIT.214 | tests/test_asy_wifi_service.py | **landed**: `_release_wifi_lock` gone; :1684-1687; :1775; :2469; parks stated as "a park" (:861,:1380,:1417,:1421) |
| 69 | TEST_UNIT.219 | tests/test_asy_wifi_service.py | **landed**: power-cycle comment :3152; QTYPE comment :3960; one status call :4668. The shared-WLAN assertions are **check-only** |
| 70 | TEST_UNIT.220 | tests/test_asy_wifi_service.py | **landed**: `PortAllocator` :3950-3953; ordered proof :3977; `# ----` dividers; `_CONNECT_BOUND_S` :66; `_FLASH_CANCEL_BOUND_S` :82 |
| 71 | TEST_UNIT.221 | tests/test_asy_wifi_service.py | **to write** (sweep) |
| 72 | TEST_UNIT.226 | tests/test_asy_base_classes.py | **landed**: `logger=` tests gone; one log path src/asy_base_classes.py:412; tests :1015,:1695 |
| 73 | TEST_UNIT.234 | tests/test_bus_hazard_multi_device.py, tests/_bus_hazard_catalog.py | **part landed.** Landed: chip-id loop :83-88; fold (1) through catalog :293-296,:336. **Left:** `switches >= 2` at :131,:174 becomes `sibling_inside_window`. That helper is absent from the catalog (M.TEST_HELP.027) |
| 74 | TEST_UNIT.235 | tests/test_bus_hazard_multi_device.py | **part landed.** Landed: L3 script; tests_hardware/flash/test_bus_concurrency.py:267; twin_record.json:182. **Left:** delete `:219 assert all(entry[1] != _BMP_ADDR …)` with its comment, and the test at :248-~290. **Hardware:** R1 H29 |
| 75 | TEST_UNIT.127 | tests/test_asy_sgp40_driver.py | **landed**: :297, :309-326, :329-338 |
| 76 | TEST_UNIT.236 | tests/test_bus_hazard_multi_device.py, tests/_bus_hazard_catalog.py | **part landed.** Landed: datasheet oracle :640-659; fold (1) :337,:364. **Left:** :291 test gets `wait_for(…,_ISOLATION_BOUND_S)` plus `bus_lock` asserts (**adds tag** `l1.bus_fault_isolation_bound_s = 5` and its Part N row); :689-691 reserved-address test still loops the hand-kept :64-67, and needs adapters' `default_address` (none on `I2CHazardAdapter` :158) |
| 77 | TEST_UNIT.237 | tests/test_bus_hazard_multi_device.py | **to write**: :699-750 and :753-786 are still SPIDevice/sync-worker forms; no `FRAM_SPI` used |
| 78 | TEST_UNIT.152 | tests/test_asy_spi_driver.py | **landed**: :773-796 |
| 79 | TEST_UNIT.248 | tests/test_asy_captive_dns.py | **to write** (sweep; `_FakeUDPS` :408) |
| 80 | TEST_UNIT.255 | tests/test_asy_config_manager.py | **landed**: :1633, :1641. The CONTRACT counts at the other sites are **check-only** |
| 81 | TEST_UNIT.257 | tests/test_asy_config_manager.py | **landed**: `dumps` :2419; :2471,:2814,:2881,:2899,:2912,:2937; fold (1) :2952. **Conflicts**, see §4: the non-dict test :1981 |
| 82 | SRC_CORE.043 | src/asy_config_manager.py | **landed**: :325 `absent_at_boot`; :326 `unpersisted`; :527-528 dir fault; :530 `except (MemoryError, OSError)` (no TypeError); :534-535; :580; :584-589. OF-225 joins here |
| 83 | TEST_UNIT.254 | tests/test_asy_config_manager.py | **landed**: :2488, :2538, :952 |
| 84 | TEST_UNIT.260 | tests/test_asy_crc_checks.py | **landed**: imports :6,:8; `_crc(...,0x31)` :34,:40; :781,:788 |
| 85 | TEST_UNIT.262 | tests/test_asy_crc_checks.py | **part landed.** Landed: :206. **Left:** add `base.length() == 0` to :394-397, and the new pure-pass-through test. Both fail until M.SRC_CORE.131 lands: today `CRCBase(1,0x1FF,">B")` keeps `_num_bytes` 1 (src/asy_crc_checks.py:22, `length()` :155-158) |
| 86 | TEST_UNIT.274 | tests/test_neopixel_wifi_integration.py | **landed in a yield-bounded form**: `_run_until` :45-52; scenario :57-80, no sleeps; `set_ext_led` test gone. The packet's DrivenTime form and the `setup()` calls are not written; that waits on the §4 decision. **Check-only** |
| 87 | TEST_UNIT.276 | tests/test_notification_neopixel_integration.py | **part landed.** Construction landed: :61,:78-80,:119,:136-139. **Left:** real `sleep(1.3)` :125 and `sleep(2.5)` :146 |
| 88 | TEST_UNIT.278 | tests/test_notification_scd30_integration.py | **part landed.** Landed: `reset_id`, `UTCValid`, `inject_fault` :180,:214. **Left:** :135, :164, :190 (0.2 s), :242 |
| 89 | TEST_UNIT.281 | tests/test_notification_sgp40_integration.py | **part landed.** **Left:** :146, :175 (0.2 s), :218 |
| 90 | TEST_UNIT.280 | tests/test_notification_scd30_sgp40_integration.py | **part landed.** **Left:** :199 (2.6 s), :238 |
| 91 | TEST_UNIT.283 | tests/test_ntp_fram_system_integration.py | **landed**: :197-201, :226, :252, :280, :447 |
| 92 | TEST_UNIT.284 | tests/test_ntp_fram_system_integration.py | **landed**: tick with clock :310,:327,:352; :393-396; :510,:525; ValueRef :545-546 |
| 93 | TEST_UNIT.290 | tests/test_asy_print_log.py | **landed**: :295-297, :318, :238, :363, :429/:433, :546/:562, :810, :1335. One case was not located by name: "pre-setup entries kept after the stored ones" (store merge). :242 covers RAM slots only; reading the store section :827-900 settles it |
| 94 | TEST_UNIT.303 | tests/test_asy_system_service.py | **landed**: :303, :318, :431, :467, :496, :545, :569. The clock is the shared `_fake_time.DrivenTime` (:121-123); a U35 swap only if §4 changes the class. **Check-only** |
| 95 | TEST_UNIT.304 | tests/test_asy_system_service.py | **landed**: :604, :612, :620, :648, :672 |
| 96 | TEST_UNIT.309 | tests/test_asy_system_service.py | **landed**: :2722; :2951,:2982 (22 dead),:3065,:3088; :3154; :3205,:3225; :2894; :2109,:2216,:2320; :4097-4270; `_RUN_BOUND_S` :69 |
| 97 | TEST_UNIT.339 | tests/test_driven_time.py (new) | **to write.** Neither file exists. tests/test_shared_helpers.py:168-300 already self-tests `_fake_time.DrivenTime` (§4) |
| 98 | TSC.175 | tests_scripts/_devices.py | **landed**: :1-3, `bench_device` :25, `devices_with` :42 |
| 99 | TWIN.132 | tests/test_digital_twin_network_neopixel.py | **part landed.** Landed: tags :29-32; singletons :223-238; power_dip fake case :499-507; downed AP :416; chip-down :448. **Left:** negative windows `sleep(1.0)` :197,:379 become structural; the A.U22.01 test (U25 stage, absent); fold (1)'s driver case, which is absent at L1 too (`power_dip` appears only at :504) |
| 100 | TWIN.158 | tests/test_digital_twin_uart_link.py | **landed, except U35's piece:** :568-581 still runs only `uart_get(0x01)`. Add the 140-byte `uart_set(0x02, …)` asserted True while the noise tasks run. UART: test only, public API, no wire change. OF-223 site |
| 101 | HW_DEV.060 | tests_hardware/flash/test_fram_storage.py | **landed**: :1-2, :19-31, :95-104, :179. A.U35.22's part is **check-only** (:96 stays the N.28 proof). Hardware R1 H22/H72 are not in U35's rounds |
| 102 | PROC.022 + SCR.024 | audit/b3/* (new); scripts/lint.sh | **PROC.022 to write**: audit/b3 is absent. Hardware parks: H43 (R1 end, the memory-gate silicon arm), H71 (R1, silicon cells), H56 (R0, speed bands). **SCR.024 landed**: lint.sh:1-25, :99 (U35 runs it: check-only). A.U35.09/.28 scenarios are absent from the tree |
| 103 | HW_BENCH.002 | **moved:** tests_hardware/markers.py | **landed** :11-25, registered at conftest.py:97; A.U35.51 part **check-only** (conformance.md) |
| 104 | PROC.025 | audit/b3/raising.md | **to write** (procedure). The module names are right; `src/math_helpers.py` keeps its name |
| 105 | PROC.028 | Part N rows and tags | **to write.** 918 of 937 `l0`-`l4` rows read "estimated" (grep). l3/l4 rows: **hardware** H55 (R1, R4, R5) |
| 106 | SCR.006 | scripts/_run_lower_levels.sh | **landed** :1-46 (npm leg :46). **Check-only** |
| 107 | SCR.042 | scripts/test.sh | **part landed.** Landed: `_check_heavy_list` :674-683; 10-entry list :661-672; L0 test test_test_sh.py:1999. **Left:** re-order from timing.md |
| 108 | PROC.024 | scratch, audit/sweeps/ticks30_build.sh | **to write** (procedure). OF-32 joins |
| 109 | SCR.060 | scripts/_digital_twin_ci_suite.py | **landed** :919-934; **check-only** (run at both stages) |
| 110 | SPEC.018 | SPECIFICATION.md A.5 (:489-535) | **landed** (pin v2.7.0, checklist, ladder, rebind, HTTPDropped, `_StaticRoutes`); **check-only** for A.U35.36 |

**Tunable tags.** Removed: step 48 (`override_bound_ms`). Added: step 76 (`bus_fault_isolation_bound_s`), which step 77 reuses. Step 105 changes values and basis only. None at steps 53, 60, 99 (their rows are already gone). Step 56 removes nothing: `l1.asy_ntp_client_serve_wait_s` lives on in test_ntp_fram_system_integration.py:65 and test_ntp_wifi_dns_integration.py:67, so its row stays. Check at execution whether driven waits drop `l1.notification_neopixel_wait_until_timeout_ms` (tests/test_notification_neopixel_integration.py:87).

**error_catalog.json:** no step in this range adds or removes a row.

**Twin-record input:** none new; step 74's entry already exists.

**UART:** no step in 46-110 edits src/asy_uart_comm.py, src/asy_uart_link_driver.py or UART_C_PORT_CHANGELOG.md. Steps 59-62 and 100 are tests only: no emitted byte, no accept/reject rule, no timing change. A changelog Class B entry appears only if a sweep finds a defect (A.U35.48 Blast).

## 2. CARRIED ACTIONS → STEPS
- A.U35.13 → 46, 47, 48, 49, 53, 87, 88, 89, 90
- A.U35.12 → 50, 51, 52, 53, 54, 58, 68, 69, 91, 92, 95, 96
- A.U35.48 → 55, 59, 61, 62, 65, 67, 71, 79
- A.U35.15 → 56, 57 (confirmation runs at 102)
- A.U35.14 → 60, 63, 64, 70, 99
- One step each: A.U35.45 → 72; A.U35.16 → 73; A.U35.21 → 74; A.U35.17 → 74, 75; A.U35.18 and A.U35.19 → 76; A.U35.20 → 77, 78; A.U35.44 → 84 (test side only); A.U35.10 → 97 (self-test)
- A.U35.43 → 80, 81, 82, 83
- A.U35.08 → 98, 102; A.U35.22 → 100, 101, 102; A.U35.35 → 93, 102
- Step 102: A.U18.05 (its code landed at src/asy_udp_socket.py:33-35,:122-132; only the twin idle measurement is left), A.U35.01/.03/.04/.05/.09/.23/.28/.37/.41/.50/.51
- A.U35.51 → 102, 103; A.U35.02 → 102 (SCR.024), 106, 109; A.U35.36 → 104, 110; A.U35.56 → 105; A.U35.23 and A.U35.24 → 107; A.U35.32 → 108

## 3. OPEN FINDINGS IN THIS RANGE'S FILES
- **OF-81** (src/asy_base_classes.py:123-126, `__aexit__` swallows `RuntimeError` on a double release): open. It joins the cancel-sweep helper's step (M.TEST_HELP.067, not in this range); the sweeps in 55/59/61/62/65/67/71/79 assert its invariants.
- **OF-211** (unit files depending on 127.0.0.1:123/:53): open. Joins steps 50 and 56 (tests/test_asy_ntp_client.py).
- **OF-221** (src/asy_print_log.py:181-182,:190-191, shared `_reset_mark`, still there at :151-152,:358-359): open. Joins step 93.
- **OF-223** (tests/test_digital_twin_uart_link.py soak rate): open, target U36; its file's U35 holder is step 100.
- **OF-225** (src/asy_config_manager.py:396-402 and :582-588, one non-yielding flush): open. Joins step 82.
- **OF-32** (digital_twin/machine.py `_epoch_us` on a 2**30 build): open. Joins step 108, whose twin leg would hit it.
- None of the other U35 rows sits in this range's files.

## 4. PACKET VS CODE
- **DrivenTime collision (it decides steps 46-49, 53, 64, 66, 86-90, 94, 97, 99(1)).** The packet's M.TEST_HELP.065 is a new tests/_driven_time.py with `install()`, async `advance()`, `run_until()` and an asyncio shim. The tree already has a `DrivenTime` in tests/_fake_time.py:15-37: it swaps only `time`, has a synchronous `advance()`, and is used in 8 files. The file-local asyncio shims are `_YieldOnlyAsyncio`/`_DrivenClock` (neopixel test :61-105) and the webserver-connections `_DrivenClock`.
  - Proposal (agent, 2026-10-21; CLAUDE.md "check Part G's catalog first for an existing primitive to reuse"): extend tests/_fake_time.py's class, or promote the neopixel shim beside it, rather than add a second class of the same name. P2 and the M.TEST_HELP.065 owner decide.
- **Moved files:** step 66 → tests/test_asy_webserver_connections.py; step 103 → tests_hardware/markers.py.
- **Renamed files** (asy_ prefix): test_asy_config_manager.py, test_asy_crc_checks.py, test_asy_captive_dns.py, test_asy_print_log.py, test_asy_system_service.py, test_asy_base_classes.py; src/asy_config_manager.py.
- **Stale names:** `_neopixel_freq` should be `neopixel_freq`; the packet's `FakeNtpServer(port)` is now `(port, *, poll_ms, poll_tries)`; the packet's "TempOffs" is "TempOffset" in markers.py.
- **Step 81/83 conflict.** A.U35.43 (2) removes tests that pass non-dict data. But src/asy_config_manager.py:622 now checks a non-object explicitly (E BAD_ARG), and tests/test_asy_config_manager.py:1981 pins that branch. Keep the test while the branch exists (agent, 2026-10-21, conservative).
- **A.U35.43 (3) not landed:** the C.5 "don't remove them" sentence is still at SPECIFICATION.md:3156-3161. No step in 46-110 edits it, so P2 locates its step.
- **A.U35.44 code half not landed:** src/asy_crc_checks.py:37-38 `_crc()` pass-mode guard and :92-95/:110-113 `except ValueError`. That is M.SRC_CORE.116's step, outside this range; step 85's new cases also need M.SRC_CORE.131 first.
- **SPEC pointers:** the packet cites "C.14.3" for the registration shape (steps 87-90). In the tree, C.14.2 is the `_WIRING` convention (SPECIFICATION.md:4333) and C.14.3 is the error fan-in (:4436); the files cite C.14.2. Keep C.14.2 (agent, 2026-10-21). E.5.1's heading is now at :5218, under a different title; A.U35.41 has to re-locate the unreachable-branch register.
- **Not determinable read-only:**
  - Whether driven waits keep their counts exact (needs a run).
  - Step 93's store-merge case (read :827-900).
  - Step 69's shared-WLAN assertions (read :1593-1694).
  - Step 86/87 docstring wording ("(SPECIFICATION.md L.2)" against the packet's "(buildgen/codegen.py)").

## 5. FILES (step numbers)
- **tests/test_asy_notification_service.py:** 46, 47, 48, 49
- **tests/test_asy_ntp_client.py:** 50, 54 (check), 55, 56
- **tests/test_asy_udp_socket.py:** 63 (check), 64, 65
- **tests/test_asy_uart_driver.py:** 60, 61
- **tests/test_asy_wifi_service.py:** 68, 69, 70 (all check), 71
- **tests/test_asy_config_manager.py:** 80, 81, 83 (all check)
- **tests/test_bus_hazard_multi_device.py:** 73, 74, 76, 77; with tests/_bus_hazard_catalog.py: 73, 76
- **tests/test_asy_crc_checks.py:** 84 (check), 85
- **tests/test_ntp_fram_system_integration.py:** 91, 92 (check)
- **tests/test_asy_system_service.py:** 94, 95, 96 (all check)
- **tests/test_asy_webserver_connections.py:** 66, 67
- **Notification integration files:** tests/test_notification_neopixel_integration.py 87; tests/test_notification_scd30_integration.py 88; tests/test_notification_sgp40_integration.py 89; tests/test_notification_scd30_sgp40_integration.py 90
- **Driven-time and twin tests:** tests/test_asy_neopixel_driver.py 53; tests/test_neopixel_wifi_integration.py 86; tests/test_driven_time.py (new) 97; tests/test_digital_twin_network_neopixel.py 99; tests/test_digital_twin_uart_link.py 100
- **Other tests, one step each:** tests/_ntp_frames.py 57; tests/test_asy_fram_driver.py 51 (check); tests/test_asy_isl29125_driver.py 52; tests/test_asy_scd30_driver.py 58; tests/test_asy_uart_comm.py 59; tests/test_asy_uart_link_driver.py 62; tests/test_asy_base_classes.py 72 (check); tests/test_asy_sgp40_driver.py 75 (check); tests/test_asy_spi_driver.py 78 (check); tests/test_asy_captive_dns.py 79; tests/test_asy_print_log.py 93
- **src/asy_config_manager.py:** 82 (check; OF-225)
- **tests_scripts/_devices.py:** 98 (check)
- **tests_hardware:** flash/test_fram_storage.py 101 (check); markers.py 103 (check); flash/test_bus_concurrency.py and device_scripts/bmp3xx_alone_survives_a_general_call.py 74 (landed, H29)
- **audit/b3/*:** 102, 104, 105, 107 (timing.md); audit/sweeps/ticks30_build.sh 108
- **scripts:** lint.sh 102; _run_lower_levels.sh 106; test.sh 107; _digital_twin_ci_suite.py 109 (all except test.sh's re-order are check)
- **SPECIFICATION.md:** A.5 110 (check); Part N rows 48, 76, 105

The helper scripts I used are in /tmp/claude-0/-home-user-sensors/185d5b0e-d0ae-57c0-8798-ed52081f7df8/scratchpad/u35/plan_scratch/b/ (wo*.py, of.py, hw.py, plus extracted texts).
## P1c

# P1c record: U35 steps 111-144 (agent, 2026-10-21)

**Scope.** I read the packet's standing sections, steps 111-144 and the 30 carried actions those steps name. The tree checked is `S/wt-u33plan` at `1dd6dd5` (HEAD confirmed, working tree clean). All path:line citations are at that commit. I made no edits. My helper scripts are in `S/u35/plan_scratch/c/` (`g.py`, `of.py`, `s1-s4.json`). I used about 63 tool calls.

**Numbering.** The packet's step numbers govern, as the brief says. `audit/order/work_order.json` lists U35's steps in a different order: its #111 is M.TEST_UNIT.124, and packet step 111 (M.SPEC.081) is its #57.

## 1. STEP TABLE

| # | M.ID | files | verdict | evidence / what is left |
|---|---|---|---|---|
| 111 | M.SPEC.081 | SPECIFICATION.md E.5-E.5.3 (:5184-5361) | part landed; U35 (2) **to write** | **Landed:**<br>• A.U28.15: there is no Codecov step and no Cobertura XML anywhere in `ci.yml`, `test.sh`, `_render_coverage.py` or `.gitignore` (grep finds only doc mentions). The four publish steps are `ci.yml:611-644`; the count of 8 is asserted at `tests_scripts/test_test_sh.py:1973`; `--xml-file` is refused at `tests_scripts/test_render_coverage_anchors.py:39`.<br>• E.5 body: the archive and incomplete-file sentences :5193-5194, :5208.<br>• E.5.2 probe bullet :5296-5310.<br>• E.5.3 `Result: PASS (coverage report not rendered)` :5357-5358.<br>**U35 writes:**<br>• The convention paragraph (absent: grep "A branch no input can reach" finds nothing).<br>• The register at :5234-5259, rewritten per A.U35.41's table.<br>**Stale at HEAD:**<br>• :5246 "`except Exception` around `type(nt).__name__`" — the catch is gone (`src/asy_config_manager.py:257-258`).<br>• :5247 the wifi `ifconfig()` `return None` — `get_wlan_ifconfig` is gone.<br>• :5249 the sgp40 `readlen is None` — gone.<br>**Go:**<br>• "That pass left **31 genuinely uncovered lines across 8 files** …" (:5254-5256).<br>• "Two more were found exactly that way in the 2026-09-22 pass" (:5263) gets reworded.<br>**Earlier-stage gap:** U24's tracer classes are missing from E.5.1's first paragraph (:5220-5230 lists only const, decorator and `while True`). |
| 112 | M.SPEC.092 | SPECIFICATION.md F.1 | **to write** (U35's two sentences) | Already in place: wall clock (2) :6053-6073 and C stack (3) :6075+.<br>U35 inserts two sentences after :6051 ("…`tests/test_ticks_rollover.py` and the drivers' own test files)."):<br>• "Wrap safety was run once on a 2**30-period Unix build … (agent, <date>)" — only after step 108 (M.PROC.024, P1b) has run.<br>• "On silicon the rollover round's tick-offset test image crosses … about 15 minutes after boot (B.14.5, E.6.3)" — B.14.5 exists at :2516.<br>REGISTER.md:414 (U14 ruling 7) confirms the scratch-build sentence is U35's. The A.U36.544 item-12 sentence is U36's. |
| 113 | M.SRC_CORE.130 | src/math_helpers.py | **landed** | All five catches read `except (ArithmeticError, ValueError):` at :68, :120, :147, :167, :227.<br>End-state function order holds: :53 abs_humidity, :72 cct_mccamy, :90 chromaticity_xy, :102 dew_point, :124 ema_step, :137 pressure_at_height, :151 rel_humidity, :174 rgb_to_hsb, :196 rgb_to_xyz, :210 wet_bulb_temperature. |
| 114 | M.TEST_HELP.042 | tests/_sensortask_scenarios.py | **to write** | None of the four groups exists (grep for fault_storm, forty_days, dropped_one_second, stops_every_feed, `_log_dead_task`, persisted_log: nothing).<br>**Blocked on step 32** (M.TEST_HELP.065, P1a): `DrivenTime` (`tests/_fake_time.py:15-37`) is only a ticks module swap. It has no asyncio sleep shim, no async advance/run_until/jump and no wait_for shim; `Ticks30Time.advance()` is synchronous (`tests/_ticks30.py:27`).<br>**Seams present:**<br>• `tests/machine.py`: `Timer.all_timers` :1232, `drop()` :1288, `trigger()` :1320, `WDT.feed_count`/`feed_times` :1372-1389, `SimulatedRebootError` :1448.<br>• Supervisor: `_log_dead_task` `src/asy_system_service.py:297`, `_TASK_FAIL_MAX` :69, `_reset_armed` :550, `supervise_tasks()` :783.<br>• Generated `main()` emitter `buildgen/codegen.py:544-559`.<br>• The scenarios already read `chip.write_transactions` (:1357). `tests/_fram_chip_fake.py` has no per-logger write counter. |
| 115 | M.TEST_UNIT.229 | tests/test_asy_base_classes.py | **landed**; check-only | • `get_cfg_schema()` :119, :1894-1933.<br>• `assert run(reader.setup()) is True` :1871.<br>• FRAM-rule comment verbatim :2086-2087; no "stays public" left.<br>• The RAM-only class test exists under another name: `test_a_reader_that_keeps_its_config_log_off_fram_still_logs_its_own_to_fram` :2164-2188 (`_CFG_LOG_FRAM = False` :2161). |
| 116 | M.SPEC.058 | SPECIFICATION.md C.7 (:3329) | part landed; U35 (7) **to write** | Already in place: pitfall and RAM-only text (1)/(12)/(13) :3331-3355; per-layer and mixed-kind rule :3431-3439; report_if_fatal :3491; WIFI rule (15) :3505-3510.<br>U35 inserts at :3439, after "…(`tests_scripts/test_fault_or_warning_never_both.py`)." and before "A failed config read is persisted…": "An expected condition prints only: a normal situation never logs a code, and a test of one asserts no entry (owner, 2026-09-12, `8a45060`: '…')".<br>The "one save primitive" pointer stays U36's (current text at :3337-3338). |
| 117 | M.TEST_UNIT.230 | tests/test_asy_base_classes.py | **landed**; check-only | • Header comment :2279-2281 ("(owner, 2026-09-26)").<br>• "(agent, 2026-08-03)" :3191.<br>• No "Final project decision", "(project decision)" or "benign" left.<br>• Unknown-key test :3027-3037.<br>• New tests :2285, :2302, :2414 (with `WriteCountingOpen` :2440), :2454, :2492, :2523, :2548, :2568.<br>• Fold (1) :1624. |
| 118 | M.SCR.049 | scripts/_digital_twin_ci_suite.py `_run_1_baseline` :1089-1124 | part landed / **to write** / part **conflicts** | **Landed:** the null-before-sync check :1099-1100; ResetErrors `Valid` plus budget in `_put_reset_errors_timed()` :682-696 (called at :1116); the `ctx.state_dir` check :1123.<br>**To write (before :1116):**<br>• One `GET /status`/`/system` read, kept as `run1_errcount.json`.<br>• Every module's history: no E and no W entry (`_error_codes()` :521).<br>• Fold (1): the reformat relaunch with exactly one W `CONFIG_LOST` (the catalog row exists), kept as `run1_reformat_errcount.json`.<br>**Conflicts:** the step wants a poll until `NTPSynced` is true in Run 1. Run 1 has no station link (its comment :1090-1091; the SSID is set in Run 6 :1349). HEAD proves the synced half in Run 5 :1236 and Run 8 :1409-1412.<br>Conservative choice (agent, 2026-10-21): keep the synced half where it is and write no Run-1 poll.<br>HEAD has no `runs/` directory (the archive is `ctx.logs_dir/"state_archive"` :340), so the files go under `ctx.logs_dir/"runs"`. |
| 119 | M.TEST_UNIT.273 | tests/test_math_helpers.py | **to write** | No stand-in exists (grep for `ArithmeticError`, `mh.math`, "stand-in": nothing).<br>The module is imported as `mh` (:4). The test goes before the final `microtest.run(globals())` trailer.<br>Math calls to stand in: `pow` :67/:165, `log` :117, `exp` :146, `atan`/`sqrt` :221-225. |
| 120 | M.TSC.134 | scripts/test.sh, tests_scripts/test_test_sh.py | **landed** (U35 part); one re-measure left | • Heavy list :661-671; `_check_heavy_list` with its message and exit 2 :672-681.<br>• Tests :1988-2000.<br>• Tunables :36-39.<br>• `--help` :1319-1350; exit-2 cases :1251-1335; `fixture_device` :1120.<br>Left: A.U35.24 (3), re-measuring the list against A.U35.23's timing. The list has 10 entries, not the 15 the action names. OF-200 joins this. |
| 121 | M.TWIN.031 | digital_twin/machine.py :1474-1538 | **check-only** | • Cap comment :1474-1475; TEST_API :1482.<br>• Comment block :1494-1495; bounded logs :1497-1499; `_armed_at_ms` :1502.<br>• Saturating counters :1530, :1536; `feed_times` append :1537. |
| 122 | M.TWIN.054 | digital_twin/run_device_script.py | **check-only** | • Header :1-3; prewarm then shim :105-106; `# @tunable wdt.timeout_ms = 8000` :27.<br>• WDT armed :122-123; `gc.threshold` :126; exec comment :128-129.<br>• Reset exits :132-135; `sys.exit(main(…))` :148.<br>HEAD goes beyond the packet: exit code 6 (watchdog starved) :13 and a `--state-dir` option. Only the `machine_wdt.c:43-57` citation is missing from :122's comment. |
| 123 | M.TWIN.102 | tests/test_digital_twin_bus_hazard_concurrency.py | **check-only** | • Derived devices :33, :104-106; no in-DUT burst; `dropped` check :275; `resets` :283.<br>• Heater, soft-reset and re-apply cases :756-894; `owner=` :457-650.<br>• Owner tag :478 "(owner, 2026-09-04, paraphrase)".<br>Not determinable read-only: whether reset-reachable cases catch `SimulatedRebootError` (grep: none). Running the file settles it. |
| 124 | M.TWIN.144 | tests/test_digital_twin_sensortask_integration.py | part landed; U35 **to write** | **Landed:** header :1-3, `PER_DEVICE` :21; tests 1 :401, 3 :446, 4 (now :567 plus :599), 5 :644, 10 :662 (MEASURE :683), 6 :719, 7 :743, 8 :777, 9 :814; (19) is in tests/test_digital_twin_wifi_modes.py:221.<br>**Test 2 (A.U35.31 (1)) to write:** :422-443 still uses `_feed_watchdog_periodically()` (:213-216, :433) and hand-started timers and tasks (:429-432). It becomes a `main()` run under `run()`, renamed, plus:<br>• the offline-boot assertion `public_destinations_refused == 0` (today only printed on the runner's shutdown line, `run_generic_integration.py:465`);<br>• the comment's second line.<br>**Fold parts (11)-(16) and (18) to write** (packet :205-242; grep for WLAN_NO_VERDICT, `_SAMPLE_MAX_AGE_S`, burst_answered: none). (17) is covered in wifi_modes :231. |
| 125 | M.SCR.018 | scripts/_digital_twin_scenarios.py; digital_twin/run_generic_integration.py | part landed; U35 **to write** | **Landed:** (d) :484, (e) :572, measurements_and_sensors_shape :1086, (j) :1040, (k) :907/:1367, (l) :932/:1170/:1286, (m) :1872.<br>**To write:**<br>• (f) watchdog_fault_*: needs the runner flag `--test-watchdog-fault` and a `WDT_AT_FAULT` line (absent; the flag table is at :384-409).<br>• (g) A.U35.09's two recombinations (use `NTPHost`, Run 8 :1420).<br>• (h) the bounded storm: needs `fram_writes=`/`fram_writes_by=`/`fram_writes_unattributed=` on the shutdown line (absent at :463-465). It depends on step 151 (M.TWIN.050, P1d).<br>• (i) zero_think readers.<br>• Folds (1)-(3). Their product fields exist: `HTTPDropped` `buildgen/codegen.py:661`, `ConfigUnpersisted` :673, catalog rows CHIP_GET and CFG_FILE_WRITE. |
| 126 | M.DOCS.065 | BACKLOG.md "## Deferred / explicitly out-of-scope work" :537 | **to write** (U35 part) | Remove the bullet at :1174-1184 ("Network fault injection against the real dev bench unit is complete … **Still open**: the NTP-outage-x-bus-load fault recombination has no twin/mock-tier equivalent … not chased yet. …") once step 125 (g)(a) lands. The rest of the step is U37's. |
| 127 | M.HW_DEV.106 | tests_hardware/device_scripts/scheduler_saturation_drop.py | **check-only** (hardware R1 [H48]) | `_N_TIMERS` :24, 900 µs steps :28/:49-51, arming span :47, heal window :30, facts :59-65 (`dropped` is computed inside the fact at :64). |
| 128 | M.SPEC.160 | SPECIFICATION.md E.2.3 (new), E.6.6 :5532, K.10 :10041 | **to write**; unit mismatch | None of the five E.2.3 sentences exists, E.6.6 has no DHCP sentence, and K.10 has no fault-planting gate.<br>**Mismatch:** the merged text's Unit says U36; the work order puts it in U35 (#66, carrying A.U35.04/.28/.33).<br>Conservative choice (agent, 2026-10-21): land it in U35, after step 143 creates E.2.3 and after the tests that make its sentences true. |
| 129 | M.HW_BENCH.016 | tests_hardware/harness.py | **check-only** | Markers :58-63, `boot_lines` :444, `crash_lines` :455, `observe_during` :521 with its tunable :143-144, `wait_for_boot` :686. |
| 130 | M.HW_BENCH.060 | tests_hardware/bench/conftest.py | **check-only** (hardware: every round's first step [H04]) | `check_image` :71, `board_image` :83-94. |
| 131 | M.HW_BENCH.074 | tests_hardware/bench/test_memory_stress_bench.py | **check-only** (hardware R1 [H83], soaks R5 [H64]) | Derived names :81, routes :24, crash/boot lines :136-137, floor :33-34, `test_http_soak_stays_live` :93, failure rate :39, COVERS list :18, comment :115. |
| 132 | M.HW_BENCH.075 | tests_hardware/bench/test_modlwip_send_stall.py | **check-only** (hardware R1 provisional / R4 [H39, H40]) | :83, :93-118. `check_image()` appears as `_load.image_deviations(request, dut_ip, record)` (:112, :118). |
| 133 | M.HW_BENCH.091 | tests_hardware/twin_board.py | **check-only** | :49-58, `run_isolated` :109, `_unix_port.sh` :25/:42/:46, micropypath :27/:66. A.U27.12/.15 landed here. |
| 134 | M.HW_BENCH.092 | tests_hardware/twin_record.json | part landed; U35 **to write** | 122 entries (19 bench, 88 device scripts, 15 flash): 21 pass, 101 exception. All carry `gc_threshold: -1`, dated 2026-10-21.<br>U35 owes the re-record at both GC stages after B2's and B3's last hardware-facing change, plus a review of every exception.<br>59 device-script entries are charged with their flash file's silicon-only case (OF-229). |
| 135 | M.HW_BENCH.121 | tests_hardware/README.md :522-541 | **check-only** | 12 habits, each with its enforcing check; the twin-first habit is at :538. |
| 136 | M.HW_DEV.010 | twin_record.json and every instrument | **to write** (procedure) | The re-runs at both stages (with step 140), the bite review (A.U35.03), the gates proven through the twin (A.U35.05), and the wear gates (A.U35.51). |
| 137 | M.PROC.023 | audit/b3/intent.md, audit/b3/levels.md | **to write** | `audit/b3/` does not exist at `1dd6dd5`. A.U35.01 opens it, and that step is in another range. |
| 138 | M.PROC.027 | audit/b3/conformance.md | **to write** | Same. |
| 139 | M.PROC.037 | throwaway worktree; the flash and bench runners | **hardware** (phase C, R1 end, [H43]) | Nothing in the tree. REGISTER.md:722: hardware session 1 waits for the owner's order after U35. |
| 140 | M.SCR.022 | scripts/record_twin_instrument_runs.py (+ tests_scripts/test_twin_record.py) | part landed; U35 **to write** | Landed: tmp file plus replace :143-145; the `pytest --twin` flash run :41; the binary and MICROPYPATH through TwinBoard.<br>To write: the second GC stage. Today there is a single `_GC_THRESHOLD = -1` (:32) and one `gc_threshold` per entry (:140); each entry needs an outcome at -1 and at 32768. OF-229 sits at :125-130. |
| 141 | M.PROC.029 | audit/b3/queue_c.md | **to write** (hardware preparation) | Absent. |
| 142 | M.DOCS.064 | BACKLOG.md "## Real-hardware work still owed" :194-536 | **to write** (U35's rows only) | Existing rows include the general-call ACK/NAK row :368-372 and the lwIP row :333-338.<br>U35 adds rows for its new instruments as A.U35.54 lists them (the silicon arm of the gates first). The lone-BMP3xx flash test exists at `tests_hardware/flash/test_bus_concurrency.py:267`. |
| 143 | M.SPEC.077 | SPECIFICATION.md E.2 :4846-4955 | part landed; U35 (4) **to write** | **Landed:** (1) :4848-4865, harness :4867-4882, helpers :4884-4897, buildgen homes :4899-4906, "Waits poll" (5) :4908-4912 (sitting in E.2, since there is no E.2.3).<br>**Not landed:** no E.2.2/E.2.3 headings; the "Session 6.2" sentence :4940-4942 is U36's.<br>**U35 writes:** "### E.2.3", with "**A test bites** …" and "**Time at L1 is driven** …". The second needs step 32's virtual sleeps first.<br>Conservative choice (agent, 2026-10-21): the hygiene sentences already in E.2 (:4857-4860) stay; U36 relocates them. |
| 144 | M.SPEC.137 | SPECIFICATION.md J.7 (:9512); maybe tests/test_uart_comm_hazard.py | U35 (5) **to write** | "The accepted trade-off is that neither test would now catch a *latency* regression below 240 ms — …" (:9641-9643) is replaced after A.U35.06's plant. (6) has landed at :9666-9673.<br>**UART:** test and doc only. No emitted byte, accept/reject rule or recovery timing changes; nothing is logged in UART_C_PORT_CHANGELOG.md. |

**UART files.** No step in this range edits `src/asy_uart_comm.py`, `src/asy_uart_link_driver.py` or `UART_C_PORT_CHANGELOG.md`. Step 125 (m) only reads `_FLASH_HOLD_MAX_MS` by `ast` (already landed). Nothing here is a wire-format conflict.

**`# @tunable` tags:**
- Step 120's two tags have landed (`tests_scripts/test_test_sh.py:36-38`).
- Step 125 (i) adds a reader-floor tag.
- Steps 114 and 125 (f) may add tags for their driven or watchdog windows (per A.U8.02).
- Step 144 adds one bound tag only if no existing test bites.
- Step 124's test-2 rewrite drops this file's use of the `l2.twin_wdt_feed_interval_s` loop.

**`error_catalog.json`:** no step here adds or removes a row. Step 118 reads `CONFIG_LOST`; step 125 reads `CHIP_GET` and `CFG_FILE_WRITE`.

**Twin-record inputs:**
- Steps 134, 136 and 140 change the record and its shape (a per-stage field), so `tests_scripts/test_twin_record.py` must follow.
- Step 125 (f)/(h) changes `run_generic_integration.py`. That file is not in `runner_sha256` (`RUNNER_FILES` = `run_device_script.py` + `twin_board.py`).

## 2. Carried actions → steps

| action | step(s) and state |
|---|---|
| A.U28.15 | 111 (landed) |
| A.U35.41 | 111 (E.5.1 text); 113 (row; landed) |
| A.U35.42 | (1) → 113 and 119. (2), the FRAM half, sits outside this range (packet steps around 22-23) and appears landed: no `errno=98` in `src/asy_fram_driver.py`. |
| A.U35.32 | 112 (the sentence); the scratch run itself is step 108 |
| A.U35.36 | 113 (the map itself is step 104) |
| A.U35.03 | 114, 136, 143 |
| A.U35.10 | 114, 143 (needs step 32) |
| A.U35.28 | 114 (1), 125 (h), 127, 128 |
| A.U35.30 | 114 (2) |
| A.U35.33 | 114 (3), 128 |
| A.U35.34 | 114 (4) |
| A.U35.37 | 115, 116, 117, 118 |
| A.U35.38 | 118 (the action is dropped; the step carries its successor text) |
| A.U35.24 | 120 |
| A.U35.31 | 121 (check), 124 (test 2), 125 (f) |
| A.U35.49 | 122, 134, 135, 136, 140 |
| A.U35.09 | 123 (adds nothing), 125 (g), 126 |
| A.U35.21 | 123, 134 (script and flash test already in tree) |
| A.U35.50 | 123 |
| A.U35.29 | 125 (i) |
| A.U35.04 | 128 |
| A.U35.05 | 129-133, 136, 139 |
| A.U35.07 | 137, 143 |
| A.U35.22 | 137 |
| A.U35.53 | 138 |
| A.U35.51 | 136 |
| A.U35.54 | 141, 142 |
| A.U27.12, A.U27.15 | 140 (landed through twin_board.py) |
| A.U35.06 | 144 |

## 3. OPEN FINDINGS whose site is in this range's files

| finding | site | state | joins |
|---|---|---|---|
| OF-149 | twin integration test failed once under build-settrace | open | step 124 |
| OF-188 | the same file's settrace heap drift | open | step 124 |
| OF-229 | `scripts/record_twin_instrument_runs.py:125-130` charges each script with its flash file's outcomes | open; visible in 59 record entries | step 140; gates steps 134 and 136 |
| OF-200 | `tests/test_sensortask.py` duration | open | step 120's re-measure (or the A.U35.23 timing step) |
| OF-32 | `digital_twin/machine.py` `_epoch_us` :900, `_now_us` :930 on a 2**30 build | open | step 108 (P1b), the only run that trips it; my step 121 holds the file check-only |
| OF-184 | CONFIG_LOST in scratch builds | open, target C | related to step 118 fold (1) only |
| OF-47, OF-187 | — | closed at U30 | — |
| OF-199 | test_test_sh.py's half | closed at U28 | — |

Register rows:
- REGISTER.md:414 → step 112.
- REGISTER.md:691/:722 (firmware final at U35's end; hardware session order is the owner's call) → steps 139 and 141.

## 4. PACKET VS CODE

**Renames:**
- Source modules: `system_service.py`, `base_classes.py`, `print_log.py`, `config_manager.py` and `crc_checks.py` are now the `src/asy_*.py` versions.
- `tests/test_base_classes.py` is now `tests/test_asy_base_classes.py`; the packet's :743-1851 citations are stale.
- The supervisor's `start_and_check_tasks()` is gone. It is now `start_tasks()` :744, `supervise_tasks()` :783 and `_supervise()` :524.
- `NTP_Host` is now `NTPHost`.

**Moved:**
- `tests/_driven_time.py` and its self-test do not exist; `DrivenTime` is at `tests/_fake_time.py:15`.
- M.TWIN.144's test 4 was rewritten from reconstruction to radio re-selection (:567, :599).
- (19) is one combined test in `tests/test_digital_twin_wifi_modes.py:221`.
- `check_image` is `_load.image_deviations`.
- TwinBoard's `gc_threshold` is a constructor keyword, not a `run_isolated` keyword.

**Done by earlier units:**
- A.U35.21's script and flash test are in the tree (the mock copy's deletion is another range's step).
- A.U28.15 and A.U27.12/.15 have landed.

**Stale or diverging:**
- Three E.5.1 entries (row 111).
- The heavy list has 10 entries, not 15.
- `reset_code_boot_phase_hang.py` passes in the twin, though the packet expects a silicon-only exception.
- `bmp3xx_alone…` is recorded as an exception, though A.U35.21 expected it to pass by construction (see OF-229).
- E.2.1's heading is `##`, not `###` (U36 renumbers).

**Not determinable read-only, and what would settle each:**
- Whether A.U14.32's full tick sentence (U17's stage) has landed — compare F.1 :6043-6051 with the action text in `audit/actions`.
- Whether the bus-hazard file still guards resets — run the file.
- Whether E.5.1's tracer classes hold on `build-settrace` — a `--coverage` run.
- Whether folds (11)-(16) can be driven in-process with today's seams (for example `_SAMPLE_MAX_AGE_S = const(10800)` at `src/asy_notification_service.py:69` needs the twin wall clock) — write and run.

## 5. FILES (with step numbers)

| file | steps |
|---|---|
| SPECIFICATION.md | 111, 112, 116, 128, 143, 144 |
| tests/test_math_helpers.py | 119 (113 is landed, no edit) |
| tests/_sensortask_scenarios.py | 114 (depends on tests/_fake_time.py, step 32) |
| tests/test_asy_base_classes.py | 115, 117 (check) |
| scripts/_digital_twin_ci_suite.py | 118 |
| scripts/test.sh, tests_scripts/test_test_sh.py | 120 (landed) |
| digital_twin/machine.py | 121 (check) |
| digital_twin/run_device_script.py | 122 (check) |
| tests/test_digital_twin_bus_hazard_concurrency.py | 123 (check) |
| tests/test_digital_twin_sensortask_integration.py | 124 |
| scripts/_digital_twin_scenarios.py | 125 |
| digital_twin/run_generic_integration.py (+ digital_twin/README.md flag list) | 125 (f); (h) via step 151 |
| BACKLOG.md | 126, 142 |
| tests_hardware/device_scripts/scheduler_saturation_drop.py | 127 (check) |
| tests_hardware/harness.py | 129 (check) |
| tests_hardware/bench/conftest.py | 130 (check) |
| tests_hardware/bench/test_memory_stress_bench.py | 131 (check) |
| tests_hardware/bench/test_modlwip_send_stall.py | 132 (check) |
| tests_hardware/twin_board.py | 133 (check) |
| tests_hardware/README.md | 135 (check) |
| tests_hardware/twin_record.json | 134, 136, 140 |
| scripts/record_twin_instrument_runs.py, tests_scripts/test_twin_record.py | 140 |
| audit/b3/{intent,levels,conformance,queue_c,load}.md | 137, 138, 141 (114 and 125 add load.md entries) |
| tests/test_uart_comm_hazard.py | 144 (only if no existing test bites) |
| throwaway worktree | 139 |

**Cross-range dependencies for P2:**
- Step 32 (M.TEST_HELP.065) must come before steps 114, 143 (4) and 144.
- Step 108 (M.PROC.024) must come before step 112.
- Step 151 (M.TWIN.050) must come before step 125 (h).
- A.U35.01, which opens `audit/b3/`, must come before steps 137, 138 and 141.

## P1d

## U35 P1d: steps 145-179, located at `1dd6dd5`

All 35 steps are located (step 157 is the co-landing group and counts as one). This was read-only: the only files written are the helper scripts and extracts under `S/u35/plan_scratch/d/`. All line cites are at `1dd6dd5`. "README" means `digital_twin/README.md`, "SPEC" means `SPECIFICATION.md` and "suite" means `scripts/_digital_twin_ci_suite.py`.

**Summary.**
- **Already done, nothing to edit:** 150, 154, 155, 156, 168, 172, 173 and the six web steps 174-179.
- **Partly done:** 145, 146, 149, 151, 152, 157, 160-166, 167, 169, 171. What is left is listed per row.
- **Still to write, or waiting on B3 measurements:** 147, 148, 153, 158, 159, 170.
- **Conflicts:** five, all set out under "Conflicts" in section 4. Four come from the NTP "synced on a normal boot" claim, which cannot hold for a boot with no SSID. One is the wire log's "unbounded" label, which is now false.

### 1. Step table
| # | M.ID | files it edits | verdict and evidence |
|---|---|---|---|
| 145 | M.SPEC.156 | SPEC Part N (N.3 :11543-, N.4 :12713-) | **part landed.** Done: the renames (`led.refresh_hz` tag in `src/asy_neopixel_driver.py`; `udp.poll_wait_ms`/`poll_idle_ms`, row :11625 with the owner's 2026-10-05 "kept"; `l2.uart_link_pause_*`/`_leak_rate_bytes_per_transfer`). The withdrawals: no row or tag remains for `l1.asy_notification_service_override_tick_s`, `l2.network_neopixel_never_connects_wait_s`, `l2.sensortask_integration_dns_query_*`, `udp.conn_tries_default`, `…starter_loop_grace_ms/_poll_ms` or `*_wdt_feed_every`. Also done: `l3.device_script_feed_step_ms` under `wdt.timeout_ms`, the fold rows (`sgp40.comp_max_age_s`, `notify.sample_max_age_s`, `led.overlay_refresh_ms`, `dev.uart_rx_ring`, `uart.flash_hold_max_ms`) and the rule rows N.4 :12724-12728. **Left:** (a) rows for U35's new tags (only step 148's conditional one); (b) `loop.uart_call_span_max_us` "Checked by" still names the device script, but the verdict is read at `tests_hardware/flash/test_uart_crossover.py:135-136` (GAP-D4). |
| 146 | M.SPEC.079 | SPEC E.3.1 :5036-5130 | **part landed:** (1) :5038-5042, :5056; (2) :5062-5081; (3) :5104; (4) :5125-5130. A.U30.12 is done: no in-body `gc.threshold` remains in `tests/test_asy_webserver_service.py` (comments only, :3772/:3843), and the `gc.threshold_bytes` row :11673 lists none. **Left:** A.U35.23's history row under the list :5044-5058, after B3 measures. "WP1+WP2" :5044 and "dev-variant" :5054 are U36's (A.U36.512). |
| 147 | M.SPEC.157 | Part N Basis cells | **to write (B3) + hardware.** 386 `l0`-`l2` rows still read "estimated" (e.g. :11758, :11969-11973, :12016). The 532 `l3`/`l4` rows stay estimated until phase C: R1/R4/R5 (H55), the bands R0 (H56). A.U19.13's `web.serving_demand_budget_b` :11775 ("post-boot free heap on dev, L4") is R1 (H44). |
| 148 | M.TEST_UNIT.324 | `tests/test_uart_comm_hazard.py`; SPEC J.7 | **to write, plant first.** J.7 :9641 still reads "The accepted trade-off is that neither test would now catch a *latency* regression below 240 ms". `DrivenTime` is at `tests/_fake_time.py:15`, but the hammers already run on `PollRoundClock` (`tests/_uart_comm_harness.py:122-158`). **UART:** test only, the plant stays in a throwaway worktree; no emitted byte, accept/reject rule or recovery timing changes. **@tunable:** may add `l1.uart_comm_hazard_clean_transaction_virtual_ms`. |
| 149 | M.TSC.086 | `tests_scripts/test_digital_twin_generated_boot.py` | **part landed:** ROUTES read by `ast` :87-95; strict JSON :110-112/:294; section keys :121; errcount parity :126; Status parity :127/:279; System path :130/:300; memory markers :167/:387-391; SGP40 instances :453. **Left:** `_normal_boot_log_failures` in the `/status` branch :124-128; the boot-sequence order (already asserted in-process at `tests/_digital_twin_construction_scenarios.py:82-84`); the comment :505-506 "Session 3's". **Conflicts:** "NTPSynced turns true" (see section 4). |
| 150 | M.TWIN.011 | `digital_twin/_fram_chip.py` | **landed:** :1-3, :31-32, :136-164 (`write_count`/`writes_at`, counted only with WEL set and more than 1 byte, :292-295), :169-170, :221-223, :277-283, :313-314. |
| 151 | M.TWIN.050 | runner `_shutdown_line()` :458-467; `scripts/_twin_process.py` `ShutdownLine` :109-121, `_SHUTDOWN_INTS` :130 | **part landed:** exit codes :135-137, NTP responder :892-896, the WDT tag :151, `_watchdog` :138. **Left (U35):** `fram_writes=`, `fram_writes_by=` and `fram_writes_unattributed=`. The sources exist: `machine._current_fram_chip` (machine.py:582), `get_loggers()` (src/asy_base_classes.py:755), `_block_addr` (src/asy_fram_manager.py:95). There is no `_module` global yet. |
| 152 | M.TWIN.051 | runner :172-203, :381-412, `_test_start` :730; `tests_scripts/test_twin_runner_test_flags.py:16-18`; `scripts/_digital_twin_scenarios.py` (three host cases) | **part landed:** section comment :469-471, 11 flags. **Left:** `--test-watchdog-fault {supervisor-raise,main-exit,block}`, its `WDT_AT_FAULT <feed_count>` line, its row in the flag table, and A.U35.31's three host-side cases. |
| 153 | M.PROC.026 | new `audit/b3/conformance.md` (from `audit/actions/SUPP_recovery.md`) | **to write.** `audit/b3/` does not exist yet (A.U35.01 opens it). L3/L4 cells go to `queue_c.md`, then **hardware R1 (H71)**. |
| 154 | M.SCR.016 | `scripts/_twin_process.py` | **landed** (U25/U27): :1-3, :27, :30-34, :238, :309. No normal-boot tolerance constant exists anywhere in `scripts/` or `tests_scripts/`, which is U35's confirmation. OF-215 stage 3 joins here. |
| 155 | M.SCR.017 | `scripts/_digital_twin_scenarios.py` | **check-only:** the mechanism has landed (:5-7, registry :402-1872). A.U35.57's text lands at step 158. |
| 156 | M.SCR.047 | the suite | **landed:** imports :37-67; `-1` readers :1004/:1197/:1341/:1408; :402; `_twin_process.py:238-250`. A.U35.05 is a procedure in a throwaway worktree; its silicon arm is **hardware R1 end (H43)**. |
| 157 | M.SCR.046 + M.SCR.057 + M.TWIN.052 | the suite :200-217, :651-666, :801-841; runner :371-378; `scripts/_check_gc_collect_sites.py:68` (conditional) | **part landed:** header, imports, tags; one attempt `_run_11_soak` :779-798, `_SoakRun` :315. **Left:** (1) the window is still clock-based: `cycles_start = time.time()` :818, filter :837 `cycles_start <= ts <= cycles_end`, and the parser returns `(float, int)` :651-666; it moves to log byte offsets. (2) `MEM_SAMPLE {time.time():.3f}` :378 becomes `ticks_ms`. (3) Keep or drop the sampler's collect, its comment :372-374 and checker row :68. (4) Measured values for :207, :212, :217, plus the comment :208-210 ("one gc.collect()+print() per interval costs nothing measurable"). **Conflicts:** the "unbounded" wire-log label (see section 4). |
| 158 | M.DOCS.066 | `BACKLOG.md` chroot entry :547- | **to write:** U35's dated paragraph after the last 2026-10-21 paragraph, before the "Session 7's `max-args`" bullet. No paragraph names the heavy-list check (`scripts/test.sh:672-682`), so U35's paragraph must. |
| 159 | M.DOCS.067 | `BACKLOG.md` `## Owner questions` :1223- | **conditional:** entry 8 (1-7 are used, :1228-1292), only if A.U35.27 finds no separating window. A.U30.02 has nothing left here. |
| 160 | M.SCR.051 | the suite Run 3 :1151-1181; `audit/b3/load.md` | **part landed:** `_SUSTAINED_FAULT` :94, escalation checks, `_LEFT_OUT` :112, CRC16 check :376. **Left:** the FRAM write-count rate assertion (needs step 151's field) and `load.md`. |
| 161 | M.SPEC.076 | SPEC E.1 :4748-4758 | **part landed:** the code from A.U35.24 (1)-(2) is in: `scripts/test.sh:672-682` (exit 2) and `tests_scripts/test_test_sh.py:1988`, `:1995`. **Left:** the SPEC clause "the heavy-file dispatch list is checked against the file set" at :4753-4754, and (3) re-measuring the list order in B3. |
| 162 | M.SPEC.085 | SPEC E.9 :5690-5775 | **part landed:** :5714, :5723-5751, one attempt :5769-5771. **Left (U35):** the calibration clause, after measurement. The history bullet :5708-5714 is U25/U27's stage, not landed. |
| 163 | M.SPEC.129 | SPEC I.4(e) :8886-8887 | **to write** the outcome over "kept while a sparser sampling interval gives Run 11 the same verdict". The release proof is phase C. |
| 164 | M.TSC.084 | `tests_scripts/test_digital_twin_ci_suite_soak.py` | **part landed:** :133-141, :300, :310, `fixture_device`. **Left:** offset cases and a backwards-clock fixture; the current cases :28-43 are timestamp pairs. |
| 165 | M.TSC.095 | `tests_scripts/test_gc_collect_sites.py`; checker :67-69 | **landed** (U30); U35 only decides the `_mem_sampler` row :68, with the line. |
| 166 | M.TSC.165 | `tests_scripts/test_digital_twin_ci_suite_errcount.py` | **part landed:** :83-95, :213-269, :324, :378, :440, :519-560, :586-591, :611-616, :701-742. **Left:** `fram_writes*` parser cases; normal-boot cases (one W fails; an NTP entry fails). **Conflicts:** Run 1's NTP cases (see section 4). |
| 167 | M.TWIN.059 | README Fidelity table :187-269 | **part landed:** the FRAM write-count row :264. **Left:** A.U35.31's row ("a runner-cancelled `main()` keeps the loop and the WDT countdown alive"). |
| 168 | M.TWIN.063 | README :559-596 | **landed, check-only:** :570-584. A.U35.09 needs no README line. |
| 169 | M.TWIN.064 | README CI suite :612-863 | **to write:** Run 1 :669-679 "reads, keeps and checks the logs … then clears them". **Conflicts:** "NTP synced" (see section 4). |
| 170 | M.TWIN.065 | README :864-923 (+ :332, :780) | **to write:** :867 head; :869-870 "deliberately has no REST route" is stale (`MemFree` is at `buildgen/codegen.py:669`, SPEC :971); :873-875 wall-clock join becomes `ticks_ms` plus log position; :876-877 the B3 verdict; :892-896 "wozi's original 40"; "one attempt decides (no retry)"; `MEM_SAMPLE <time.time()>` at :332/:780. **Conflicts:** the wire-log label (see section 4). |
| 171 | M.TWIN.066 | README Runner flags :429-472 | **part landed:** 11 test flags :455-466, exit codes :472. **Left:** the `--test-watchdog-fault` row, the `main-exit` sentence, and the `fram_writes*` fields in the shutdown-line text :466-470. |
| 172 | M.TWIN.074 | README :597-611; `tests_hardware/twin_record.json` | **landed** (doc). A.U35.49 is a re-record at both GC stages after B2 and after B3: the record's content changes, its inputs (`scripts/record_twin_instrument_runs.py:27`, `:91-94`) do not. OF-229 attaches here. |
| 173 | M.TWIN.110 | `tests/test_digital_twin_fram.py` | **landed:** :774, the SF-B13 cases :414-505, :727-830. |
| 174 | M.WEB.003 | `js/poll-manager.js` | **landed:** :12-13, `tick()` :150 with no guard, :142-148. |
| 175 | M.WEB.026 | `js/nav.js` | **landed:** :20-22, :38-50, :58, :90. |
| 176 | M.WEB.025 | `js/shell.js` | **landed:** :17, :24, :50, :92, :120, :159. OF-144 is still open here. |
| 177 | M.WEB.030 | `js/main.js` | **landed:** :7-9, :34-39. |
| 178 | M.WEB.031 | `js/app.js` | **landed:** :6-10, :87-92. |
| 179 | M.WEB.051 | `tests_js/poll-manager.test.js` | **landed:** :1-2, :8 tag, :376, :421, :441, :492, the one `useRealTimers` :191. |

**Marks.**
- **UART:** only step 148 touches it, and only in a test. Step 145's UART rows are docs and have landed. No step in this range changes the wire.
- **@tunable:** step 148 may add one tag. Step 157 changes values only. No `error_catalog.json` row is added.
- **Twin record:** step 172 re-records; no step in this range edits a twin-record input.

### 2. Carried actions, each placed on a step
- A.U35.23 → 146; A.U30.12 → 146 (landed)
- A.U35.56 → 147; A.U19.13 → 147 (phase C)
- A.U35.06 → 148
- A.U35.39 → 149 and 154
- A.U35.28 → 151, 160, 166 (open); 150, 167, 173 (landed)
- A.U35.31 → 152, 167, 171
- A.U35.52 → 153
- A.U35.38 → 154 (confirm), 166, 169
- A.U35.57 → 158 (and 155's blast)
- A.U35.05 → 156 (procedure)
- A.U35.25 → 157, 163, 165, 170
- A.U35.26 → 157, 164, 170
- A.U35.27 → 157, 159, 162
- A.U27.17 → 159 (conditional), 170
- A.U30.02 → 159 (nothing left)
- A.U35.24 → 161
- A.U35.09 → 168 (nothing to add)
- A.U35.49 → 172
- A.U35.46 → 174-179 (landed)
- A.U0.54 → 170 (conflict); A.U11.08, A.U30.09, A.U25.46, A.U27.08, A.U30.17 → 170

### 3. Open findings in this range's files
- **OF-144** (`js/shell.js:104-110`): open. The watch compares only against the first build it sees, and the page reads no build date. The stager already writes `<meta name="build-date">`. Joins step 176.
- **OF-215 stage 3**: open. The harness should end a twin through the runner's `--stop-file`, with SIGINT only as the fallback; this changes `shutdown()` in `scripts/_twin_process.py:366-388`. Joins step 154, with harness boots at step 155.
- **OF-229** (`scripts/record_twin_instrument_runs.py:125-131`): open. Joins step 172's re-record, or P1c's M.TWIN.054 step; P2 picks one.
- **Nearby, but not in this range's files (P2 assigns):** OF-214 (`tests_js/live-backend-put-matrix.test.js:269`; the runner plants `DNSFallback=""` at `digital_twin/unixport/_offline_ntp_config.py:27`) and OF-231 (`tests_js/mock-data-compose.test.js`).

### 4. Packet vs code
**Renamed or moved since the packet was written:**
- `_print_wdt_status` is now `_shutdown_line()` (runner :458), plus `_print_shutdown_line` (checker :69).
- `TestFlags` has 11 fields, not 7.
- `@scenario` takes `family=`, `shared=`, `moves=` and `first_device=`.
- `_fram_chip.py` is 323 lines (the packet cites :1-157).
- `UART_Comm` is now `UARTComm`.
- The heavy-file list has 10 entries, not 15, and its check landed early.
- `rate.persisted_log` is a C/F rate-table row (SPEC:6438, 627-700 ms per chunk write), not a Part N row. Step 160's bound therefore has to be derived (agent, 2026-10-21: window ÷ 627 ms × 2 block copies, stated beside the assertion).
- `l0.cross_browser_smoke_poll_ms` does not exist; the smoke's rows are the `l0.smoke_*` rows at :11742-11757.

**Conflicts.** Each is decided on the owner's behalf (agent, 2026-10-21), taking the more conservative option:
- **NTP sync on a normal boot** (steps 149, 166, 169; also P1c's M.SCR.049). Run 1 and the generated-boot smoke start with no SSID. The runner writes only the NTP config (`_offline_ntp_config.py:19-41`); the SSID is first set in Run 5 (:1226) and Run 6 (:1357). Run 1 asserts both time fields are null (suite :1090-1098; README :669-671), and SPEC:5737-5738 says "a fresh hotspot-mode boot never syncs NTP". **Decision:** the normal-boot check asserts no E or W entry, read before `l2.scenario_shared_boot_deadline_s` (SGP40's untimestamped-backup W lands after it), with no NTPSynced requirement. NTP sync stays proven at Run 5 :1236 and Run 8 :1409. The step 166 NTPSynced-bound case targets `_wait_for_ntp_sync` (:1713).
- **The wire log's "unbounded (agent, 2026-09-14)" label** (steps 157, 170; A.U0.54). The wire log is now bounded: `digital_twin/machine.py:809` `_WireLog(_WIRE_LOG_MAXLEN)`, runner :833-834, README :881. **Decision:** keep the tree's wording.

**Packet parts that belong to other units:**
- **M.SCR.046** wanted no `global` left. U27 instead added a reasoned per-file PLW0603 entry (`pyproject.toml:309-312`), and the tree keeps that.
- **I.4(e) item (6), the DebugLevel sentence,** is absent. It was U30's stage; REGISTER.md:729's owner decision governs, and P2 should rule on it.
- **The two U18 hotspot owner-question entries** are absent. They were not U35's to write.

**Not settled by reading:**
- Whether a 20/100 ms plant turns the `PollRoundClock` hammers red (step 148): run the plant.
- The sampler verdict and the Run 11 window calibration (steps 157, 162, 163, 170): the B3 runs.
- Whether a boot with no SSID logs a W inside the smoke's window: one twin boot.

### 5. Files and the steps that edit them
- `SPECIFICATION.md`: 145, 146, 147, 148, 161, 162, 163
- `tests/test_uart_comm_hazard.py`: 148
- `tests_scripts/test_digital_twin_generated_boot.py`: 149
- `digital_twin/run_generic_integration.py`: 151, 152, 157
- `scripts/_twin_process.py`: 151, 154 (OF-215)
- `scripts/_digital_twin_scenarios.py`: 152, 155 (OF-215)
- `tests_scripts/test_twin_runner_test_flags.py`: 152
- `scripts/_digital_twin_ci_suite.py`: 157, 160
- `scripts/_check_gc_collect_sites.py`: 157/165 (conditional)
- `audit/b3/{conformance,load,timing,queue_c}.md`: 153, 160, 146/147/157, 153
- `BACKLOG.md`: 158, 159
- `tests_scripts/test_digital_twin_ci_suite_soak.py`: 164
- `tests_scripts/test_digital_twin_ci_suite_errcount.py`: 166
- `digital_twin/README.md`: 167, 169, 170, 171
- `tests_hardware/twin_record.json`: 172 (plus `scripts/record_twin_instrument_runs.py` for OF-229)
- `js/shell.js`: 176 (OF-144 only)
- No edit (landed): `digital_twin/_fram_chip.py` (150), `tests/test_digital_twin_fram.py` (173), `js/poll-manager.js`, `js/nav.js`, `js/main.js`, `js/app.js`, `tests_js/poll-manager.test.js` (174-179)

**Hardware rounds:**

| Round | Item | Steps |
|---|---|---|
| R0 | H56 (speed-probe bands) | 147 |
| R1 | H44 (post-build free heap) | 147 |
| R1 | H55 (estimated l3/l4/web tunables) | 147 |
| R1 | H71 (silicon-only rung cells) | 153 |
| R1 | H83 (loaded `MemFree` floor; documentation only here) | 170 |
| R1 end | H43 (hardware memory gates turn red) | 156 |
| R4, R5 | H55 | 147 |
| phase C | release proof | 163 |

## P2

# U35 plan, block P2: cut, waves, rulings, risks, blocks (agent, 2026-10-21; read-only at 1dd6dd5)

This block used about 25 tool calls. All line numbers are at `1dd6dd5` in `S/wt-u33plan`. Nothing in the tree was edited. Helper scripts are in `S/u35/plan_scratch/p2/`:
- `of.py`: the open-findings rows routed to U35;
- `bt.py`: base times across the earlier units;
- `readers.py`: the tests_scripts readers per lane. Rerun it as `python3 -I readers.py S/wt-u33plan`.

### P2.1 Findings that change the cut (beyond P1)
- **Tags and Part N rows are paired across files.** `tests_scripts/test_tunables_register.py:250` fails on a tag that has no Part N row, and on a row that has no tag. Lanes change tags, but SPEC is D's file:
  - step 48 withdraws `l1.asy_notification_service_override_bound_ms`;
  - step 76 adds `l1.bus_fault_isolation_bound_s = 5`;
  - steps 114, 125 (f), 125 (i) and 148 may add tags.
  - Handled by R-17.
- **The explicit-`Any` residue is tied to four config files.** Its lines are in `pyproject.toml` (ANN401 entries :261-276, baseline :417-433), `digital_twin/typecheck.ini:32-40`, `host_typecheck.ini:43-52` and `tests_scripts/test_mypy_any_baseline.py:16-34` (`_RESIDUAL`).
  - The "same commit" rule ties each module to those lines. Five of the 13 modules also carry U35 steps: `_bus_hazard_catalog` (28, 29), `test_bus_hazard_multi_device` (6, 73, 74, 76, 77), `_sensortask_scenarios` (114), `test_asy_uart_comm` (59) and `test_asy_uart_driver` (60, 61).
  - So lane Y holds the config files, the bus family and the scenarios. The two UART files are handed from lane U to Y (R-16).
  - `pyproject.toml` and both inis are not in U35's work-order files (U36 and U37 hold them). The brief and U34 R-2 route these removals here; logged (R-15).
- **The fifth step-2 dependency.** `asy_crc_checks` is imported by `src/asy_fram_manager.py`, `asy_framing_codecs.py`, `asy_print_log.py`, `asy_scd30_driver.py`, `asy_sgp40_driver.py`, `asy_uart_driver.py` and by `buildgen/buildspec.py` and `codegen.py`. Steps 20, 21 and 23 therefore reach every device. Only invalid polynomials change behaviour.
- **Every device has FRAM.** All six `devices/*.toml` wire `driver = "fram"`, so OF-167 and OF-225 reach every device.
- **OF-225 needs no extra copy.** The config flush already serialises before the open (`src/asy_config_manager.py:399`, `:584`), so chunking adds no whole-document copy.
- **DrivenTime importers.** `DrivenTime` (`tests/_fake_time.py:15-37`) is imported by 9 files. P1b's count of 8 left out `tests/test_shared_helpers.py`, whose `:168-300` self-tests the ticks-only part.
- **OF-233's sixth site is not U35's.** FX8 found the same hazard at `tests/test_ticks_rollover.py:223-229`. In work_order.json that file is U37's, and it is outside OF-233's five files.
- **OF-32's test file.** `tests/test_digital_twin_machine.py` is U36's next file. U35's `tests` entry covers it, and OF-32's seen-failing test lives there.
- **Runner hash.** `runner_sha256` covers only `run_device_script.py` and `twin_board.py`. T's runner edits do not make the twin record stale; H1's comment citation in `run_device_script.py` does (the lead re-records anyway).
- **OF-226's row** still names U33 (`audit/sweeps/open_findings.md:234`). The brief routes it here, so the lead re-points the row.

### P2.2 The cut (one owner per file at a time; at most five agents at once)

The base is U34's close head (`1dd6dd5`, unless U34's squash changes the tree; the lead sets it). Times are "base to measure" unless they come from `S/u32/base_times.tsv` (written "U32 a/b" = seconds at -1/32768). Earlier units' figures are given for balance only.

**Lane C: core time and cancel sweeps**
- **Files:**
  - tests/_fake_time.py
  - tests/test_driven_time.py (new)
  - tests/_cancel_sweep.py (new)
  - tests/_ntp_frames.py
  - tests/test_shared_helpers.py
  - test_asy_{dns_client, ntp_client, udp_socket, webserver_connections, wifi_service, captive_dns, base_classes, bmp3xx_driver, isl29125_driver, scd30_driver, fram_driver}.py
  - a guard file, only if R-28's guard can be made deterministic.
- **Steps written:** 32 and 97 (<CORE>), 36 (<SWEEP>), 57, 40, 55, 56, 64, 65, 66, 67, 71, 79, 39, 41, 52, 58.
- **Steps checked:** 30, 31, 38, 50, 51, 54, 63, 68, 69 (read :1593-1694), 70, 72, 115, 117.
- **Findings:** OF-81 (R-11), OF-211 (R-28).
- **Size:** about 700 lines in 17 files.
- **Runs, both stages, all base to measure.** Earlier figures: ntp 23.9/25.6 (U30), captive 25.6/25.6 (U30), wifi 24.4/24.7 (U31), scd30 22.1/28.9 (U31), bmp3xx 13.7/13.8 (U31), udp 7.2/7.2 (U31), isl 2.6/3.5 (U30), webserver_connections 1.2/1.3 (U31), base_classes 0.9/0.5 (U31), dns 0.8/0.8 (U30). fram_driver and shared_helpers have no earlier figure; test_driven_time is new (after-time only).
- **Readers:** import_placement, microtest, radio_shape_corpus, plus the repo-wide scans of the common brief.
- **Seen failing first:**
  - the shim self-test bitten by planted off-by-ones in `advance` (a sleeper due at n+1 must stay parked), `run_until`, `jump` and `wait_for_ms`;
  - <SWEEP> names a planted path that leaks a socket or leaves a lock unbalanced on cancel;
  - 56: `assert await server.serve_once(reply) is True` fails against today's `-> None` (`tests/_ntp_frames.py:36`);
  - 41: `advance(999)` not done, `advance(1)` gives False, bitten by a bound 1 ms short;
  - 39: the BMP interleaving reproduced on a planted unlocked read;
  - each sweep (40, 55, 65, 67, 71, 79) fails on a planted missing cleanup;
  - the OF-81 pin fails on a planted double release.
- **Depends on:** nothing. C publishes <CORE> first, then <SWEEP>.

**Lane N: notification and neopixel driven time (OF-233)**
- **Files:**
  - tests/test_asy_notification_service.py
  - tests/test_asy_neopixel_driver.py (on 970b63b)
  - tests/test_notification_{neopixel, scd30, sgp40, scd30_sgp40}_integration.py
  - tests/test_neopixel_wifi_integration.py
  - tests/test_digital_twin_network_neopixel.py
- **Steps written:** 43, 44, 45, 46, 47, 48 (tag withdrawn), 49, 53, 87, 88, 89, 90, 99; 86's `setup()` calls only (R-3).
- **Findings:** OF-233 (R-13).
- **Size:** about 400 lines in 8 files.
- **Runs:**
  - neopixel U32 9.56/9.55 (FX8's after-times 7.25/7.29);
  - the rest base to measure. Earlier (U31): notification service 19.0/19.1, network_neopixel 15.6/15.6, notification_neopixel 6.4/6.4, notification_scd30 4.5/4.5, scd30_sgp40 4.2/4.2, sgp40 2.9/3.2, neopixel_wifi 2.7/2.8.
- **Readers:** import_placement, ticks_wrap_scan, tunables_register.
- **Seen failing first:**
  - every converted assertion bitten by a planted driver, at both stages (FX8's method: no restore, the lock ignored, t truncated);
  - 44: `>= 30` becomes `== 31`;
  - 48: the bound read through `src_int` (:1280).
- **Depends on:** <CORE>; <PARTN> merged before N2's reader run.

**Lane U: UART tests**
- **Files:**
  - tests/test_asy_uart_comm.py and tests/test_asy_uart_driver.py, until <HANDOVER-UART>
  - tests/test_asy_uart_link_driver.py
  - tests/test_digital_twin_uart_link.py
  - tests/test_uart_comm_hazard.py
- **Steps:** 59, 60, 61 (U1); 62, 100, 148, plus the plant evidence for 144 (U2).
- **Findings:** none worked (R-12).
- **Size:** about 200 lines.
- **Runs:**
  - U32: uart_comm 61.39/62.22, link_driver 2.35/2.43, twin uart_link 55.35/59.39, hazard 104.88/108.69, cancel_sweep 40.17/40.10 (reader);
  - uart_driver base to measure (U30 5.94/9.80).
- **Readers:** import_placement, mypy_any_baseline, suppression_form, uart_changelog.
- **Seen failing first:**
  - each sweep on a planted missing cleanup;
  - 60's Event (cancel in `finally`) on a planted leak;
  - 100's 140-byte `uart_set(0x02, …)` with a planted drop;
  - 148: the 20 ms and 100 ms plants, made in a throwaway worktree, turn the `PollRoundClock` hammers (`tests/_uart_comm_harness.py:122-158`) red. If they do not, U2 adds a bound test and the tag `l1.uart_comm_hazard_clean_transaction_virtual_ms`, relayed to D.
- **Depends on:** <SWEEP>.

**Lane P: product (`src/`) and persistence**
- **Files:**
  - src/asy_crc_checks.py, tests/test_asy_crc_checks.py
  - UART_C_PORT_CHANGELOG.md, src/asy_uart_comm.py
  - tests/test_math_helpers.py
  - src/asy_fram_manager.py, tests/test_asy_fram_manager.py, tests/_fram_chip_fake.py
  - tests/test_asy_system_service.py, tests/test_digital_twin_fram.py
  - src/asy_config_manager.py, tests/test_asy_config_manager.py
  - src/asy_print_log.py, tests/test_asy_print_log.py
- **Steps written:** 20, 21, 23 then 85, 22 (B87 and B88), 24-27 plus the :712 comment, 119, 35 (the copy at test_asy_system_service.py:1043-1079 swapped for the shared fake).
- **Steps checked:** 12-19, 42, 80-84, 93 (read :827-900), 94-96, 113.
- **Findings:** OF-167 and OF-60's read-path half (R-8), OF-225 (R-9), OF-221 (R-10), OF-184 (R-12).
- **Size:** about 400 lines.
- **Runs:**
  - U32: system_service 24.92/26.40, twin_fram 0.58/0.69, ntp_fram_system (reader) 7.63/7.68, twin integration[dev] 22.95/23.65 as the product smoke;
  - base to measure: crc, math (U28 0.02/0.03), fram_manager, config_manager (U30 0.20/0.28), print_log (U30 0.31/0.56).
- **Readers:** api_reference, build_firmware, buildgen_{driver_registry, error_contract, frozen_modules, generate, limits, source_agreement, validate}, code_conventions, config_schemas, counter_steps, device_script_config_schemas, digital_twin_ci_suite_errcount, digital_twin_scenarios, exception_handler_contract, fake_surface_conformance, fatal_report_sites, fault_or_warning_never_both, fram_chunk_crc_sites, fram_chunk_owner_sites, import_graph, import_placement, js_api_mirrors, lint_ceilings, memory_catalog, microtest, persistence_write_marker_completeness, readiness_gates, result_words, setter_contract, stored_config_golden, suppression_form, task_tops, timing_budget, uart_changelog, watchdog_feed_sites; also lock_order (R-8).
- **Seen failing first:**
  - 23 and 85: `CRCBase(1, 0x1FF, ">B")` still reports `length()` 1 (src/asy_crc_checks.py:24-28, :155-158); one case per width plus the pass-through case;
  - 119: the stand-in `ArithmeticError` cases fail with the except narrowed;
  - OF-167: the twin's undriven read (`digital_twin/_fram_chip.py:266-267`) and the L1 fake read as blank (False), where the test expects lost;
  - OF-225: a stalling fake file exceeds a loop-stretch bound set near one erase;
  - OF-221: the two-overlapping-resets case.
  - 20 and 21 are dead-code removals: the existing tests stay green and the E.5.1 register records the change.
- **Depends on:** nothing. The mpy-cross byte compare of every `src/` file it touches (U34 precedent).

**Lane T: twin runner, harness, CI suite, twin README**
- **Files:**
  - scripts/_digital_twin_ci_suite.py, scripts/_digital_twin_scenarios.py, scripts/_twin_process.py, scripts/_check_gc_collect_sites.py
  - digital_twin/run_generic_integration.py, digital_twin/README.md
  - tests/test_digital_twin_sensortask_integration.py
  - tests_scripts/test_twin_runner_test_flags.py, test_digital_twin_ci_suite_soak.py, test_digital_twin_ci_suite_errcount.py, test_digital_twin_generated_boot.py, test_gc_collect_sites.py
- **Steps written:** 151, 152, 154 (T1); 118, 157 (1)-(3), 160, 164, 166 (T2); 125, 149, 124, 155 harness (T3); 157 (4), 165, 167, 169, 170, 171 (T4).
- **Steps checked:** 109, 156, 168.
- **Findings:** OF-215 stage 3 (R-27), OF-149 and OF-188 (R-26).
- **Size:** about 660 lines.
- **Runs:**
  - twin integration per device (U32 a/b): arzi 119.08/118.64, dev 22.95/23.65, grkizi 21.65/22.05, klkizi 21.69/21.89, schlafzi 21.64/21.66, wozi 22.14/22.31;
  - `run_digital_twin_ci.sh` for dev and arzi at both stages, base to measure. All six devices run at the lead's gate.
- **Readers:** bench_restores_serving, citations, conftest, device_script_bench_facts, device_tomls, digital_twin_ci_suite_{ceiling, errcount, matrix, soak, state}, digital_twin_generated_boot, digital_twin_scenarios, exception_handler_contract, gc_collect_sites, harness_mpremote_retry, import_placement, legacy_paths, level_containment, lint_sh, live_command_device_args, no_variant_literals, persistence_write_marker_completeness, port_bands, request_timeout_ceiling, run_digital_twin_ci_sh, run_unix_port_integration_sh, setup_toolchain_env, stripped_image_boots, test_sh, twin_board, twin_entry_point_order, twin_never_needs_tests_on_its_path, twin_process_js_spawn, twin_process_spawn, twin_runner_test_flags, twin_wiring_contract.
- **Seen failing first:**
  - `fram_writes*` parser cases;
  - the flag table, until `--test-watchdog-fault` and `WDT_AT_FAULT` exist;
  - a planted W fails Run 1, and the reformat relaunch logs exactly one W `CONFIG_LOST`;
  - the backwards-clock fixture (164);
  - a planted excess write rate (160);
  - one W, and one NTP entry, each fail the normal boot (149, 166);
  - a planted public destination fails test 2 (124);
  - the stop-file path (OF-215).
- **Depends on:** nothing for T1; <SHUT> (T1) before T2 and T3; B2's figures before T4.

**Lane H: hardware tier and twin-record script**
- **Files:**
  - tests_hardware/bench/test_end_to_end_timing.py
  - tests_hardware/device_scripts/bus_topology_autodetect_and_hazard_sweep.py, tests_hardware/device_scripts/_shared/bus_reader_loops.py
  - tests_hardware/flash/test_bus_concurrency.py
  - tests_hardware/bench/test_memory_stress_bench.py, tests_hardware/device_scripts/loop_lag_under_combined_load.py
  - digital_twin/run_device_script.py (comment only)
  - scripts/record_twin_instrument_runs.py, tests_scripts/test_twin_record.py
  - tests_hardware/twin_record.json (H2's shape proof only)
- **Steps written:** 3 (R-7), 5 with OF-02 and OF-05, OF-226 (R-14), 122's citation (R-25), 140 with OF-229 (R-20).
- **Steps checked:** 1, 2, 7, 101, 103, 127, 129-133.
- **Size:** about 150 lines.
- **Runs:** no GC-stage files. `pytest --collect-only tests_hardware`; the twin runs of the changed scripts; the device-script mypy pass; test_twin_record.
- **Readers:** digital_twin_scenarios, exception_handler_contract, level_containment, memory_error_gate_agreement, tests_hardware_persistence_write_gating, twin_record, plus every device_scripts reader (U32 lane T's list).
- **Seen failing first:**
  - the host check requires at least one sent broadcast (flash/test_bus_concurrency.py:232-245), bitten by an all-NAK twin;
  - an out-of-bounds SCD30 reading is caught (bus_reader_loops.py:79-81);
  - OF-229: a sibling test broken in a scratch copy is charged only to its own scripts.
- **Depends on:** nothing.

**Lane Y: typing residue, bus-hazard family, sensortask scenarios**
- **Files:**
  - pyproject.toml, digital_twin/typecheck.ini, host_typecheck.ini, tests_scripts/test_mypy_any_baseline.py
  - tests/machine.py, digital_twin/machine.py, tests/test_digital_twin_machine.py, src/asy_system_service.py
  - tests/test_bus_hazard_generated.py, tests/test_digital_twin_bus_hazard_concurrency.py
  - tests_hardware/conftest.py, tests_hardware/device_scripts/serving_at_default_gc.py, tests_scripts/test_cross_browser_smoke_probe.py
  - tests/_bus_hazard_catalog.py, tests/test_bus_hazard_multi_device.py
  - tests/_sensortask_scenarios.py, tests/test_sensortask.py
  - from <HANDOVER-UART>: tests/test_asy_uart_comm.py and tests/test_asy_uart_driver.py
- **Steps written:** 6, 28, 29, 73, 74, 76 (adds the tag), 77, 114, the residue (R-15), OF-32 (R-30), OF-200 (R-31).
- **Steps checked:** 33, 121, 123 (this run settles whether reset-reachable cases catch `SimulatedRebootError`).
- **Size:** 183 `Any` sites (T1's list) and about 450 lines of step work.
- **Runs:**
  - U32: twin bus hazard 150.15/152.79; test_sensortask per device arzi 36.89/33.50, dev 46.32/53.94, grkizi 28.91/32.62, klkizi 28.40/33.11, schlafzi 28.94/33.24, wozi 32.31/37.63; uart_comm 61.39/62.22;
  - base to measure: bus_hazard_generated (U30 63.6/64.3), bus_hazard_multi (U30 3.3/3.6), twin machine, uart_driver;
  - `scripts/typecheck.sh` after every module commit.
- **Readers:** 77 in all (readers.py). They include pyproject's readers (ci_workflow, config_paths_resolve, host_annotations, lint_ceilings, lint_type_scopes, mypy_any_baseline, no_variant_literals, preview_server, ruff_exemptions_live, script_metadata_pins, suppression_form, tool_pins, typecheck_sh), fake_surface_conformance, twin_fake_catalog, the system-service readers (U32 lane C's list) and the device-script readers.
- **Seen failing first:**
  - OF-32: a twin `ticks_us` driven past 2**29 misreads;
  - 73: a switch planted outside the window is named;
  - 76: a planted `bus_lock` leak;
  - 114: each group bitten by a planted defect (the WDT fed despite a stuck task; a FRAM write storm over its bound).
  - The `Any` removal has no seen-failing case; its proof is the three passes plus ruff_exemptions_live and mypy_any_baseline.
- **Depends on:** <PARTN> (Y2), <CORE> (Y4), <HANDOVER-UART> (Y3).

**Lane D: documents**
- **Files:** SPECIFICATION.md, BACKLOG.md, tests_hardware/README.md.
- **Steps written:** <PARTN> (rows for 48 and 76), 4, 8, 9, 10, 34, 37, 111, 112, 116, 126, 128, 142, 143, 144 (J.7), 145, 146, 147 and 105 (Basis cells), 158, 159 (conditional), 161, 162, 163. Also R-23's I.4(e)(6), R-28's E.1, R-9's J.6, R-8's FRAM sentence, and :3794's actor form.
- **Steps checked:** 11, 13, 110, 135.
- **Readers:** 110 (they are the lead's tier). D3 runs citations, decision_vocabulary, legacy_paths, comment_block_cap, tunables_register, timing_budget, memory_catalog, lock_order and task_inventory.
- **Depends on:** D2 on the integration head plus B1's step-108 run; D3 on B2.

**Lane W: web and tests_scripts hygiene**
- **Files:**
  - js/shell.js, tests_js/shell.test.js (base 970b63b)
  - tests_js/mock-data-compose.test.js, tests_js/live-backend-put-matrix.test.js
  - tests_scripts/test_definitions_js_mirrors.py, test_host_text_encoding.py, test_port_lock.py, test_tool_help.py, _repo_scan.py, test_lint_ceilings.py, test_device_script_config_schemas.py
- **Findings worked:** OF-144, -231, -214, -197, -199, -206, -207, -212 (R-29).
- **Steps checked:** 174-179.
- **Size:** about 250 lines.
- **Runs:** the full web tier in its own network namespace, never beside a MicroPython tier; test_citations (U34 13.3 s; OF-206 must bring it under 10 s).
- **Readers:** the 28 that readers.py lists, plus the repo-wide scans.
- **Seen failing first:**
  - a reflash between page load and the first watch is seen;
  - a planted format the compose branches miss is named;
  - a new put-matrix skip fails until listed;
  - a planted non-literal `encoding=` fails;
  - a stray ruff ahead on PATH fails;
  - a skipped schema site is named.
- **Depends on:** nothing.

**Lane B: B3 records and measurements**
- **Files:** audit/b3/* (new; A.U35.01 opens the directory), audit/sweeps/ticks30_build.sh (new), scripts/test.sh.
- **Steps written:** 102 (PROC.022), 104, 137, 138, 141, 153, 108 (B1); timing.md (A.U35.23), load.md (160), 107 and 120's re-measure, 136's bite, gate and wear procedures, 156 (A.U35.05), the Run 11 calibration and l0-l2 basis measurements (B2).
- **Steps checked:** 106, 109; 102's SCR.024 (lint.sh, run at the gate).
- **Readers:** _devices, build_firmware, ci_workflow, conftest, coverage_runner, device_script_fram_regions, device_tomls, digital_twin_boot_contiguity, hardware_runners, level_containment, memory_error_gate_agreement, micropython_overrides, microtest, port_lock, render_coverage_anchors, retry_counts, setup_toolchain_env, summary_block, test_sh, threshold_runner, tool_help, twin_record.
- **Seen failing first:**
  - the 2**30 build trips OF-32 at base and passes after Y's fix;
  - each memory gate turns red on a planted `MemoryError` in a throwaway worktree, its message worded clear of both markers.
- **Depends on:** B1 on nothing; B2 on the lead's W6 gate.

**Lead:** the twin-record re-record (134, 136, 172), the tests_scripts tier, the OF and REGISTER rows, and CI after the push (OF-71's CI times).

### P2.3 Waves and order (at most 5 blocks at once)

**Waves:**
- **W0 (lead):** set the base, prove the file sets disjoint (handovers included), and open `S/u35/relay.md` with sections C, N, U, P, T, H, Y, D, W, B.
- **W1:** C1, D1, P1, T1, Y1.
- **W2:** C2, N1, U1, Y2, T2.
- **W3:** C3, N2, U2, Y3, B1.
- **W4:** N3, P2, T3, Y4, H1.
- **W4 (lead, 2026-10-21, note 19):** F1, Q1, E1, C4, N2, U2, then P2b, T2b, Q2, E2, C5, N3, Y4 after `<CLOCK>`.
- **W4-W5 (lead, 2026-10-21, note 20):** V1, G1, Y4, then Y5, and V2 after `<HANDOVER-SCEN>` and `<CLOCK>`, then V3.
- **W5:** P3, Y5, H2, W1, W2.
- **W6 (lead):** merge C, N, U, P, T1-T3, Y, H, W, D1 and B1 into `audit/u35-int`; rebuild; re-record the twin record at both stages; run the full gate at both stages (unit tier, twin per device, coverage, web tier). Its per-file times feed timing.md.
- **W6 lead item (lead, 2026-10-21, LEAD NOTES 49):** on the merged head, tests/_sensortask_scenarios.py's dev
  sensors set (U3d: `{SGP40, UARTLINK}` at :2491 on U's branch) gains the initiator's maintenance name `UART_init`
  when `_has_uart_link`, seen red on the merged head first; its :2728 red on U's branch is C4's, fixed by V2's
  `83c9475` and resolved by the merge.
- **W6 lead item (lead, 2026-10-21, LEAD NOTES 51):** tests_js/_put_field_cases.js:56's comment ("status's only
  field (ResetErrors) is dispatch-only") goes stale on dev once lane U merges; the lead restates it on the merged head
  (no lane holds the file).
- **W6 lead item (lead, 2026-10-21, LEAD NOTES 55):** every test stand-in for an NTP sync (`_set_synced(value=True)`:
  tests/test_notification_neopixel_integration.py, tests/test_digital_twin_sensortask_integration.py,
  tests/test_asy_ntp_client.py) is checked on the merged head; one that stands for a real sync and reaches UTCTime or a
  VOC backup also sets the clock-valid flag `_handle_ntp_sync_success()` sets, seen red there first.
- **W6 lead items (lead, 2026-10-22, LEAD NOTES 66):** on the merged head the put matrix's `NOT_DRIVEN` gains a
  stale-row check (a listed action the definitions no longer declare fails), seen failing on a planted stale row; and
  tests_js/source-constants.test.js (no lane) gains a `readStringSetConst` case, seen failing first.
- **W7:** B2, alone on the host for the timing runs (CHECKLIST 12).
- **W6 lead item (lead, 2026-10-21, LEAD NOTES 38):** on the merged head, `tests/_cancel_sweep.py`'s lock check gains
  E1's counting lock so a double release shows (a check strengthened), seen failing on E1's planted double release, and
  every sweep is re-run at both stages before the gate.
- **W8:** T4 and D2.
- **W9:** D3.
- **W10 (lead):** merge; rerun Run 11 per device at both stages, test_test_sh, then the tests_scripts tier once; push; watch CI. Then stop for the owner's order of hardware session 1 and the U36/U37 document work (L-5).

**Dependencies, each with its reason:**
- **Step 32 (<CORE>) before** 41, 43-49, 53, 64, 66, 87-90, 99, 114 and 143's "time at L1 is driven". They need virtual sleeps and `wait_for`; today `DrivenTime` swaps only `time` (`tests/_fake_time.py:24-37`).
- **Step 36 (<SWEEP>) before** 40, 55, 59, 61, 62, 65, 67, 71, 79 and OF-81's pin. They are all sweeps over that helper.
- **Step 57 before 56.** `serve_once` returns `None` today (`tests/_ntp_frames.py:36`).
- **Step 108 before 112.** The sentence reports that run (REGISTER.md:414).
- **Step 151 before 125 (h), 160 and 166.** They read the `fram_writes*` fields, which are absent from `_shutdown_line()` (runner :458-467).
- **Step 152 before 125 (f) and 171.** The flag must exist first.
- **A.U35.01 (B1's first commit) before 137, 138, 141 and 153.** `audit/b3/` is absent.
- **M.SRC_CORE.131 (23) before 85's new cases.** They fail until the width fix lands.
- **Prerequisites for later SPEC text:**
  - 143 before 128 (E.2.3 must exist);
  - 125 (g) before 126 (the BACKLOG bullet goes once the recombination exists);
  - U2's plant before 144's J.7 sentence;
  - Y4's scenarios before 34;
  - C's sweeps before 37.
- **Every `src/`, device-script, flash or bench file and runner edit before the W6 re-record.**
- **B2 before 107, 146, 147, 157 (4), 161 (3), 162 and 163.** They need measured values.
- **P3 before J.6 (R-9); P2 before the FRAM sentence (R-8).**

**First commits other lanes need:**
- <CORE> (C1's first): the shim and test_driven_time.
- <SWEEP> (C1's second).
- <PARTN> (D1's first).
- <SHUT> (T1): the runner and `ShutdownLine`.
- <T30> (B1): ticks30_build.sh, for Y's OF-32 confirmation.
- <HANDOVER-UART> (U1's last): relay line `<HANDOVER-UART> <hash>`; U never edits those two files again.

### P2.4 Rulings draft (agent, 2026-10-21)

**Process rulings**
- **R-1 The cut** as in P2.2.
- **R-16 Handover.** test_asy_uart_comm.py and test_asy_uart_driver.py pass from U to Y at U1's end. Only one owner holds a file at any time.
- **R-17 <PARTN>.** D1 writes the Part N rows for the tag changes known now (48 and 76). A tag decided during execution is relayed as `<TAG name value basis>`. Until the lead merges D's row, that lane's tunables_register run is red on that one named row only (test_tunables_register.py:250).
- **R-21 B3 measurement is lane B, not the lead's.**
  - B1 writes the B3 documents from the records: intent, levels, conformance (from `audit/actions/SUPP_recovery.md`), queue_c, raising, and the 2**30 build.
  - B2 measures on the integration head: timing.md from the gate logs at both stages, load.md, the Run 11 calibration and the l0-l2 Basis values.
  - The lead's gate is B's input; the B documents are writing work.
- **R-33 Check-only steps** are verified on the base by their lane's first block and again at the gate.

**Rulings applying L-1 to L-4**
- **R-2 (L-1).** <CORE> extends `DrivenTime` in place. Its opt-in parts are tested in test_driven_time.py. The ticks-only cases at test_shared_helpers.py:269-300 stay, because they test the default, which is unchanged. N1 and C2 delete the local `_YieldOnlyAsyncio`/`_DrivenClock` copies (neopixel 970b63b:59-105; webserver connections :968).
- **R-3 Step 86.** Write the `setup()` calls. `_run_until` (:45-52) stays: it reads no clock. Step 94 is check-only (test_asy_system_service.py:121-123 uses the default).
- **R-4 (L-2).** Applies to 118, 149, 166 and 169: no E and no W entry, read before `l2.scenario_shared_boot_deadline_s`. 166's NTPSynced case targets `_wait_for_ntp_sync` (suite :1713). Run files go under `ctx.logs_dir/"runs"`. This settles every NTP conflicts row (P1c 118; P1d 149, 166, 169).
- **R-5 (L-3).** 157 and 170 keep the tree's wire-log wording.
- **R-6 (L-4).**
  - 128 lands in D2 after 143.
  - The non-dict test at test_asy_config_manager.py:1981 stays (settles P1b's 81/83 conflict).
  - Names follow the tree: `neopixel_freq` (src/asy_neopixel_driver.py:83), `UARTComm`, `FakeNtpServer(port, *, poll_ms, poll_tries)` (tests/_ntp_frames.py:22).
  - Step 53's `debug=4` (:55) stays while the constructor takes it.

**R-7 Torn-write mapping (step 3)**
- `allowed_errors=(code("E", "FRAM_STATUS_BYTE"),)` and `allowed_warnings=(code("W", "FRAM_BLOCK_INVALID"),)`. Not `FRAM_STATUS_WRITE`.
- Settled by message identity: `699836e` E31 "Read status byte is not idle but X" matches the catalog's "a block status byte is neither idle nor uninitialised"; W71/W72 "Invalid data in block 0/1" match "a chunk block held invalid data; it is repaired from the other copy" (buildgen/error_catalog.json).
- Proven on silicon at R3, H68.

**R-8 OF-167 and OF-60's read-path half: the blank chunk against an undriven bus**
- The fix: when a block's status byte reads blank (`_STATUS_UNINIT = const(0x00)`, src/asy_fram_manager.py:28; `_read()` :197), P2 probes with `verify_present()` (RDID; src/asy_fram_driver.py:477-502).
  - If the chip answers, the block is blank, as today.
  - If it does not, the existing lost path and chip watch take over.
- The probe runs after the read has released the SPI lock (lock table, SPEC :3770). Its buffer is preallocated.
- The non-zero blank marker is not taken: it changes the FRAM layout and needs a migration.
- Per device and bus: all six devices, on the FRAM's SPI bus. There is one RDID transaction, and only on a blank read.
- What it closes:
  - a silent chip during a read-only stretch is now found at its first read, not at the next write;
  - a dropped READ opcode with the chip still answering stays covered by L1's wire-trace tests (tests/test_asy_fram_wire_trace.py).
- OF-60's silicon latency stays R2 H17.
- Settled by CLAUDE.md's rule for decisions during execution (conservative, reversible, grounded in sources), reuse-first (G), and MB85RS64V p10. Decided on the owner's behalf and logged for review.

**R-9 OF-225: the config flush in chunks**
- Both sites, :399-401 and :584-586, use one helper: fixed-size slices of the text that is already serialised, with a yield between slices. No `flush()` or `sync` between chunks.
- P confirms littlefs's commit-at-close semantics against v1.29.0's `lib/littlefs` before writing.
- D re-derives J.6 and `uart.rx_ring_floor` from P's relayed figures. dev's configured ring stays as it is, since the floor can only fall. If B68's threshold moves, P adds a Class B changelog row.
- Settled by the finding's own plan and F.3.

**Rulings on the other findings**
- **R-10 OF-221.** Write the test first; fix `src/asy_print_log.py` only if it fails.
- **R-11 OF-81.** A pin, with no product change: <SWEEP>'s lock-balance invariant, plus a pin in test_asy_base_classes.py.
- **R-12 Findings with no code in U35:**
  - OF-70: waits on R2 H37, which comes after U35;
  - OF-184: no code (agent, 2026-10-14); its file changes only under R-15;
  - OF-232: U37; OF-223: U36 (U32 R-16); OF-180: owner question 5; OF-181: waits on R1;
  - OF-150 and OF-71: B2 measures, and the lead reads the CI times from U35's push. Their cause is the product's allocation volume, in no U35 file.
- **R-13 OF-233** is lane N's work. The lead adds test_ticks_rollover.py:223-229 to the row for U37.
- **R-14 OF-226.** The bench loop-lag run gains the twin's HTTP load (scripts/_digital_twin_scenarios.py:1038) and asserts its evidence the way the twin does. U35 only collects it; it runs at R1 (H83).

**R-15 The explicit-`Any` residue**
- 13 modules, each cleared in one commit together with its baseline line, its ANN401 entry and its `_RESIDUAL` row:
  - `_sensortask_scenarios`, `test_asy_uart_comm`, `test_asy_uart_driver`, `_bus_hazard_catalog`, `machine` (tests/), `test_bus_hazard_generated`, `asy_system_service`, `test_bus_hazard_multi_device`;
  - `machine` (twin pass), `test_digital_twin_bus_hazard_concurrency`;
  - `test_cross_browser_smoke_probe`, `conftest`, `serving_at_default_gc`.
- `scripts._hardware_verdict` stays: its one site comes from the bare import at :22, which U34 R-4 sends to U37. `_boot_contiguity_probe` and `_uart_link_contract` are U36's.
- A module that cannot lose its `Any` without a cast or an ignore stays listed with its sites (U34 R-2's form).
- When the twin pass empties, digital_twin/typecheck.ini's :35-36 comment and the clause at :32 go with it.

**R-18 UART: the wire stays untouched (owner, 2026-09-25)**
- Steps 24-27 are comments only, plus the :712 comment (D.10).
- Step 25's comment reads "kept: it guards the copy into a caller's buffer".
- B87 covers steps 20 and 21; B88 covers step 23. Both are Class B.
- Steps 59-62, 100 and 148 are test-only. If a sweep finds a defect, its row goes through P.

**Rulings on placement and smaller points**
- **R-19** 67's sweep goes in test_asy_webserver_connections.py, which holds `_serve()`'s test doubles. 66 swaps that file's clock for <CORE>.
- **R-20 The twin record.**
  - H2 adds the second GC stage (step 140) and the OF-229 fix, and proves the new shape on its branch.
  - The lead re-records once at W6, at both stages, after every input is final (134, 136, 172).
  - B2 reviews every exception and runs the bite, gate and wear checks into conformance.md (A.U35.03, .05, .49, .51).
- **R-22 The Run 11 sampler (157 (3), 163, 165).** B2's sparser-sampling run decides whether the sampler keeps its `gc.collect()`. If no interval gives the same verdict, D2 enters owner question 8 (step 159) and the collect stays (owner, 2026-09-26: the twin's one exception).
- **R-23** I.4(e)(6) states the landed DebugLevel state (REGISTER.md:729; owner, 2026-10-20: "Option 1 is good").
- **R-24 Other agent proposals, accepted:**
  - P1a: the :712 comment; step 34's codec sentence lands in U35 if the tree holds it; B88.
  - P1b: the C.14.2 pointers stay.
  - P1c: 143's hygiene sentences stay where they are; U24's tracer classes are added to E.5.1 (paragraph :5220-5230) inside step 111.
  - P1d: 160's bound is derived as window ÷ 627 ms × 2, stated beside the assertion; the PLW0603 entry (pyproject.toml:309-312) stays; 149 asserts the boot order at the booted level too.
  - Stale-doc rule: :3794's actor form.
- **R-25** H1 adds the missing `machine_wdt.c:43-57` citation to run_device_script.py:122.
- **R-26 OF-149 and OF-188.** T4 runs the twin integration file once per device under build-settrace. No change unless one reproduces.
- **R-27 OF-215 stage 3** is T1's: `shutdown()` (scripts/_twin_process.py:366-388) uses `--stop-file`, with SIGINT as the fallback.
- **R-28 OF-211.** C2 tries to build a deterministic guard. If it cannot, it reruns the held-responder audit over every socket file. D2 states the E.1 rule.
- **R-29** OF-144, -197, -199, -206, -207, -212 (its schema half), -214 and -231 go to lane W (the fallback rule).
- **R-30 OF-32.** Y re-anchors `_epoch_us` (digital_twin/machine.py:900, :930). It is seen failing first in test_digital_twin_machine.py and confirmed on <T30>.
- **R-31 OF-200.** Y5 profiles one device at 32768 first; any fix lands only in a U35 file.
- **R-32** Hardware stays parked: the list is below.
- **R-34 For the owner:** nothing now; one conditional item (R-22).

### P2.5 Risks
- **Every mode:**
  - CRC widths come from the validated polynomial; every valid configuration is byte-identical.
  - The UART wire (dev only) is untouched.
  - The FRAM probe (R-8) runs only on a blank read.
- **STA and AP:** a config-persisting PUT (OF-225) stretches the loop by about one sector erase instead of up to 2129 ms. The UI watch (OF-144) now sees a reflash that happens between page load and its first watch.
- **Silent:** no API, so no runtime flush.
- **Off:** the boot write at :584-586 runs inside the setup batch, which already feeds the watchdog.
- **USB:** a silent FRAM chip prints its lost-chip line at the first blank read, instead of a run of CRC and block-invalid lines.
- **Frozen image:**
  - asy_crc_checks (steps 20, 21, 23);
  - asy_uart_comm (24-27 and :712: line tables only);
  - asy_fram_manager (R-8) and asy_config_manager (R-9);
  - asy_print_log (only if R-10's test is red);
  - asy_system_service (annotations only; mpy-cross is expected to show no change);
  - the frozen website (js/shell.js).
  - Nothing in `ext/` or `buildgen/` changes. Firmware is final at U35's end (REGISTER.md:691/:722), so all of this must land before W6.
- **Memory gates:**
  - all four read zero at -1 and 32768, and the coverage leg too;
  - the shim's sleeper queue is bounded;
  - the sweeps' allocation churn passes at -1 with no `gc.collect()` prop;
  - OF-225 adds no copy;
  - step 157 (3) touches the gc-collect checker row (:68).
- **Timing:**
  - Expected faster: lane N's files, network_neopixel's two 1.0 s windows, and udp :1631.
  - Growth risks:
    - the sweeps (ntp, captive, wifi, uart_comm): driven time and bounded pollers only;
    - test_sensortask per device (114, already above the 10 s bar, OF-200): forty_days by `jump`;
    - 124's `main()` run;
    - Run 1's reformat relaunch: reuse Run 1's state;
    - 148's possible bound test;
    - the re-record: two stages.
  - Any growth over 10 % and 0.5 s, or over 10 s, is made efficient, never by cutting strictness.

### P2.8 Blocks (60-80 calls; no file split across a lane's blocks; each lane's last block runs its complete checks)

**Lane C**
- C1 (W1): <CORE>, then <SWEEP>, then <NTPF> on _fake_time, test_driven_time, _cancel_sweep, _ntp_frames and test_shared_helpers.
- C2: dns, ntp (OF-211), udp, webserver_connections.
- C3: wifi, captive, base_classes (OF-81), bmp3xx, isl, scd30, fram_driver; then C's checks.

**Lane N**
- N1: neopixel (43, 44, 53).
- N2: notification service (45-49, merging <PARTN>).
- N3: the four integration files, neopixel_wifi and network_neopixel; then N's checks.

**Lane U**
- U1: uart_comm and uart_driver (59-61), then <HANDOVER-UART>.
- U2: link_driver, twin uart_link, the hazard plant; then U's checks.

**Lane P**
- P1: crc, the changelog, the uart comments, math.
- P2: fram_manager, the chip fake, the system-service copy swap, twin fram (R-8).
- P3: config_manager (R-9), print_log (R-10); then P's checks with mpy-cross.

**Lane T**
- T1: the runner, _twin_process, test_twin_runner_test_flags.
- T2: the suite and its tests_scripts readers, gc_collect_sites.
- T3: the scenarios, generated_boot, the twin integration file.
- T4: values, README and settrace; then T's checks, the twin CI for dev and arzi at both stages.

**Lane H**
- H1: the tests_hardware edits and run_device_script.
- H2: the record script, test_twin_record and the shape proof; then H's checks.

**Lane Y**
- Y1: the config files plus machine (both), asy_system_service, bus_hazard_generated, twin bus hazard, conftest, serving_at_default_gc, cross_browser_smoke_probe.
- Y2: _bus_hazard_catalog and test_bus_hazard_multi_device (steps and `Any`).
- Y3: the two UART files' `Any`.
- Y4: step 114.
- Y5: _sensortask_scenarios' `Any`, test_sensortask (OF-200); then Y's checks: typecheck.sh, lint.sh, the readers, per device at both stages.

**Lane D**
- D1: <PARTN>, tests_hardware/README, the SPEC items with no dependency (9, 10, 116, 145 (b), 161's clause, R-23).
- D2: the dependent SPEC sentences and BACKLOG.
- D3: B2's values and the Basis cells (scripted); then D's scans.

**Lane W**
- W1: the web files.
- W2: the tests_scripts hygiene; then the web tier.

**Lane B**
- B1: the documents and the 2**30 build.
- B2: the measurements, test.sh, the conformance review.

Commits are named `U35 lane <L>: …`. Branches are `audit/u35-<l>`.

### Base-time shards (`path@-1`/`@32768`; seconds are U32's or earlier figures, balance only)
- **A (about 780 s):**
  - tests/test_digital_twin_bus_hazard_concurrency.py@-1 (150), tests/test_uart_comm_hazard.py@-1 (105), tests/test_bus_hazard_generated.py@-1 (64), tests/test_asy_uart_comm.py@-1 (61), tests/test_asy_captive_dns.py@-1, tests/test_asy_ntp_client.py@-1, tests/test_asy_system_service.py@-1;
  - tests/test_digital_twin_sensortask_integration.py[arzi, dev, grkizi]@-1 and @32768.
- **B (about 780 s):**
  - the same seven files @32768;
  - test_digital_twin_sensortask_integration[klkizi, schlafzi, wozi] at both stages;
  - tests/test_sensortask.py[arzi, dev] at both stages.
- **C (about 780 s):** at both stages:
  - test_digital_twin_uart_link, test_asy_wifi_service, test_asy_scd30_driver, test_asy_notification_service, test_digital_twin_network_neopixel, test_asy_bmp3xx_driver, test_asy_neopixel_driver, test_asy_uart_driver, test_asy_udp_socket;
  - the four notification integration files, test_neopixel_wifi_integration, test_bus_hazard_multi_device, test_asy_isl29125_driver, test_asy_uart_link_driver, test_asy_fram_driver, test_asy_fram_manager, test_asy_crc_checks, test_asy_dns_client, test_asy_webserver_connections, test_asy_base_classes, test_digital_twin_fram, test_asy_config_manager, test_asy_print_log, test_math_helpers, test_shared_helpers, test_digital_twin_machine;
  - tests/test_sensortask.py[grkizi, klkizi, schlafzi, wozi];
  - plus the changed tests_scripts files: twin_runner_test_flags, ci_suite_soak, ci_suite_errcount, generated_boot, gc_collect_sites, twin_record, mypy_any_baseline, cross_browser_smoke_probe, definitions_js_mirrors, host_text_encoding, port_lock, tool_help, lint_ceilings, device_script_config_schemas, test_sh, citations.
- Twin per-device rows run under the 4-process cap.
- New files are after-only: test_driven_time, the sweep files.

### Hardware session 1 (parked by L-5; each run needs the owner's go-ahead in its session, the FRAM logs read first, the wear gates)
- **R0:** H56.
- **R1:**
  - H29 (steps 6, 7, 74);
  - H73 (step 5's rerun with OF-02/OF-05);
  - H43 at the end (102, 139, 156);
  - H44 and H55 (147);
  - H71 (153, from queue_c);
  - H83 (131 and OF-226);
  - step 3's timing;
  - H48 (127; not in U35's work-order rounds);
  - H04 (130, every round);
  - H39/H40 provisionally (132);
  - R-8's probe through the FRAM flash run;
  - R-9's silicon loop stretch (the lead assigns the H row);
  - OF-181's raw steps.
- **R2:** H17 (OF-60), H37 (OF-70).
- **R3:** H68 (step 3's backup-reset test), H73.
- **R4:** H55, H39/H40.
- **R5:** H55, H64.
- **Phase C:** 163's release proof.

### Not determinable read-only
- Whether every `Any` site has a form mypy accepts without a cast (Y).
- Whether `Task[Any]` (src/asy_system_service.py:229-230) can become `Task[object]` under the stubs.
- The shim's frame counts against `_YieldOnlyAsyncio`'s (N1 runs settle it).
- littlefs's commit point (P3).
- Whether folds (11)-(16) can be driven in-process (T3).
- Whether a boot with no SSID logs a W in the smoke's window (T2).
- The l0-l2 Basis count B2 can measure in one block: at the valve it stops at a seam and hands back what is left.
- All base times marked "measure".
## LEAD NOTES (lead, 2026-10-21)
1. Base `f3fff0e`: U34's integration head `1dd6dd5` merged with U33's records head `c26db17`, which carries U32's squash
   `970b63b`. Against `1dd6dd5` only tests/test_asy_neopixel_driver.py and tests_js/shell.test.js (U32's two gate fixes)
   and `audit/` differ, so P1's and P2's line numbers hold everywhere else; N1 and W1 re-locate in those two files.
   Lanes never merge anything: the lead merges U33's and U34's final heads into `audit/u35-int` at W6. The base worktree
   is `S/wt-u35base` (detached at `f3fff0e`, rebuilt); every base/head time pair runs against it.
2. P2's rulings R-1 to R-34 stand, with these amendments (lead, 2026-10-21):
   a. R-8, the FRAM probe. Before writing it, P2 states from the code, per device, when a blank status byte is read in
      steady state (boot, chunk allocation, each errcount read behind `/status`, other). If one can recur per request,
      P2 measures the probe's SPI cost per request on the twin, states it, and keeps the probe bounded (its bound
      recorded as "(agent, 2026-10-21)"). An undriven bus reads every chunk blank, so no bound may hide a chip that
      stops answering; a test shows that. P may also edit digital_twin/_fram_chip.py, src/asy_fram_driver.py and
      tests/test_asy_fram_wire_trace.py where its steps need them: no other lane holds them (`S/u35/lead/lanes.py`).
   b. R-9, the config flush in chunks. The lock that serialises config writes stays held across every yield; P3 names
      it by line. The config file is a shared resource (CLAUDE.md's hazard rule), so P3 adds an L1 test: a concurrent
      PUT and a concurrent read of the same file during a yielded write see the old or the new document, never a torn
      one. A twin test follows if the twin's filesystem models commit at close. P3 states the flush's allocation per
      write before and after: no new whole-document copy, slice churn bounded and stated, zero MemoryError at both
      stages.
   c. R-26: T4's build-settrace runs of the twin integration file are heavy processes (arzi takes 119 s plain); one at
      a time.
   d. The coverage-growth finding: U32's coverage CI step grew 603 s to 881 s while the plain run did not, and agent CG
      measures it. When CG reports, the lead routes its fix to the lane that holds the file and adds it to that lane's
      next block.
3. W1 runs four blocks: C1, D1, P1, Y1. CG and the lead's close work (U33, then U34's records block) share the host
   and the six-agent cap. T1 starts when a slot frees; T's chain has slack until W7. Later waves follow P2.3, at most
   five blocks at once, fewer while a lead gate or U34's records block runs.
4. Times (CHECKLIST 14): base and head back to back in one run, alternating. Growth over 10 % and over 0.5 s, or a
   changed file over 10 s, is made efficient, never by cutting strictness. A changed file already over 10 s at base
   must not grow, and its time is stated. An annotation-only edit (MicroPython never evaluates annotations) is timed
   at the head only, at both stages, against its known figure; a paired run follows only if that time is off by more
   than 10 %.
5. The whole `tests_scripts` tier is the lead's, at W6 and W10. A lane's final block runs its readers (P2.2), the 17
   repo-wide scans (`S/u32/briefs/common_u32.md`, "Before your lane's final") and its own files' runs.
6. The host is shared with the lead's U33 gate (until about 17:20 UTC), U33's tier on its squash, U34's gate (about
   75 minutes) and CG's settrace measurements. Every wall-time-bound run obeys CHECKLIST 12.
7. `src/` edits: each file gets an mpy-cross byte compare of base and head, using the pinned build under
   `/root/pico-toolchain` (run it, never write there); the output goes under `S/u35/lane<L>/`.
   - P's files: crc, uart_comm's comments, fram_manager, config_manager, print_log. Y's: system_service's annotations.
   - A comment-only edit keeps its line count where it can. One that moves lines states the moved range (the line
     tables are then the only change); the tests prove the behaviour.
   - Firmware is final at U35's end: every `src/`, device-script, flash and bench edit lands before W6.
8. tests_hardware/twin_record.json: the lead re-records it at W6. H2 may commit only a record its own changed script
   produced (step 140's new shape), never a hand edit.
9. Relay `S/u35/relay.md`, sections C N U P T H Y D W B. The first-commit tokens:
   - C1: <CORE>, <SWEEP>, <NTPF>;
   - D1: <PARTN>; T1: <SHUT>; B1: <T30>; U1: <HANDOVER-UART>;
   - any lane, to D: <TAG name value basis>.
10. Names:
    - commits `U35 lane <L>: <summary>`; branches `audit/u35-<l>`;
    - worktrees `S/wt-u35<l>`, created from `f3fff0e` and set up with `S/u23/rebuild.sh`; logs in `S/u35/lane<L>/`;
    - the lead saves each hand-back as `S/u35/handbacks/<L><n>_final.md`;
    - `python3 -I S/u35/tools/steps.py [--standing] N ...` prints the packet's standing sections and the steps you name.
11. **The stale clock: owner question 7 answered** (owner, 2026-10-21: "Clock time: Option b, but with a flag in
    /status showing it might be stale. Should be visible on the website as well - probably the current time actually
    is already showing on the status page? Then this would be easy to add."; the question: "Keep timestamping once the
    NTP sync goes stale?"). Option (b), as BACKLOG.md entered it: `UTCTime` and the VOC backups keep the clock set this
    boot through a stale sync (backups keep their timestamp and their age test); after an NTP settings change both
    still wait for the next sync. The status page already shows Local Time, UTC Time and Device Clock in its system
    group (buildgen/definitions.py), so the flag is one more readonly row. The lead's form, decided on the owner's
    behalf for review (agent, 2026-10-21):
    - the NTP client gains `ntp_clock_valid()`: true from each successful sync until an NTP settings change
      (`ntp_force_sync()`); staleness, which clears only `Synced`, leaves it set. `UTCTime` and the SGP40 backup
      callback (`SgpBackup(<fram>, ...)` in codegen) read it in place of `ntp_issynced`; the boot signature
      (SystemService) keeps `ntp_issynced` (taken once at boot, where both are equal).
    - `/status` `system` gains `TimeStale`, after `UnixTime`: null until the clock was first set this boot (as
      `LocalTime` and `UnixTime` are), then true while `NTPSynced` is false (gone stale, or a settings change since the
      last sync) and false while synced. Website row: label "Time May Be Stale", readonly, a description saying when
      it is true and that the times shown may then have drifted.
    - every device (all six run the NTP client and the generated module; the VOC backup on each SGP40), every mode the
      same code path (AP and Silent turn stale 3 x `NTPInterval` after their last sync, as today); no bus traffic,
      wiring or wire byte changes; one bool of state.
    Landing: block C4 (lane C, after C2, before W6). Files added to lane C: src/asy_ntp_client.py,
    src/asy_sgp40_driver.py (its comment naming the callback), buildgen/codegen.py, buildgen/definitions.py,
    mockdata/samples.json, tests_scripts/test_buildgen_generate.py, tests_scripts/test_buildgen_definitions.py,
    tests_js/templates.test.js, tests_js/definitions-mockdata-coverage.test.js. C4 relays `<CLOCK> <hash>`; then Y4
    adds the per-device scenario assertions (stale window: `UTCTime` shown, `TimeStale` true, a backup stamped; after
    a settings change: `UTCTime` null, `TimeStale` true), T4 adds the twin suite's `TimeStale` checks (null in Run 1,
    false after Run 8's first sync), D2 writes A.8, F.1's gate sentence and the decision, and removes BACKLOG.md's
    question 7 (rule 4: its decision lives in SPECIFICATION.md with the quote above).
12. **Owner questions 2, 4 and 5 answered** (owner, 2026-10-21; each answer's words and its question are in REGISTER.md's
    U33 owner-answers row, `82b2af7`).
    - 2 (a), "Reboot when no sensor read timer can start?", and 4 (a), "Keep the SCD30 soft reset at every start?": no
      code changes. D2 removes both entries from BACKLOG.md and states each decision, with the owner's words, where its
      behaviour is described in SPECIFICATION.md (the read timer's failure path and the supervisor's restart budget;
      the SCD30 driver's start sequence).
    - 5 (b), "Leave the UART hazards under API load untested?" ("b - system shall be proven stable unter max load
      allover"): block U3 (lane U, after U2, before W6). The lead's form, decided on the owner's behalf for review
      (agent, 2026-10-21):
      - a hazard mode in `dev`'s UART exerciser (`src/asy_uart_link_driver.py`), off by default and reachable only on
        `dev` (the only device wiring `uart_link`). It is started by a dispatch-only command, never a persisted
        setting, so no boot ever starts in hazard mode and the flash-wear gate is not touched. It runs a bounded set of
        hazards and then returns to the normal echo.
      - The set is today's from `tests_hardware/device_scripts/uart_comm_hazards.py`: two initiations at once, both
        ends transmitting, boundary values, a stalled transmit, and the field sweep. Each is driven through the
        protocol's existing API. The wire format, the accept/reject rules and the timings are untouched (no Class A
        row). A Class B changelog row, if the change needs one, goes through P (P holds the changelog).
      - Proof on the twin under API load: tests/test_digital_twin_uart_link.py drives the hazard mode while readers
        hammer the API. Every hazard's verdict is asserted, and so are zero MemoryError and no reboot, at both GC
        stages. Unit tests go in tests/test_asy_uart_link_driver.py, each new test seen failing first.
      - tests_hardware/bench/test_uart_link_under_api_load.py gains the hazard run under the bench's reader load,
        collected (`--collect-only`). Its silicon run is parked for hardware session 1, and D2 adds its owed row.
      - D2 updates SPECIFICATION.md E.6.6's `uart-hazards-under-api-load` row and the other sites that say "not
        written", and tests_hardware/README.md; it removes BACKLOG.md's question 5.
      - Files added to lane U: src/asy_uart_link_driver.py, tests_hardware/bench/test_uart_link_under_api_load.py and
        tests_hardware/device_scripts/uart_link_echo_under_serving_load.py. uart_comm_hazards.py is read, not edited.
      - If the command needs a change in buildgen/codegen.py or buildgen/definitions.py (C4's files, LEAD NOTES 11), U3
        runs after C4 and C hands those files over by relay line; one owner per file at a time.
    - Questions 1, 3 and 6 stay open; the owner answers them next.
13. **Owner questions 1 and 6 answered** (owner, 2026-10-21; words and questions in REGISTER.md's second U33
    owner-answers row).
    - 1 (a): no code change. The condition, that a recurrence cannot be missed, was checked by the lead: a signal death
      fails Run 5c's check by name, and nothing retries a twin job. D2 removes the entry and states the decision in
      SPECIFICATION.md where the twin suite's crash naming is described.
    - 6 (c): block K at W6, after the lane merges and before the gate and the twin re-record, since K moves `src/`
      line tables.
      - K re-measures the over-cap blocks at 120 characters, rewraps or shortens each with no meaning change (rule 3),
        and turns the switch on in tests_scripts/test_comment_block_cap.py.
      - It also restates CLAUDE.md's "How a block is counted" sentence with the owner's words.
      - Detail that cannot fit moves to SPECIFICATION.md through D2's relay, never dropped.
      - Files: every file with an over-cap block, at W6, when no lane holds them; the cap test; CLAUDE.md.
      - Later blocks (T4, D2, D3) write to the new count from then on.
    - 3 stays open: the owner asked for its options in more detail.
14. **Owner question 3 answered** (owner, 2026-10-21: "option a"; the question: "Cap the SCD30 NVM writes the
    extra-write flag admits?"; REGISTER.md's third U33 owner-answers row). No test changes. D2 restates CLAUDE.md's
    `scd30_extra_write` sentence ("a *second* SCD30 NVM write beyond the routine per-session one") and the matching
    tests_hardware/README.md and SPECIFICATION.md text to what the flag admits: the four `scd30_extra_write` tests, up to
    12 further writes, 13 per session with both flags, plus at most one start command. D2 also removes the entry from
    BACKLOG.md and states the decision there. CLAUDE.md is K's at W6 (LEAD NOTES 13), then D2's: one owner at a time.
    With this, BACKLOG.md's owner-question list holds no open question; D2 leaves the list's heading and its rule.
15. **Y1's carries** (lead, 2026-10-21; Y1's hand-back):
    - P2 moves tests/test_asy_system_service.py's six `Task[object]` annotations (:1132, :1207, :1922, :2118, :2227,
      :3031 at `f3fff0e`) to `Task[None]`; a later Y block then types src/asy_system_service.py with the TaskStarter
      alias and clears the module (its twin-pass and main-pass checks are in Y1's hand-back).
    - OF-32 moves to Y3, first, before the UART files' `Any`.
    - `machine` stays listed in both passes with its sites (Y1's reasons); the twin pass keeps typecheck.ini's :32 clause.
    - test_mypy_any_baseline's self-test now names `scripts._hardware_verdict` as its listed host module: U37's row for
      that module says the self-test needs a new pick when it clears.
16. **Lane branch points and the lead's handover merges** (lead, 2026-10-21). N and U branch from C1's final head
    `feae592`. Y needs U1's `<HANDOVER-UART>` head `7158212` (which carries C1's helpers) before Y3: the lead merges it
    into audit/u35-y after Y2 ends; the file sets are disjoint, so the merge is clean, and at W6 the shared commits are
    common ancestry. The same before Y4 with C4's `<CLOCK>` head. Lanes themselves still never merge.
17. **Smaller blocks** (lead, 2026-10-21): four of the first five blocks ran past the 80-call valve (89 to 116), so later
    blocks are cut smaller (C2 became C2a/C2b, T2 T2a/T2b, P2 P2a/P2b) and every brief says "at 70, finish the step in
    hand and hand back". U's complete checks move to U3, its last block.
18. **Y2's carries** (lead, 2026-10-21): tests/_bus_hazard_catalog.py and tests/test_bus_hazard_multi_device.py were
    already out of SPECIFICATION.md D.15's module-level order at the base; a later Y block reorders both in its own
    commit, no content change (checked by line multiset, as C2a did for the dns file). The lead removed the allow-list row
    Y2's deletion orphaned (`c1b9f31`) and merged U's handover head into Y (`1089164`).
19. **N1's and C2b's findings; lane C split** (lead, 2026-10-21):
    - The driven clock's cancel hang (N1; blocks_w4.md's first section): F1 root-causes and fixes it and relays
      `<SHIMFIX>`; the lead merges that head into each lane that needs it before the lane's next block (note 16's form).
    - C2b's defect in src/asy_udp_socket.py:56-76: a cancel during `_connect()`'s backoff sleep (:73) skips the self-heal
      (:75-76), so `_sock` stays set with `connected` False and every later `_connect()` skips setup until a
      `disconnect()`. Latent on every device and in every mode, since each caller disconnects in its own `finally`. No
      unit's files hold the module, so the routing rule would send it to U37, away from the test that pins it; it lands
      in lane Q with step 65's connect half instead, the self-heal moving into a `finally` (agent, 2026-10-21: decided
      on the owner's behalf for review; the fix is bite-checked by C2b and the test that needs it is in U35). Its
      open-findings row is U35's records block's.
    - Lane C was the longest serial chain (C3, C4, then Y4 and Y5 behind `<CLOCK>`), so its remaining files split into
      lanes that branch from C2b's head `0547def`: F (tests/_fake_time.py, tests/test_driven_time.py: F1), Q (the UDP
      socket and its test, webserver_connections, wifi, captive: Q1, Q2), E (base_classes, fram_driver, isl, scd30,
      bmp3xx: E1, E2). Lane C keeps _cancel_sweep, _ntp_frames, shared_helpers, dns, ntp and the clock files: C4, then
      C5 (C's complete checks). Each new lane runs its own complete checks; the lead merges all four at W6, where
      `0547def` is their common ancestry. lanes.py holds the cut (117 files, 13 lanes, disjoint at the base).
20. **CG's result, Y3's and T2a's points; lane Y split** (lead, 2026-10-21):
    - CG (U33's coverage-growth block, `S/u33/handbacks/CG_final.md`): U32 did not slow the coverage leg. No file grew
      under build-settrace (160.2 to 163.1 CPU-s over 15 files) or under coverage.py (tier CPU +1.5 % with 43 more
      tests; as one process 875 s on U31's tree, 811 s on U32's). The local 849/1056 s pair is contaminated by load
      (U32's leg overlapped the U33 tier run, a scratchpad grep and four lanes); CI's step reads 603-905 s over 11 green
      runs, 603 s the lowest. OF-236 closes as no regression in U35's records, citing `S/u33/cg/`, which goes into U35's
      evidence. CG's two efficiency proposals are taken, as the owner's direction of 2026-10-08 asks ("not cutting back
      strictness, but making it more efficient"):
      - the tests_scripts tier in `--coverage` mode run as two `--parallel-mode` shards and combined: B2 (scripts/test.sh
        is B's), only if the leg's wall drops when `scripts/test.sh --coverage` runs alone on the host, split against
        unsplit on one tree; otherwise B2 records the measurement and the tier stays one process;
      - real-time waits that hold a slot without CPU (wall/CPU-s under settrace): twin bus hazard 160/24 (V1),
        twin timer pool 36/2.3 per device and hot replug 72/5 (G1, a new lane from `0547def`), twin sensortask
        integration 23.5/3 per device (T3), the notification service 19/0.3 (N2, already). Each move keeps every
        assertion; a wait whose real time is the scenario's subject stays, with its reason.
    - Y3's finding: digital_twin/_flash_stall.py:98 stores stall windows as `ticks_diff()` from EPOCH_US, so on a 2**30
      build a window straddling the 2**29 us wrap reads as empty (class 5, twin only). No unit holds the file; it joins
      lane V with OF-32's other twin sites (V1), seen failing first on tests/_ticks30.py's clock.
    - T2a's +16 % on the dev suite's `--only 1,2,12` (5.4 s) is step 118's added reformat-relaunch boot, a new check, not
      growth of existing work, so note 4's bar does not apply (agent, 2026-10-21). T2a's owed points go to T4
      (digital_twin/README.md's Run 1 text and the "SIGINT shutdown" wording); SPECIFICATION.md:8848 still holds.
    - Lane Y's remaining chain (the `Any` of three files, 114, OF-200, the `<CLOCK>` assertions, Y's checks) is split:
      lane V branches from Y3's head `949a68a` with digital_twin/_flash_stall.py, the twin bus hazard file, the catalog
      and multi_device (V1), and after Y4's `<HANDOVER-SCEN>` tests/_sensortask_scenarios.py and tests/test_sensortask.py
      (V2: 114 and the `<CLOCK>` assertions; V3: OF-200 per R-31, then V's checks). Y keeps the config files: Y4 types
      _sensortask_scenarios first and hands both files over; Y5 types the two UART files, then runs Y's checks.
21. **P2a's points** (lead, 2026-10-21): `<TASKNONE>` is `a77baac`; the lead merges it into audit/u35-y before Y5.
    tests/machine.py:598's SPI `TEST_API` is inferred as a fixed-length tuple, so tests/_fram_chip_fake.py:29 carries
    a coded `# type: ignore[assignment]`; annotating :598 as `tuple[str, ...]` makes that ignore unused. The two files
    are in lanes Y and P, so the lead makes both edits in one commit at W6, after the merges, proven by
    `scripts/typecheck.sh`. P2b owes P2a's ten unrun test_sensortask runs (arzi and dev ran at -1, 91/91; the other
    four devices at -1 and all six at 32768 were held by the host's load) on its own head.
22. **`<SHIMFIX>` `1d77560`** (lead, 2026-10-21; F1's hand-back): the driven `wait_for`'s runner cancelled a waiter a
    second time after an external cancel had landed but before the waiter resumed, so a cancelled task ran on (class 4,
    tests/_fake_time.py:256 at `0547def`). Lane F is complete. The lead merged the fix into N (`2ed3946`) and
    fast-forwarded Q, E and G to it; C takes it after C4, before C5. Lanes U, V, Y, T, P and D hold no site. With the
    fix, the "let tasks start before a cancel" rule no longer applies to N, Q, E, G or C5; N1's setup test
    (tests/test_asy_neopixel_driver.py:880-886) moves to the driven clock in N3.
23. **C4's points** (lead, 2026-10-21): `<CLOCK>` is `8c2b458`; lane C took `<SHIMFIX>` as `7442273`. C4's red on
    tests/_sensortask_scenarios.py:2726-2728 (it patches `ntp_issynced` to show `UTCTime`; on `<CLOCK>` it must patch
    `ntp_clock_valid`) is V2's, which merges `<CLOCK>` with Y4's handover; Y4 neither merges nor fixes it.
    buildgen/graph.py:65's comment ("built with ntp.ntp_issynced") is stale and joins lane C for C5. test_asy_ntp_client
    grew +2.6 s (+11 %) on a file over 10 s; C5 folds C4's stale-clock test into the existing stale test, which runs the
    same 1081-tick drive, and re-times paired. C4's `node_modules` link in S/wt-u35c (gitignored) goes with the worktree.
24. **T2b's finding** (lead, 2026-10-21; class 3, twin mode, every device): Run 3's FRAM write-rate check (T2b,
    `f9569b9`) cannot fail. Run 3 faults `fram:silent` on every device, and digital_twin/_fram_chip.py:287 returns before
    `_count_write` while the chip is silent, so the shutdown line reads `fram_writes=0` whatever the product issues (dev
    at both stages: 0 writes in 7563 ms). Fix in two lanes: P2b gives the chip a count of the writes issued while silent,
    seen failing first, and relays `<SILENTW> <hash>` under `## P`; the lead merges it into T before T3. T3 makes the
    runner print that count on the shutdown line (`ShutdownLine` parses it, a parser case seen failing first), makes Run 3
    check the issued writes against the same bound, bitten by T2b's plant (`S/u35/laneT/t2b_plant/run3_plant.py`), and
    adds Run 3's L0 case in the suite's matrix or errcount file. T2b's owed doc points: T4 (digital_twin/README.md :332
    and :780 `MEM_SAMPLE`, Run 11's byte-span window, Run 3's ceiling) and D2 (E.9's window sentence; rate.persisted_log
    gains Run 3 as a reader). Run 11's floor analysis (about 90 new floors per run on base and head alike) is B2's input.
25. **U2's points** (lead, 2026-10-21; U2's head `f6f54cc`):
    - Times: the hazard file (+0.6/+0.3 s) and the twin link (+0.15 s) are over 10 s at base and grew by exactly their new
      checks (the bound test about 0.1 s, the 140-byte SET about 0.15 s); both heads stay under U32's figures. Under
      note 20's ruling a new check is not growth of existing work (agent, 2026-10-21); each added cost is stated.
    - Step 148's bound `l1.uart_comm_hazard_clean_transaction_virtual_ms = 14` is the measured 4 virtual ms plus a 10 ms
      margin with no source. Virtual time is deterministic, so U3 restates the basis: J.7's figure if J.7 states one,
      otherwise the measured value with no margin (N1's bounds), keeping both plants red. D2's Part N row takes U3's
      value; tunables_register stays red on that row until it lands (R-17).
    - Y5 adds the two missing blank lines around `test_cancelling_at_each_await_leaves_no_lock_or_busy_flag`
      (tests/test_asy_uart_comm.py:3116, :3172; ruff's E302 is preview-only).
26. **Y4's points** (lead, 2026-10-21; `<HANDOVER-SCEN>` `5ef18d4`): `_sensortask_scenarios` stays listed with three
    shape-found sites (:1244, :1564, :2624; agent, 2026-10-21) and its baseline line and `_RESIDUAL` row; its ANN401
    entry left with the last bare `Any` (a shrink, as R-15 has it). The file was out of D.15's module-level order at the
    base and still is: V3 reorders it in its own commit with no content change (line multiset), after V2, keeping the
    scenario registration order. The lead merged `<TASKNONE>` `a77baac` into Y for Y5; the handover merges into V at
    V2's start, after V1.
27. **The secret-scan decision's citation** (lead, 2026-10-21, found writing U34's squash message):
    THIRD_PARTY_LICENSES.md:12 (U34 lane A) and SPECIFICATION.md:42 cite "(owner, 2026-09-30)" for the secret scan's
    exclusion of `arduino/` without the owner's words. The words are in audit/actions/U29.md:230: "No, it stays fully
    out of the audit" (asked, paraphrase: whether the history secret scan reads `arduino/`). Both sites take the quote
    at W6, as a lead edit after U34's final head is merged (lane D's base predates lane A's text), no meaning change.
28. **P2b's points** (lead, 2026-10-21; `<SILENTW>` `83e8633`): R-8 landed with no probe bound (no blank read recurs
    per request on any device; agent, 2026-10-21). The twin chip's `silent_write_count` counts data-phase writes while
    silent, and P2b reports that a correct product issues none to a chip silent from boot: the driver's WEL check stops
    each write before its data phase. So that count may again be unable to fail on Run 3. digital_twin/_fram_chip.py
    passes from P to T (P3 does not touch it): T3b first shows on the real dev twin whether a planted write storm moves
    the count Run 3 reads; if it cannot, the chip also counts the write attempts it sees while silent (a WREN while
    silent), seen failing first, and Run 3 checks those. The lead merges `83e8633` into T at T3b's start, after T3a.
    The FRAM datasheet PDFs in the main checkout are AES-encrypted; P2b read the scratchpad's earlier text extraction
    (S/MB85RS64V-DS501-00015-4v0-E.txt, the MB85RS2MTA one) for RDID 9Fh and ID 04 7F 03 02.
29. **T3a's points** (lead, 2026-10-21; T3a `ffd742f`, then the lead's merge of P's `83e8633` as `12669ab`): test 2 and
    fold (12) landed; arzi's twin integration file 118 s to 68 s. Two reds are unexplained and go to R1, a root-cause
    block in a scratch worktree (S/wt-u35r at `ffd742f`) that commits nothing: (a) fold (14)'s SCD30 snapshot fault
    sends nulls where the marker is expected (class 4 if confirmed, a product path); (b) the supervised-death memory
    slope failed once on dev at -1 (56 B against 32 B). Folds (11), (13)-(16) and (18) and test 4's, the PC-report
    test's and tests 6-9's remaining real waits go to T3c, after T3b and R1; fold (14) waits on R1's root cause.
30. **V1's points** (lead, 2026-10-21; V1 `fb9c0e1`; the lead merged Y4's `5ef18d4` and C's `7442273` into V as
    `97a034c`, rebuilt): the flash-stall windows are (start, length); the twin bus hazard file runs 84 s, not 150 s.
    - The recombination test (owner, 2026-09-04, paraphrase: the system tolerates "a genuine 60 s wifi_mode_lock hold
      (the real ESTABLISHED-branch retry)" under concurrent bus load) never reached that retry: `_run_sta_mode()`
      (src/asy_wifi_service.py:768-776) reconnects inside the lock and waits its 60 s outside it, and only after a
      failed attempt, so neither the old 75 s window nor V1's bounded one ran the retry. The owner's requirement is the
      system under the real retry; the lock hold is the mechanism the 2026-09-04 code had. Decided on the owner's
      behalf for review (agent, 2026-10-21): V3 forces one failed reconnect so the real 60 s retry runs while the bus
      load is in flight, asserts the bus work proceeds through it and the link returns after it, and restates the
      comment with the change named (the retry waits outside `wifi_mode_lock`); the owner's paraphrase keeps its actor
      and date. Its about 60 s is the scenario's subject.
    - The residual (class 5, twin, 2**30 build): a stall window exactly 2**30 us old matches a byte due one period
      later; the fix is machine.py:937 (Y's) passing an unbounded time. Y5 takes it if the fix lies in machine.py
      alone; if it needs digital_twin/_flash_stall.py too, the lead makes both edits at W6.
    - The two Part N rows' new basis (`l2.bus_hazard_concurrency_flap_window_s` 75.0 is a bound, not a window;
      `l2.twin_wdt_feed_interval_s` x 4 is the SCD30 cycle's bound) is relayed to D by the lead.
31. **U3a's points** (lead, 2026-10-21; U3a `4d6568f`; the lead merged C's `7442273` into U as `78fb201`, rebuilt):
    - The hazard mode runs three of the set: two initiations at once, both ends transmitting (from the initiator alone,
      since the live listen loop holds the responder's TX), and the field sweep. The stalled transmit is left out: it
      needs a UART re-init with the port and pins the driver does not keep (asy_uart_driver.py:472-475), and it stays
      covered by the bench's raw script with `main.py` stopped; H1b is not in the lead's list. Both are decided on the
      owner's behalf for review (agent, 2026-10-21).
    - The route was not wired, since it needs lane C's files. C4's buildgen and web files (codegen, definitions,
      samples.json, the two buildgen tests, the two JS tests) and src/asy_webserver_service.py (in no lane) pass to U for
      U3b; C5 keeps its fold, graph.py's comment and C's checks.
    - Open thread, U3b's first item: in the mock the crossing logs NO_ACK where PEER_INITIATED is expected, and the first
      recovery try logs NO_ACK too; the test pins `[85, 81, 81]` without the cause traced. It is root-caused before any
      test relies on it.
    - "Stop, don't cancel" under the driven clock predates `<SHIMFIX>`, now merged: U3b re-checks it.
    - The changelog: no row. UART_C_PORT_CHANGELOG.md records changes to the protocol module (CLAUDE.md), and the
      exerciser is not that module (agent, 2026-10-21).
    - tunables_register: five tags without Part N rows (src/asy_uart_link_driver.py :50, :52, :54; the link driver test
      :489; the hazard test :1383), D2's.
32. **R1's root causes** (lead, 2026-10-21; `S/u35/handbacks/R1_final.md`, evidence in `S/u35/laneR/`):
    - (a) Fold (14)'s SCD30 nulls are a harness artefact, not a firmware defect: T3a's "unplanted" run executed the test
      from the plant's directory, which the Unix port puts first on sys.path (ports/unix/main.c:688), so the planted
      asy_base_classes.py (:455 returning plain values) loaded in both runs; SCD30 alone fails through that branch.
      Copied into a clean directory the test passes with all three markers. On hardware a failed SCD30 read raises (I2C
      ETIMEDOUT/EIO, the CRC-8 check) and the marker reaches /status on every SCD30 device in every serving mode.
      Fold (14) lands in T3c as a guard, with bites at bmp3xx's and isl29125's callback branch, its control run from a
      clean directory.
    - (b) The supervised-death memory check's red (1 in 17 head runs, 0 in 17 base runs, no base/head difference): no
      death retains memory (flat floors from death 3, 68 probe runs), but transients of -224 to +416 B span one to three
      deaths, and the check's slope against the window minimum lets one transient in deaths 3-5 fail a healthy run and
      one in deaths 7-9 hide up to dip/4 B per death of real retention. The transient's source is not found at line
      level: every task chain, frame slot type, queue, module attribute and twin registry matched a steady death; stale
      words a conservative `gc.collect()` scans are the leading, unproven hypothesis. The method is the root cause of the
      red: T3c replaces the slope with the Theil-Sen median of the 21 pairwise slopes over deaths 3-9, keeping the 32 B
      bound (R1's `S/u35/laneR/b_fix/test_fix.py`: 49 unperturbed recorded runs read at most 10.7 B, a planted 64 B per
      death at least 53.3 B; real runs green 4/4, the plant red 4/4), runs it at both stages and under settrace, and
      states its two known limits (two late transients read 38 B; three mid-window transients plus the plant read 32.0).
33. **U3b's points** (lead, 2026-10-21; U3b `bfc6519`, `S/u35/handbacks/U3b_final.md`):
    - The crossing's open thread is closed with no protocol defect: the first 81 is the stale uid's NO_ACK
      (asy_uart_comm.py `_validate_ack`), the second was the test hook counting `_fault`'s `_err` twice; pin `[85, 81]`,
      the peer's 88 asserted, and a guard for the uid-0 outcome. "Stop, don't cancel" was never needed at that site.
    - The route: `add_status_command(key, command)` and the dev-only codegen and definitions. Its call is unguarded
      (agent, 2026-10-21), which departs from SPECIFICATION.md G.2's caller-supplied callback dispatch guarding (validate,
      `try`, `except Exception` → `err_s` → `"Failed"`). A consistency departure is changed, not flagged (CLAUDE.md, the
      owner's 2026-09-25 rule): U3c applies `_run_system_cmd`'s guard shape, seen failing first on a raising command
      (500 today). The other two decisions (a registration method; the report key as the initiator's resolved name) stand
      for review.
    - The G.3 mirror obligation reaches js/mock-server.js (in no lane; it answers only ResetErrors), and the service-level
      test of `add_status_command` belongs in tests/test_asy_webserver_service.py (U35's file, in no lane): both join
      lane U for U3c (lead, 2026-10-21; lanes.py updated). Lane map fix: the two UART test files passed to Y at
      `<HANDOVER-UART>` `7158212`; lanes.py now lists them under Y.
    - The hazard run's 26 small frame copies per run (`_write_raw` through `device.write()`, asy_uart_driver.py:787) are
      bounded and on demand; no change in U35, a findings row in U35's records routed by the rule.
    - U3c takes U3b's remainder (its hand-back's list): the two buildgen readers seen failing on base, samples.json, the
      two JS tests, the paired link-driver runs, every dev generated-module test at both stages, the 12 checks, relay
      lines, the silent-failure scan and the 17 scans.
34. **V2's points** (lead, 2026-10-21; V2 `83c9475`, `S/u35/handbacks/V2_final.md`): C4's red is green on all six; the
    stale-clock scenario landed, seen failing on the pre-merge head; step 114's four groups landed narrower than the
    packet's rows, each bitten. Every file grows 8.2-10.9 s, all of it the new groups (forty days 4.9-5.4 s, dropped
    tick 2.1-2.3, storm 0.8-1.6, stuck task 0.4-0.7, stale clock 0.2-0.4). The growth is accepted as new checks (LEAD
    NOTES 4), but forty days and dropped tick drive the clock: V3 measures where their time goes and makes them
    efficient where no assertion measures it, every assertion kept. The groups' uncovered parts (the stuck task's
    escaping exception, cancelled `main()` and blocked-loop half; forty days' WiFi uptime, NTP age and resyncs, ring
    saturation, stored ticks; the storm's periodic paths, scan budget, ladder and L2 half) go to V3 where they fit V's
    files; any left is a findings row routed by the rule, with Pin IRQs (tests/machine.py keeps no pin registry, Y's).
    The four decisions stand for review. The `_threshold_runner` path wrinkle (the runner's own directory first on the
    path) is the same mechanism as R1's (a): any paired run copies the runner beside each tree.
35. **T3b's points** (lead, 2026-10-21; T3b `fd0292d`, `f4cba3c`): Run 3's silent count now includes write attempts
    (`silent_wren_count`, ceil(WRENs / 2)), both shutdown fields required, bitten on the real twin at both stages; 149
    applied in part; 155 had landed. The lead dropped the orphaned citation row (`0a19769`, test_citations green). T4
    takes 149's booted boot order (R-24), 125 (f)-(i), folds (1)-(3), and digital_twin/README.md's text on
    `silent_wren_count` and the two shutdown fields.
36. **Q1's points** (lead, 2026-10-21; Q1 `8194466` red, `e50f813` fix, `a87d1e9`, `5fba3da`): 65's connect half is
    fixed (the self-heal in a `finally`, checked against the pinned asyncio at line level; mpy-cross 2060 → 2066 B, only
    `_connect` moves); latent in every mode today. 67's sweep landed, bitten three ways; D.15's order landed. Two new
    points: `_connect()` drops `_disconnect_locked()`'s bool (src/asy_udp_socket.py:76, class 4) goes to Q2 (Q's file);
    tests_scripts/test_code_conventions.py:232-243 `_import_time_names` misses class-body method defaults (they run at
    import time): a findings row in U35's records, routed by the rule to U36 (work_order.json).
37. **N2's points** (lead, 2026-10-21; N2 `66e496d`): steps 45-49 applied; the notification file drops from 19.0 s to
    0.19 s at both stages (68/68, settrace 0.32 s), every converted test bitten by at least one of 18 planted services
    at both stages, the no-margin plant included. Three tests build their service directly (two read state before
    `setup()`, one is the debug=2 console test) and the `FastAsyncSleep` scenarios stay (they are bounded in rounds):
    both stand for review (agent, 2026-10-21). tunables_register's one red on N is the other face of Y2's row
    (`l1.bus_fault_isolation_bound_s`: N carries `<PARTN>`'s row, Y carries the tag); W6's merge resolves it. N3 is
    written (blocks_w4.md).
38. **E1's points** (lead, 2026-10-21; E1 `8fb6241`): R-11's pin, 41's driven bound, 52's and 58's Event gates applied,
    each bitten; no product change; times flat (the scd30 32768 pair re-timed alternating: no growth). Two decisions
    stand for review (agent, 2026-10-21): the isl test makes the data burst's hold yield once, since the fake I2C never
    yields; the counting lock `_BalanceLock` lives in E's test file. Its fact for lane C: `_cancel_sweep.assert_unlocked`
    alone cannot see a double release (the lock ends free either way). Lane C ends with C5, and lifting the counting lock
    into the sweep changes every lane's sweeps, so it is a W6 lead item on the merged head (the W-order lines). E1
    ran its pytest batch, which starts MicroPython in test_microtest, beside its timing run and without `unshare -n`
    (CHECKLIST 12, its own report); the scd30 figure was re-timed alone, so no figure rests on it. E2 adds D.15's
    module-level order for base_classes (15 pairs out of order), isl (16) and scd30 (16), fram 0.
39. **C5's points** (lead, 2026-10-21; C5 `0174a87`; lane C complete): the fold removes C4's +2.6 s (ntp 23.7/23.8 s
    at -1, 24.3 at 32768, against 23.7/24.2 at base), C4's bite still fails only the folded test; graph.py names each
    NTP check at the edge that uses it; tests/test_shared_helpers.py back in D.15 order (C1's slip). C's checks green
    but the expected twin record. Its D.15 list for other lanes: tests/test_driven_time.py (F's, C1's slip) is moved
    by the lead (`5222d7b` on audit/u35-f, a pure move, 19/19 at both stages); Q's udp file is in order on Q's head and
    webserver_connections' `_no_delay` is an import-time name the checker misses (LEAD NOTES 36's U36 row); lane U's
    four buildgen files were out of order at base and go into U3d's D.15 pass.
40. **Y5's points** (lead, 2026-10-21; Y5 `d6f34ab`, `69135de`, `1e4df91`, `5cf361c`; lane Y complete):
    - asy_system_service is cleared from the baseline. Its mpy-cross bytes move 11289 → 11263 B, only because the unused
      `Any` leaves the `if TYPE_CHECKING:` import, which never runs on the device; a probe restoring that import is
      byte-identical to the base. LEAD NOTES 7's byte-identity is met in substance, and the clean form stands for review
      (agent, 2026-10-21). No effect on any device or mode.
    - test_asy_uart_driver is cleared; test_asy_uart_comm keeps one site (:177, `_make_comm`'s forwarded `params`, since
      mypy does not narrow a TypedDict pop), listed with that reason. The last ANN401 entry for those files and the stale
      "Unpack[TypedDict] is unavailable" reason are gone. 36 blank-line sites in the two UART files (LEAD NOTES 25's
      two included) are the same consistency defect and were fixed with them.
    - Baseline now: main pass `_boot_contiguity_probe` and `_uart_link_contract` (U36), `_sensortask_scenarios` (Y4's 3
      sites), `machine`, `test_asy_uart_comm` (1 site); twin pass `machine`; host pass `scripts._hardware_verdict` (U37).
    - LEAD NOTES 30's residual needs both stall files (Y5's line-level reading: V1's `irqs_were_off` masks its
      arguments, so a time one period later aliases; the current comparison misses windows recorded after 2**29 us).
      digital_twin/machine.py and tests/test_digital_twin_machine.py pass from Y to V (lanes.py); V4 fixes it, seen
      failing first, after the lead merges `5cf361c` into V. tests/machine.py stays Y's, for the lead's W6 edit (LEAD
      NOTES 21); wt-u35y keeps its .venv and typings/ until then.
    - Y5 ran three foreground reader runs with no RUNS.md lines (its own report); the records name the gap.
    - The lead merged `5cf361c` into V as `58b0713` (rebuilt). Y's head carries P2a's finished commits through Y's
      `<TASKNONE>` merge, so V now holds them too (src/asy_crc_checks.py, src/asy_uart_comm.py, src/asy_system_service.py
      among them); none is a V file, and W6's merge of P's head takes the same commits.
41. **U3c's points** (lead, 2026-10-21; U3c `962602d`): the guard landed as `_run_status_cmd()` (500 → "Failed" plus a
    WEBSERVER CALLBACK entry on dev in STA and AP; the other five devices unchanged), seen failing first; the service
    test, the buildgen readers on base, samples.json, the mock mirror and the templates case landed, each seen failing
    or bitten. One defect found and fixed in lane U's own test: at `bfc6519` tests/test_asy_uart_link_driver.py stopped
    at `import microdot`, because scripts/test.sh's MICROPYPATH holds no ext/; U3b's 43/43 had run with ext/ on its path.
    The file now inserts ext/ as the webserver test does, and every later run of a lane U file goes through test.sh's
    own path. The mock answers "Valid" for any listed dispatch key and keeps no pending state (agent, 2026-10-21; it
    stands for review). The `Promise.all` rewrite was not re-shown failing: U3d does that. U3c's remainder is split into
    U3d (the twin proof and runs) and U3e (the bench collection, the relays, D.15, U's checks); G.2's list naming
    `_run_status_cmd()` is a U3e relay. U3c's 12-check run (68.5 s) has no RUNS.md lines (its own report).
42. **T3c's points** (lead, 2026-10-21; T3c `4c88787`, `dc8c180`): R1's Theil-Sen drift check landed with the 32 B
    bound and its two limits in one line, bitten at both stages by the planted 64 B per death; folds (14), (15) and
    (16) landed as guards, each bitten (14 at the SCD30 store branch and at bmp3xx's and isl29125's callback branch);
    test 4's uptime ticks moved. A port-band red found on arzi (`dtsi ran past its port band 19100-19115`) is fixed in
    the test: boots that never start the web server share one `_UNSERVED_PORT` (only asy_webserver_service.py:960
    binds it), serving boots keep a fresh port. arzi's file drops 118.7 → 73.4 s at -1 (118.5 → 75.1 at 32768), the
    other five 1-1.3 s faster each. The four decisions stand for review (agent, 2026-10-21). T4 stays at W8 (it needs
    B2's figures), so T3c's and T3b's leftovers take two blocks before W6: T3d (folds (11), (13), (18); the waits in
    tests 6-9) and T3e (149's booted boot order, 125 (f)-(i) and its folds (1)-(3)). digital_twin/README.md's text
    stays T4's.
43. **E2's points** (lead, 2026-10-21; E2 `e507a88`, D.15 `d411724`, `be13031`, `bd9d811`, `e8b6f06`; lane E complete):
    39 reproduces the interleaving (snapshot (1, 1, 0), the setter's OSR write last, one session acquire), bitten three
    ways; the four D.15 orders are pure moves; times flat. Its datasheet fact is settled: DS001 §4.2's memory map
    (Table 24, p30) gives OSR 0x02 and CONFIG 0x00, so digital_twin/_bmp3xx_chip.py:41 is right and the test's seed was
    not. The lead fixed the seed on E (`6bbba55`, 138/138 at both stages). The agents' "cannot decrypt" was the venv's:
    a scratch venv with pypdf and pycryptodome reads every datasheet (`S/u35/lead/pdfvenv`, common_u35.md's new
    Datasheets section), so no later block falls back on memory. E2's (1, 1, 0) comment names the fake's untouched
    registers rather than the chip's encodings, which is accurate for the fake I2C; it stands.
44. **Q2's points** (lead, 2026-10-21; Q2 `53b10dc`; lane Q complete): Q1's class-4 item needs no change:
    `_disconnect_locked()` clears `_sock`, `poller` and `connected` before its teardown, the caller learns through
    `connected` False (captive DNS `_ERR_INIT`, NTP `_ERR_NTP_NOT_SENT`), and in v1.29.0 neither teardown half can fail
    (modselect.c:505-524, modlwip.c:1600/1668-1710, py/stream.c:444-452, ports/unix/modsocket.c:135-149); a planted
    failing unregister confirmed it. 71's and 79's sweeps landed, bitten five ways; times flat. OF-211's audit is
    green: 56 socket files (the 4 per-device ones on all 6) at both stages beside held :123 and :53 responders, 152
    runs at first try, 0 requests reached the holders; its E.1 line is relayed under `## D`. The audit set and the :53
    holder are wider than U27's and stand for review (agent, 2026-10-21). OF-211 closes in U35's records on that audit.
45. **N3's points** (lead, 2026-10-21; N3 `aa521ac`): 86-90 applied, LEAD NOTES 22's setup test on the driven clock,
    99 in part (the negative windows structural, fold (1)'s driver case in the twin file); 12 plants bite, the no-margin
    ones included; the four notification integration files drop to 0.15-0.43 s from 2.9-6.4 s, neopixel_driver to
    0.72 s from 7.2 s, network_neopixel 16.3 → 14.3 s, neopixel_wifi flat (+2.5 %, setup() added). The lead dropped the
    two orphaned decision-vocabulary rows (`189d4e8`, test_decision_vocabulary green). Its `<TAG ...withdrawn>` line
    sits under `## N`: D2 collects every `<TAG>` line from all relay sections (the Part N row
    `l1.notification_neopixel_wait_until_timeout_ms` at SPECIFICATION.md:11780 is withdrawn with it). 99's A.U22.01
    restarted-signal-task case needs a booted generated device: N4 writes it (blocks_w4.md). Its five decisions stand for
    review (agent, 2026-10-21).
46. **P3's points** (lead, 2026-10-21; P3 `934539c`): R-9 applied. One helper, `_write_text()`, writes 256-character
    slices of the serialised text with a yield before each and before the close, both sites under `_config_lock`
    (setup's write takes it now too); the only file reader is setup's boot `json.load`, before any write. littlefs's
    commit point is stated at line level (v1.29.0: truncate in RAM, one atomic metadata commit at close, a torn commit
    fails its CRC), so a mid-write reader or a power loss sees the old document. The longest stretch falls 2129 →
    1720 ms (common case about 427 → 400 ms), relayed to D for J.6 with the `config.flush_slice_chars` row;
    `_FLASH_HOLD_MAX_MS` stays 2129 as an upper bound, so B68 does not move and the changelog gets no row (agent,
    2026-10-21; it stands for review). Allocation: about 350 B per slice, no whole-document copy, zero MemoryError.
    Its three class-5 residuals (an interrupt parked at a yield lets the finaliser commit a prefix; a MemoryError in
    the fallback; a failing fallback close replacing the cancel) and the slice churn go to P4, with a `memoryview`
    form the lead probed on the pinned port (py/objstr.c:2219: `str` exposes its buffer; a slice costs 64 B). The
    cross-lane red P3 found, tests/test_bus_hazard_multi_device.py:1095 (lane V), is the test's posix-file model, not
    the product: P4 lifts P3's commit-at-close fake into tests/_littlefs_fake.py and V4 uses it after the lead merges
    P4's head into V. The old P4 (R-10 and P's checks) is now P5. P3 ran 12 calls past the valve.
47. **V3's points** (lead, 2026-10-21; V3 `ad1ac1f`, `7836588`, `e305fcd`): OF-200 profiled at line level: the cost of
    V2's two clock groups was scheduler rounds, 1.13 ms each, because the pinned extmod/modselect.c:353-370 gives the
    system `poll()` a 1 ms timeout whenever a pollable is not an fd (a waiting ThreadSafeFlag), the lead confirmed the
    source; this is Unix-port only (the rp2 build has no POSIX optimisation path). The groups now take 160 six-hour
    stalls and a 120 s window with the events' residues kept, each bite still red; test_sensortask is 5.0-5.8 s faster
    per device at both stages, 96/96. New finding, fixed: the recombination test never reached ESTABLISHED (its
    disconnect landed in the first connect, phase 0 throughout), a check that matched nothing (twin, STA, dev); it now
    waits for ESTABLISHED, scripts one failed reconnect and asserts the real 60 s retry, bitten four ways. That adds
    the retry's minute to the twin bus hazard file (85 → 147 s) and leaves a thin margin in its 75 s window: V4 drives
    the retry if the clocks split, else derives the bound from its parts. D.15 applied; the d15 checker counts the
    registered scenarios as sortable (their order is registration order), the same import-time class as LEAD NOTES
    36's row for U36. The 1 ms poll round is a findings row in U35's records (efficiency of the Unix-port rig; any fix
    sits in toolchain/micropython_overrides.py, routed by the rule). V4 is split into V4 (the stall residual, the
    retry) and V5 (the posix-file look after P4, LEAD NOTES 34's parts, V's checks). V3's foreground runs missed their
    RUNS.md lines again (its own report): the records name the gap.
48. **H1's points** (lead, 2026-10-21; H1 `76b2d7f`, lane H's first block): steps 3 (R-7), 5 (OF-02, OF-05) and 122
    applied, each seen failing first or bitten; the check-only rows confirmed. "Sent" means a general call reached the
    bus, NAKed or not, since dev's lone i2c0 device (a BMP388) has no general call and the twin acks one only for an
    SGP40 (agent, 2026-10-21; it stands for review); R-25's citation is ports/rp2/machine_wdt.c:44-61 (agent). OF-226
    is blocked on two files in no lane, tests_hardware/device_scripts/bench_facts.pyi and
    tests_hardware/flash/test_memory_stress.py: both join lane H (lanes.py) and H2 takes OF-226 in H1's proposed form,
    with H1's class 4/1 finding (the sweep's `_probe()` treating ETIMEDOUT as absent) and the held-SDA twin rc=1 matched
    to its twin_record entry or root-caused. The old H2 is H3.
49. **U3d's points** (lead, 2026-10-21; U3d `181c954`): the twin proof landed on the driven clock (link, wire byte
    times and three in-memory readers through `_serve()`), every verdict read back through GET /status, bitten twice;
    one plant ("any answer is an ACK") could not bite, since the twin peer answers only legal frames. The mock mirror's
    final form was seen failing. Times: link driver 2.4 → 3.4 s (-1) and 2.5 → 4.9 s (32768); the twin link file
    55.1 → 61.9 s at -1 but 58.7 → 128.3 s at 32768, because the readers serve requests for as long as the run lasts:
    U3e paces them first. Two reds on U's branch in V's scenario file: :2491's dev sensors set now lacks `UART_init`
    (a W6 lead item), and :2728 is C4's red that V2 fixed on V. Three new tags wait on D2. U3d's decisions (the driven
    wire, in-memory readers since a socket listener needs a band in tests/_port_bands.py, the 1 ms write pause, the
    virtual bound with no margin) stand for review (agent, 2026-10-21). Its 12-check run has no RUNS.md lines.
50. **N4's points** (lead, 2026-10-21; N4 `5ce41a4`; lane N complete): step 99's A.U22.01 case landed on arzi (the first
    device wiring the NeoPixel) through the shared `boot_generated()`, with only the NeoPixel's two starters under the
    real supervisor; the frames after the restart are exactly black then the overlay grey, the overlay task survives,
    and SYSTEM's FRAM chunk holds one TASK_RAISED entry; bitten four ways at both stages. The file grows 0.44 s
    (+3.1 %, the new test with its boot). The six decisions stand for review (agent, 2026-10-21). Lane N's only red is
    tunables_register's two Part N rows, D2's.
51. **W1's points** (lead, 2026-10-21; W1 `1b638f1`, lane W's first block): steps 174-179 confirmed. OF-144 in part:
    `startShell()` takes `pageBuildDate` and reloads when GET /system's `build.BuildDate` differs, seen failing first
    and bitten; a reload loop is bounded by construction (one stamp in page and module, no-cache, the stager's check).
    It does nothing in production until js/main.js and js/app.js pass it: both join lane W (no lane held them) with
    tests_js/_live_matrix_command.js and tests_js/_source_constants.js. OF-231 applied (one format table held equal to
    `FIELD_FORMATS`); OF-214 in part (every reached skip checked against `EXPECTED_SKIPS`). W1's remainder (the entries'
    wiring, a checked map of not-driven status actions so lane U's `UartHazards` cannot slip in unseen,
    `readStringSetConst`'s move into the shared constants reader, OF-214's seeding only where no case loses its mode)
    and the web tier go to a new W3; W2 keeps the tests_scripts hygiene. tests_js/_put_field_cases.js:56's comment is a
    W6 lead item. The four decisions stand for review (agent, 2026-10-21).
52. **P4's points** (lead, 2026-10-21; P4 `b52f3b6`, `8f2f15f`, `65f7454`): the interrupt residual is closed another
    way than briefed: a KeyboardInterrupt never reaches the flush's own handler while it is parked (run_until_complete
    lets it out, extmod/asyncio/core.py:154, :194; the boot entry's new event loop drops the task), so `_write_text()`
    fills `<file>.tmp` and `os.rename()` replaces the config file in one directory commit (lfs2.c:4062-4070, read by the
    lead: the old entry's delete and the new entry's create share the commit); the finaliser can then commit only the
    sibling. Decided on the owner's behalf for review (agent, 2026-10-21): write-then-rename is the scan procedure's own
    minimal fix, and it keeps the old document whole on a Ctrl-C, a power loss or a failed rename. A failing close in
    the fallback is logged and the cancel or interrupt goes on; slices are 256-byte `memoryview` views in "wb" mode
    (`config.flush_slice_bytes`, relayed), in their own commit so it can be reverted alone; a reset to defaults also
    removes a stray sibling, since an old document (config_WIFI.cfg's password among them) outlived a reset otherwise.
    A flush's allocation falls 9088 → 7616 B and 20512 → 14432 B (base 6656 and 13024); each write gains two metadata
    commits, each its own stretch, the longest still 1720 ms. Effect: the same on all six devices and every mode; in USB
    a Ctrl-C and soft reset mid-flush leave a whole document; a power loss during the first boot's write leaves the file
    absent (defaults again at the next boot) rather than a ConfigFault. Two reds in V's files follow from it
    (`_flash_stall.py:68` on a memoryview, which breaks the twin CI until fixed; `_DirWrites` counting `.tmp` names): V5
    fixes both after the lead merges P's head into V. test_bus_hazard_multi_device.py:1095 is green again, since the
    rename is atomic on posix too. P5 checks every config-directory listing for the sibling first. src/ holds no
    listdir (the lead's grep).
53. **H2's points** (lead, 2026-10-21; H2 `e9fd1c7`): OF-226 applied in H1's form: the loop-lag script's
    `BENCH["mode"] "production"` boots main() on the board's own config and address, a new bench test hammers every
    JSON GET route at the hammer's reader ceiling and asserts every route answered, the memory markers, main_running,
    the FRAM writes and the lag; the flash test runs twin-only with the same evidence; both fail on an empty route
    table. The sweep's `_probe()` reads only ENODEV (rp2 soft I2C's address NAK) as absent, ETIMEDOUT and every other
    errno as a bus fault; bitten. The held-SDA twin rc=1 matches its twin_record entry at `f3fff0e`, with its line-level
    cause (the twin's open-drain `Pin.value()` reads only planted levels, digital_twin/machine.py:223-227, 313-314).
    The production mode made test_persistence_write_marker_completeness red; the lead triaged the script into
    `_PREREQUISITE_DEVICE_SCRIPTS` with the three serving scripts' `_SERVING_REASON` (`50e22ab`, 28 passed): CLAUDE.md's
    persistence-gate rule pins that set so a new prerequisite is triaged against it, and this one's only possible
    writes are a production boot's own. The set grows by one row: decided on the owner's behalf for review (agent,
    2026-10-21), named in the owner report since the lead's rule is that allow-lists only shrink. Wear on silicon
    falls (no scratch defaults written per run). H2's decisions (the `mode` extra reused, the flash test twin-only,
    only ENODEV absent, a 90 s bench script timeout tagged) stand for review. H3 takes the reader-death thread and the
    two doc facts.
54. **W2's points** (lead, 2026-10-21; W2 `0d33534`): OF-197 (the encoding guard's scopes tied to host_typecheck.ini by
    a test, non-literal `encoding=` flagged), OF-199 (test_tool_help reordered; test_port_lock already in order),
    OF-206 (the shared scan walks statements only, frees the tree before one token pass, caches prose blocks per path
    and text: every one of 28649 blocks equal against the base module; test_citations 10.2-10.7 → 8.1-8.5 s,
    test_decision_vocabulary 7.5-7.7 → 6.0-6.2 s, test_host_text_encoding 1.7 → 1.4 s), OF-207 (`_ruff()` takes the
    venv's pinned ruff first) and OF-212's schema half (a computed or ownerless schema file name is named; SCD30's file
    is named, not added to `_OWNERS`) applied, each seen failing first. Its red, test_no_variant_literals on W1's
    `'arzi'` skip keys, is W3's first item. Two copies of `_ruff()` (test_lint_ceilings, test_ruff_exemptions_live, the
    second in no lane) are a findings row for U35's records, routed by the rule. The five decisions stand for review
    (agent, 2026-10-21).
55. **V4's points** (lead, 2026-10-21; V4 `094bc07`, `a11603a`): LEAD NOTES 40's residual applied: one plain microsecond
    clock in digital_twin/_flash_stall.py (gaps by ticks_us up to 2**28 us, by ticks_ms beyond), windows matched by a
    plain comparison, the UART link reading its wire time off the same clock; seen failing first on both aliasing cases.
    LEAD NOTES 47: the clocks split: a test-local stand-in hands only the WiFi service's `sleep(60)` to a DrivenTime,
    the retry stays parked through 3 real SCD30 cycles, then advances by exactly its length; the retry is asserted at
    exactly 60000 ms, bitten four ways. The twin bus hazard file falls 147.0 → 93.0 s (-1) and 149.1 → 94.6 s (32768);
    the test alone 74.1 → 20.1 s, so the 75 s window's margin worry is gone (its Part N row now bounds about 20 s: D2's).
    V4's red outside V, tests/test_digital_twin_clock_jump.py:251 (in no lane), root-caused by the lead at line level:
    its `_set_clock()` stands in for a sync with `_set_synced(True)` and `set_utc_valid()` only, while a real sync also
    sets `_clock_valid` (src/asy_ntp_client.py:297-299), which the VOC backup reads since `<CLOCK>`; C4's generated-module
    runs did not include this file. The lead fixed the stand-in on V (`a102ada`, 6/6 at both stages, red on `e305fcd`
    first) and made the other stand-ins a W6 item. The lead merged P4's `65f7454` into V as `c805172`, rebuilt, for V5.
    V4's decisions stand for review (agent, 2026-10-21).
56. **P5's points** (lead, 2026-10-21; P5 `596e7ff`): the listing check found no P file misreading P4's sibling (the
    scenarios' `_DirWrites` is V5's, known; every other listing reads right, one line each in the hand-back). R-10:
    OF-221's row is right; three new tests failed on `65f7454`; the fix gives each store reset the lowest free bit of a
    29-bit set, a repeat of the newest code marks every reset begun with nothing kept since, an append ends that, and a
    `finally` frees the bit on every exit; a 30th reset in flight on one store is refused at once ("Failed", nothing
    cleared). Bitten three ways; allocation per reset 1344 → 1440 B transient; every FRAM device in STA and AP
    (ResetErrors over REST), nothing in Silent, Off or USB. The two decisions stand for review (agent, 2026-10-21).
    Changelog row B89 (Class B) covers 1856280's six narrowing comments; uart_comm's bytes are identical. Two reds left
    in P4's test file (test_microtest: an `asyncio.run()` outside the harness, and 10 json.loads sites against the
    file's 2): a small P6, with tests/_async_harness.py joining lane P (no lane held it). P5's twin fact,
    digital_twin/_flash_stall.py stalling at the sibling's close but not at the rename's directory commit, is a
    findings row for U35's records (the twin under-counts a config write's second metadata stretch), routed by the
    rule.
57. **U3e's points** (lead, 2026-10-22; U3e `14e5407` pacing, `9f01fd4` bench, eight D.15 commits to `a3c3392`): the
    twin readers are paced on the driven clock (249 reads per run at both stages, an exact per-period guard added and
    bitten), so the twin link file is 54.7 → 61.3 s (-1) and 58.6 → 76.3 s (32768) against U3d's 128.3; the bench test
    is collected (silicon parked for hardware session 1); 13 `## D` lines relayed; D.15 applied per file. Its scans
    found reds U3a's src change left: tunables (D2's), A.11 (D2's), task_tops and task_inventory (`_two_initiations()`
    has no task top), const_mirrors (`_RECOVERY_ATTEMPTS` shared with two test constants) and memory_catalog
    (`_hazard_facts`). The lead classified `_hazard_facts` in `_RUN_PHASE_ALLOWED` (`8039259`: one verdict record per
    on-demand run, replacing the last, the class of a reader's latest sample; 22 passed): the catalog lists reasoned
    run-phase cases by design, so it grows by one row, decided on the owner's behalf for review (agent, 2026-10-22) and
    named in the owner report beside LEAD NOTES 53's row. Its class-1 finding (a failed raw write in the field sweep
    reads as the expected "not ACKed") is the unit's own new code, so it is fixed, not flagged: U3f takes it with the
    task top and the constant's rename.
58. **H3's points** (lead, 2026-10-22; H3 `7a7d01a`; lane H's code complete): a dead load or lag reader in
    tests_hardware/flash/test_memory_stress.py now fails the test naming its exception (bitten at both stages). Step 140
    with OF-229 is applied in code: the recorder runs every instrument at -1 and 32768 (the flash tier once per stage
    through a recorder-owned pytest plugin, a run whose board never took the stage refused), each entry carries
    `stages`, and a script is charged only with the outcomes of the test functions that reach it. The record is not
    re-recorded: the lead does that at W6 with H3's `S/u35/laneH/h3/record.sh` and `reasons.json` (2059 s for both
    stages). The sharper charge unmasked one failure hidden behind a file-wide reason in every earlier record:
    test_uart_crossover.py's idle-listener test on the twin, "a listener outlived comm.clear()", at both stages. It gets
    no reason until root-caused (agent, 2026-10-21): R2 does that, read only. H3's class-4 list of other thread targets
    that leave only pytest's warning (lane H's soak and VOC-reset readers, `_lag_load`'s driver, end-to-end `_client`;
    five other lanes' bench files) is a W6 lead item to weigh: tests_hardware/conftest.py (lane Y, complete) turning
    PytestUnhandledThreadExceptionWarning into an error, checked against the re-record so no hidden death is lost.
59. **R2's root cause** (lead, 2026-10-22; `S/u35/handbacks/R2_final.md`, evidence in `S/u35/laneR2/`): the
    idle-listener red is a stale test expectation, not a product defect and not a twin gap. `clear()` cancels the
    parked read; ready() returns False, `_listen_unlocked` faults with E22 and resyncs, draining one quiet window of
    1.5 x timeout (1500 ms on dev's default) before uart_listen() returns; Part J says exactly that (:9387-9390, :9486),
    the path is shared Python, so silicon behaves the same. The script's 400 ms settle disagreed from its first commit
    (dc05ce8, after c63ef97's resync); 06a8ae5 made it assert, and the file-wide record reason hid it until H3. The
    lead applied R2's fix on H (`591c4ac`: the wait is the comm's own window plus the 400 ms slack), 1 passed at both
    stages on the twin; the bound rises with its basis named, decided on the owner's behalf for review (agent,
    2026-10-22); the Part N row's restatement and R2's measurements are relayed to D. No src/ change, so no changelog
    row. R2's fact: every clear() of a healthy parked listener persists one E22 on a FRAM-wired instance; only test
    scripts call clear() today.
60. **T3d's points** (lead, 2026-10-22; T3d `5ca6b30`): folds (11) (a stopped SCD30 ends its alerts and the SGP40's
    compensation: State 3, no red frame, no 0x260F measure; the lead confirmed 0x26 0x0F as sgp40_measure_raw_signal in
    the SGP40 datasheet's Table 9), (13) (a restarted SGP40 task keeps its live VOC state, not restored from FRAM) and
    (18) (6 back-to-back captive DNS queries answered in at most 7 wake-ups) landed, each bitten; every real wait in tests
    6-9 moved to a stepped form (datasheet waits stepped in the twin only, L1 still pins their values), each bitten.
    arzi's file 73.7 → 60.0 s, the others flat. A collision of two same-device processes (each wipes its scratch dir)
    made one base run red; rerun alone it passed: a run-discipline rule now in common_u35.md, not a defect. T3d's class-3
    gap in (18) goes to T3e. Its five decisions stand for review (agent, 2026-10-22).
61. **U3f's points** (lead, 2026-10-22; U3f `6f6e99a`; lane U complete): `_two_initiations()`'s tasks run `_initiate()`,
    whose top reports a fatal error and logs E23 UNEXPECTED, then answers None (task_tops green); the constant is
    `_HAZARD_RECOVERY_ATTEMPTS` (rename alone byte-identical, 3516 B); a failed raw write in the field sweep records
    None, not "not ACKed". U3f also found the TwoInitiations judges (link driver test, twin, bench) read `[True, None]`
    as a pass (`sorted(r is True)`): a check matching too much, now exact (only `[True, False]` or `[False, True]`),
    bitten on a planted None refusal. Each item seen failing first; dev only, STA and AP; nothing stored; the wire format
    and protocol module untouched. Times flat (link driver +0.18 s). Its reds wait on D2 on the merged head: Part N
    rows for 10 tags, C.9's `_two_initiations()` row (task_inventory), A.11's UartHazards sentence
    (threat_model_statement); W6's gate names them as expected. The five decisions stand for review (agent,
    2026-10-22).
62. **T3e's points** (lead, 2026-10-22; T3e `7f5501d`): T3d's (18) gap closed (the listener's idle sleeps during the
    burst counted, at most 1; both plants bite, and the old test passed them); 149's booted boot order applied: the runner
    prints a `boot phase:` line on each region-1 write (`_print_boot_phases()` wraps `_write_region`, the write
    unchanged), and test_digital_twin_generated_boot checks every booted device's BOOT_* marks against main()'s order,
    seen failing first and bitten by a planted timers-before-tasks boot. Times flat. 125 (f)-(i) and folds (1)-(3) were
    deferred whole: T3f takes them before W6, since they add twin scenarios W6's gate should run. The README's
    `boot phase:` text is T4's. The four decisions stand for review (agent, 2026-10-22).
63. **B1's points** (lead, 2026-10-22; B1 `d22a9e8` to `d7d2f0c`, lane B's first block): A.U35.01 opened audit/b3/ (11
    files); 104, 137, 141 applied; 102, 138 and 153 in part (their cells are B2's review and the campaign's). The 2**30
    build (audit/sweeps/ticks30_build.sh, a scratch Unix port, the shared toolchain untouched) shows OF-32's probe red on
    `f3fff0e` and green on Y's `5cf361c` and V's head; V1's and Y3's wrap files pass on it with the wrap at a quarter, a
    half and three quarters of each file, at both stages (`<T30> e1ad71f` under `## B`). Its generators re-run on the
    integration head (B2). New finding from 137's walk: six catalog codes no test names (asy_base_classes.py:82-86's
    CFG_SET_RAISED, PUSH_RAISED, CFG_SNAPSHOT_RAISED, RECOVERY_READ_RAISED, RECOVERY_WRITE_RAISED; asy_uart_comm.py:137's
    UART_WRONG_KIND): a findings row in U35's records, routed by the rule to U36, the next unit holding
    tests/test_asy_base_classes.py and tests/test_asy_uart_comm.py. Its generator fix (an empty commit stamped as
    "unknown") is class 4, its own file. The three decisions stand for review (agent, 2026-10-22).
64. **V5's points** (lead, 2026-10-22; V5 `8edb5aa`): P4's two follow-up reds in V's files are fixed, each seen red on
    `c805172` first (`_flash_stall.py` counts a memoryview by `len(data)`, typed `IO[bytes]`; `_DirWrites` counts a
    sibling's write at its rename, bitten by dropping the product's rename); test_bus_hazard_multi_device :1095 is green
    without the fake (the rename keeps every look whole). Two of LEAD NOTES 34's parts landed (an exception escaping the
    supervisor; a cancelled `main()` with every armed Timer fired adding no feed), bitten four ways. New finding, fixed:
    V2's stuck-task check "every other live Timer fired" matched nothing, since `_boot` armed no timer. A full twin CI
    run on V's head passed every row on dev and arzi at both stages (suite 506-572 s, harness 433-557 s). test_sensortask
    grows under 5 % per device. V5's decisions are dated 2026-10-21 in its report though taken after midnight UTC; the
    records date them 2026-10-22. The remaining 114 parts (forty days' WiFi uptime, NTP age and resyncs, ring
    saturation, stored ticks; the storm's periodic paths, scan budget, recovery and ladder; Pin IRQs, which need a pin
    registry in tests/machine.py) take V6; tests/machine.py passes from Y (complete) to V for it.
65. **T3f's points** (lead, 2026-10-22; T3f `b7d9f31`): step 125 (f) (three watchdog-fault scenarios on every device),
    (h) (a bounded fault storm per logger against the persisted-log rate, unattributed writes 0) and (i) (zero-think
    readers saturate, then recover) landed, each bitten by a planted defect; controls pass on all six at both stages.
    (g)(a), (g)(b) and folds (1)-(3) were deferred whole. T3f's finding: each SGP40 storm event persists two entries,
    its failure and `_error_check()`'s streak entry (src/asy_base_classes.py:584, SPECIFICATION.md C.7's contract), so
    the alternating codes defeat the newest-entry rule, and a sustained 4-in-5 fault pattern reaches the 627 ms rate's
    ceiling. That is long-standing, specified behaviour, not U35's to change: a findings row in U35's records for
    review, routed by the rule. The test's own fault, (h)'s spawn-to-exit window (a fast host would fail it with no
    defect), is T3g's first item. Three estimated tags (`l2.zero_think_*`) wait on D2. T3f's decisions stand for review
    (agent, 2026-10-22).
66. **W3's points** (lead, 2026-10-22; W3 `7d6d255`; lane W complete): the put matrix's expected skips are keyed by
    section, wired group and field with no device name (W2's red green); OF-144 is wired in production (js/main.js and
    js/app.js pass `pageBuildDate`), seen failing first in shell.test.js with only the reload spied; the not-driven
    status actions are a checked map with a probe-reach floor, lane U's `UartHazards` listed ahead of the merge, each
    bitten; `readStringSetConst` moved into the shared constants reader. OF-214's seeding is stopped with its reason
    (an SSID would boot every first-device case in STA, and the twin runner blanks DNSFallback itself,
    digital_twin/unixport/_offline_ntp_config.py:28): the two arzi skips stay listed, and OF-214 stays open in part in
    U35's records. The web tier is green (put matrix 350 passed, 6 skipped; 725.4 → 727.2 s). shell.test.js grows
    2.6-2.7 → 3.1-3.2 s (+18 %, about 0.5 s) from W1's five tests and both entries' module graphs: a file under 10 s
    whose growth is new checks, accepted under LEAD NOTES 4 (lead, 2026-10-22). Two W6 lead items follow (the
    `NOT_DRIVEN` stale-row check; a `readStringSetConst` case in tests_js/source-constants.test.js, in no lane). The six
    decisions stand for review (agent, 2026-10-22).
67. **P6's points and W6's start** (lead, 2026-10-22; P6 `480d4cf`; lane P complete): both test_microtest reds fixed
    (the harness's new `run_to_interrupt()`, which refuses to nest like the harness's other runners; one `_decoded()`
    helper leaves the file 2 json.loads calls); P4's bites still bite through the moved helper. The refusal test sits in
    tests/test_asy_config_manager.py; L1 moves it into tests/test_async_harness.py. W6 began: `audit/u35-int` in
    `S/wt-u35int` from `f3fff0e` merges U34's final (`05a0d31`, tree equal to the pushed `49fde7b`) and the finished
    lanes C, E, F, N, Q, Y, P, U, W, H, B (B1) and D (D1), all clean (`01691bf`); uv.lock untouched. Lead edits on int:
    LEAD NOTES 27's two quotes (`a94ddd5`; decision vocabulary, citations and attribution green) and LEAD NOTES 51's
    comment (`152f1ca`). The lead's remaining test items run as block L1 on `audit/u35-l` from `152f1ca` (LEAD NOTES 38,
    55 for the merged files, 56, 66); lanes V, T and G merge when they report; then block K (owner question 6),
    LEAD NOTES 21's and 49's edits, the twin-integration stand-in (55), the rebuild, the twin re-record (H3's recorder)
    and the gate.
68. **G1's points** (lead, 2026-10-22; G1 `ef01de5`; lane G merged into int as `4c1817b`): both twin files boot and run
    on one DrivenTime lent to every asyncio-holding module, the twin's machine and network, from before boot; every
    wait is a `run_until()` in driven seconds, every assertion kept; 17 plants bitten. Timer pool falls 27-35 → 11-12 s
    on five devices, hot replug 71 → 37 s; the reboot case stays real (its run-out is measured on the twin WDT's own
    clock), and dev's cases stay real because digital_twin/machine.py:901 at `1d77560` diffs against
    `_flash_stall.EPOCH_US` on the real clock, which the 2**30 driven ticks refuse (G1's line-level reason, class 3:
    host-load-dependent waits kept). V4 replaced that diff with one plain microsecond clock (`094bc07`), so on the
    merged head the guard's reason is stale: block G2, after V merges, tries dev on the driven clock (the guard removed,
    seen passing on dev at both stages and each G1 plant still biting there) or restates the comment with the new
    line-level reason. Two Part N rows (`l2.timer_pool_wait_s`, `l2.hot_replug_wait_s`) now bound driven seconds: D2's.
    The four decisions stand for review (agent, 2026-10-22).
69. **V6's points** (lead, 2026-10-22; V6 `c9904c2`; lane V merged into int as `3f2183c`): Pin IRQs applied (a
    test-only `Pin.wired_irqs()` over the fake's existing state table; all three feed scenarios fire every wired IRQ
    through its real handler and assert no feed), bitten on arzi and dev; a new finding fixed: `_arm_every_timer()`
    never collected the trigger starters, so the ISL29125's IRQ and the readers' trigger timers were never armed (dev
    fired 5 timers before, 8 now, plus GPIO6). Forty days gained the WiFi uptime and NTP sync age on driven seconds
    across four wraps, bitten twice; the scan budget had landed; the storm's L2 half is T's Run 3 (`b7d9f31`).
    Remaining 114 parts and V6's two fake-fidelity gaps (tests/machine.py:150 `irq()` against ports/rp2/machine_pin.c
    :464-466 and :473) go to V7 on the merged head; tests/test_fakes.py joins lane V. V6's class-5 finding,
    src/asy_ntp_client.py:374 (the resync cadence counts delivered 10 s ticks, so a dropped tick delays the resync; the
    stale rule at :372 reads elapsed time, so the status stays honest), is a behaviour discrepancy: SPECIFICATION.md
    D.1's flag-first path, a findings row in U35's records routed by the rule, no change in U35 (lead, 2026-10-22).
    test_sensortask grows under 2.2 %. G2 starts from `3f2183c`.
70. **G2's points** (lead, 2026-10-22; G2 `7d7c594`, merged into int): with V4's plain clock merged, dev's UART-wired
    plan runs on the driven clock; the guard and the real-time branches only dev used are gone, the comment names
    `plain_us()`; the reboot case stays real. dev's timer pool 43.4 → 12.6 s (39.8 → 13.1 at 32768), hot replug
    37.3 → 8.1 s; 19 of G1's plants bite on dev. G1's class-3 finding closes for dev. Its five reds are the int head's
    own, waiting on D2 (the Part N rows; C.9's `_two_initiations()` row; task_inventory's NeoPixel lines are its
    self-tests counting that one real finding too, read by the lead). Lane G complete.
71. **T3g's points and the full merge** (lead, 2026-10-22; T3g `b6902cd`; lane T merged into int as `bb2e3f3`): (h)'s
    bound now counts entries per event (each logger 2 x (its setup write + what its events allow): SGP40 2 per failed
    cycle plus 1 per rung reached, WEBSERVER 1 per unserved connection), exact on all six; the storm's own window could
    not carry a 627 ms rate (about 3 entries a second), so the scenario is renamed for what it checks. (g)(a) and (g)(b)
    landed (NTP unreachable under bus and API load, then with concurrent config writes), each bitten; T3g root-caused
    its own index bug. Folds (1)-(3) stay T4's: fold (3) looked blocked on T's branch, which lacks P4's `unpersisted`
    (src/asy_config_manager.py:332 on the int head), so T4 reads it there. Four estimated tags wait on D2. With T merged,
    every lane is in `audit/u35-int` but L1 and V7 (running); int rebuilt at `bb2e3f3`; the lead runs the unit tier once
    at -1 there as a pre-gate smoke while L1 and V7 finish (`S/u35/lead/pregate/`), so merge reds surface before
    block K and the gate.
72. **V7's points and the W6 edits since** (lead, 2026-10-22; V7 `ed649bd`, merged into int as `c9a08da`): both pin
    fakes follow ports/rp2/machine_pin.c:464-476 (an external pin raises, a bare `irq()` returns the registration),
    seen failing first, the twin's copy included (D.10); ring saturation per logger (all six), the ISL29125 stored ticks
    and the UART stored tick (dev) landed, each bitten; the NTP resync count stays out (V6's flag-first finding). The
    storm's periodic paths, recovery and ladder rungs remain: V8. V7's merged-head reds: test_lock_order x9 on
    src/asy_uart_link_driver.py:164 and :228 (`async with bus` on a parameter, no C.8 row; lane U's, now X1's), and
    LEAD NOTES 49's dev sensors set (now V8's first item). The session process restarted at 02:31:01 UTC; L1's and V7's
    scripts survived, both agents were resumed from their transcripts, and the lead's pre-gate run was terminated
    (logged). The lead's re-run of that smoke was then stopped by the lead, since V7's merge and LEAD NOTES 21's edit
    landed in the same worktree during it (a mixed tree; logged, not evidence). LEAD NOTES 21 is committed (`2360470`:
    the SPI fake's `TEST_API` typed `tuple[str, ...]`, the FRAM chip fake's ignore gone; all mypy passes clean, run
    directly since typecheck.sh refuses a symlinked venv). A clean smoke runs after the last merge, before block K.
73. **L1's points** (lead, 2026-10-22; L1 `abdeb6f`, merged into int as `d14b39b`): LEAD NOTES 38 applied (the sweep
    swaps in a counting `asyncio.Lock.release` for its lifetime, every count checked, a floor at entry; seen failing
    first on a planted double release that the old sweep missed in two files; no time growth); LEAD NOTES 56 (the
    refusal test moved unchanged into tests/test_async_harness.py, still biting); LEAD NOTES 55: none of the 20
    stand-ins in the notification and NTP files reaches UTCTime or a VOC backup (the only reader of the flag is
    `ntp_clock_valid()`, and the tests that read it use the real `_handle_ntp_sync_success()`; listed in
    `S/u35/laneL/standins.txt`); LEAD NOTES 66 (`staleNotDriven()` with a planted case; four `readStringSetConst`
    cases, bitten). E's `_BalanceLock` is now partly redundant with the sweep; it stays (a findings note, E's file).
    L1's one foreign red, test_microtest's json.loads count on tests/test_digital_twin_uart_link.py:454 (lane U's
    in-memory reader parsing response bodies with json.loads), is fixed by the lead through `strict_loads()`
    (`HEAD` of int after `d14b39b`; 22/22 at both stages; no allow-list row added).
74. **V8's points and the lead's fixes** (lead, 2026-10-22; V8 `88593ce`, merged into int as `5c9d176`): LEAD NOTES 49
    applied (dev's expected sensors gain `module.uart_link_init.name` where `_has_uart_link`, the hazard report's keys
    pinned), bitten; a bus NAK storm through every rung and recovery on all six (per reader one give-up and one
    participant rung, per bus one clear and one controller rung, loops restarted at streak 0), bitten; a refused-
    connection storm spending one slot, bitten; one bite (the streak never counting down) stayed green because the
    restart's init resets the streak, and the comment says so. The NTP no-reply part and the paired times are V9's.
    V8's new merged-head reds: fake_surface_conformance[SPI] was the lead's own regression (LEAD NOTES 21's annotated
    `TEST_API` is an AnnAssign the check skipped); the lead taught the reader both forms (`0485607`, red first, a
    planted bogus name still caught). level_containment's four new twin scenarios (T3f/T3g's) without an L3/L4
    counterpart or E.6.6 row wait on D2 with the other document rows.
75. **X1's points and the lock-order fix** (lead, 2026-10-22; X1 `931e591`, merged into int as `5d626c6`): LEAD NOTES 55's
    twin half found a check matching too much: test_digital_twin_sensortask_integration's restored-backup test stood in
    for a sync without the clock-valid flag, so the backup got the unset stamp 0, and `written is not None` let 0 pass;
    the stand-in now sets the flag and the check reads `assert written` (seen red on arzi first; class 4, fixed). The
    other three stand-ins never call `ntp_clock_valid()` (X1's probe) and say so. test_lock_order's nine reds: X1
    stopped rightly, since the clean form also needs lane U's twin link test, and handed over a verified patch; the
    lead applied it on int (`HEAD` after `5d626c6`): the raw read and write take `self._uart` with the protocol module's
    None guard, four methods drop the parameter; mpy-cross 3680 -> 3693 B, five code objects; no wire byte changes; dev
    only (STA, AP). ruff, every mypy pass, test_lock_order and eight readers green; the three files pass at both stages.
76. **Block K** (lead, 2026-10-22; owner, 2026-10-21: "6: c", asked "Count a long comment line as several?", option (c)
    "the same at 120 characters"). Measured on int `bc0d77b`: 163 blocks in 147 files over the cap at width 120, none in
    the generated modules; tests/_sensortask_scenarios.py's one block waits for V9's merge (the lead's). Five fresh
    agents on disjoint sets (`S/u35/lead/k/k1.txt`..`k5.txt`, brief `S/u35/briefs/blocks_k.md`): K1 src/buildgen/toolchain
    30, K2 digital_twin/scripts/tests_hardware 43, K3 tests 39, K4 tests_scripts 50, K5 the review-enforced JS, CSS, HTML
    and config (61 comment lines over 120 in 27 files). Three run at once with V9; the lead's pre-K smoke waits for V9's
    hand-back (CHECKLIST 23). Tools `S/u35/lead/k/show.py`, `verify.py` (AST with docstrings blanked, or non-comment
    lines, equal to the base; bitten on a planted code edit and a docstring edit, both seen), `measure.py`. Decision
    (lead, 2026-10-22): K runs no unit, twin or timing files; verify.py's proof stands in for a comment-only change's file
    runs, and the W6 gate runs every file on the merged head. src/ keeps line counts for a byte-identical plain mpy-cross
    output, else `-O3` (py/emitbc.c:429-432: no line numbers). The lead flips `_WRAP_WIDTH` to 120 after K's merge and
    restates its comment; CLAUDE.md's sentence and BACKLOG question 6 are D2's (relay `## D`, lead line 2026-10-22).
77. **Merges and the toolchain record** (lead, 2026-10-22): V9 `6b296df` merged as `052a5cd`; K1 `af38779` (`52bed78`),
    K2 `8c033e0` (`9e7a918`), K4 `48b634d` (`1bb72a4`); verify.py over every K file against `bc0d77b`: no code changed.
    K1 split 16 headers into paragraphs at topic lines, K2 3 (and moved 4 sentences beside their code), K4 2 (1 move);
    K3 and K5 were told to prefer tightening (each added line shifts citations). Kept for owner review: headers now carry
    two or three paragraphs where the long lines held them, the counting rule's paragraph break, every fact kept.
    The pre-K smoke (`run.sh` on `52bed78`) ran no test: K1's comment at toolchain/setup_toolchain.py:873 changes that
    file's recorded input hash, so `scripts/test.sh` ran setup (scripts/_unix_port.sh:162-183), and setup deletes the
    record first (setup_toolchain.py:856-857), then its `git fetch` failed in the no-network namespace. The binaries
    (20 Oct) are intact; the record is gone, so every test.sh run, the gate's too, would run setup. Fix (lead): one
    `setup` with network from int once nothing uses the binaries (after K3), then the smoke. Any later edit to a recorded
    toolchain input (`input_sha256`) needs the same one setup before the gate.
78. **Toolchain record restored** (lead, 2026-10-22): `setup` with network from int `1bb72a4`, 04:33-04:37 UTC, rc 0,
    235 s, log `S/u35/lead/toolchain/setup.log`. The rebuilt mpy-cross and both Unix-port binaries have the same byte sizes
    as the 20 Oct builds (444632, 915848, 874888), as a comment-only input predicts; every `input_sha256` entry matches
    int's toolchain/ files. Its apt step also upgraded the host's git package (setup installs its listed packages at
    their newest version, as on CI). The pre-K smoke and V10 started after it.
79. (lead, 2026-10-22, 04:48 UTC) K3 c8940f7 (tests/, 39 blocks: 13 rewraps, 8 tightened, 13 splits, 6 moves beside their
    code, 4 of them trailing comments) and K5 1fb687f (12 review-enforced blocks; the one meaning change, the malformed
    fixture's stale reader list, is named in its body and checked against test_build_device_websites_sh.py:66) reviewed in
    full and approved. Neither touches a file int changed since bc0d77b. Merge waits on the smoke (never merge into a tree
    a run is testing). K5 found measure_js.py over-counts (closing `*/` and @param continuations): js120.txt's extra 4s are
    tool error, not blocks. K3's per-file line growth is in K3_final.md for the remap.
80. (lead, 2026-10-22, 05:10 UTC) K3 and K5 merged in a second worktree, `S/wt-u35m`, so the smoke's tree stays as it
    is: `4922221` (K3), `f420ad8` (K5), then `e06966b` (lead): `_WRAP_WIDTH = 120`, its comment and self-test restated
    with the owner's words; BACKLOG.md's config_SYSTEM.cfg citation is now :78 and :121; it was :59 and :101, stale
    before K. remap.py now lists a citation the citing file's base text lacks, and never remaps it, so text written
    after the base cannot shift twice. Only 4 line citations point into changed files; that one pair was the only
    one to move. At width 120 the cap, citations, decision-vocabulary and legacy-path checks pass, except the cap's
    `tests/_sensortask_scenarios.py:477` (V10's). Int fast-forwards to `e06966b` once the smoke ends. Decision
    (lead, 2026-10-22): D2 starts now in two blocks, `S/u35/briefs/blocks_d2.md`, since every input is merged.
    D2a (SPECIFICATION.md's machine-checked rows) runs beside V10 and the smoke; D2b, the prose, follows on the same
    branch. Owner's word (2026-10-22): "1 or 2 more parallel works are still fine".
81. **Pre-K smoke** (lead, 2026-10-22; scripts/test.sh at -1 on `1bb72a4`, 04:38-05:21 UTC, 2615 s, log
    `S/u35/lead/pregate/gc_default.log`): unit and twin files 115 passed, 0 failed, 0 retried, "Passed only on retry:
    none"; 5796 tests passed; 0 `MemoryError`, 0 "memory allocation failed". tests_scripts 6768 passed, 9 failed, all
    known: tunables_register, level_containment, task_inventory x4 and threat_model_statement (A.11's `UartHazards`),
    D2a's; twin_record x2, the re-record's. The 83 tracebacks are deliberate: 60 are the twin integration file's
    injected status fault (10 per device), which the test counts as traced (`print_exception`, `traced`/`wrong`); the
    rest are named probes and injections in system_service, the unretrieved-report file and the NeoPixel files. Its 9
    tests_scripts skips: 6 real firmware builds (opt-in, the gate's firmware leg builds them) and 3 html-validate cases
    (absent from this worktree's node_modules; the gate's leg worktrees have it). Int fast-forwarded to
    `e06966b`; `S/wt-u35m` removed.
82. **D2a's points** (lead, 2026-10-22; D2a `8453305`, lead fix `5d0e16f`, merged into int as `85f3104`): Part N gains 16
    rows from the relay's TAG lines (the tree's values where they differ: `config.flush_slice_bytes`, U3a's 4,
    `_HAZARD_RECOVERY_ATTEMPTS`), withdraws `l1.notification_neopixel_wait_until_timeout_ms` and restates six bases; E.6.6
    gains `fault-storm-persisted-writes`, `ntp-unreachable-under-load`, `reader-saturation-floor` and
    `watchdog-fault-planted`, and restates `uart-hazards-under-api-load`; C.9 a "Hazard initiations" row, A.11
    `UartHazards`, I.2 `_hazard_facts`. tunables_register, level_containment, task_inventory x4 and
    threat_model_statement turn green; its 17 scans hold only the cap's `tests/_sensortask_scenarios.py:477` (V10's).
    The lead's review found two rows crediting the hazard mode to the owner. The owner decided the requirement, "b -
    system shall be proven stable unter max load allover"; the mode is the agent's form, decided on the owner's behalf
    for review (LEAD NOTES 12). One basis also carried "(lead, ...)", not an actor form. Fixed in `5d0e16f`; the eight
    D checks pass (97). D2b (relay prose, BACKLOG questions 5 and 7) runs now; D2c (owner answers 1-4 and 6, CLAUDE.md,
    README, D1's open steps, the 17 scans) follows on the same branch.
83. **V10 and D2b merged; open items routed** (lead, 2026-10-22). V10 `d1161ad` (int `db68c84`): the NAK storm's read
    triggers are Event-backed, since a waiting ThreadSafeFlag makes every Unix-port poll sleep 1 ms
    (extmod/modselect.c:353-370), with a one-waiter check (bitten); dev's storm 4121 → 732 ms; every device within +5.3 %
    of vbase at both stages; the :477 block fits. remap from `85f3104`: no citation into the file. Cap test green at
    `db68c84` (633). D2b `8fa324f` (int `57a005e`) reviewed: attribution as `5d0e16f`'s; its three dropped E.5.1 entries
    checked gone from the tree. Lead `03c46b6` dropped the comment T3g's constant removal stranded in
    scripts/_digital_twin_scenarios.py. Routing (finding rule: the next unit whose files hold the file):
    - U36: V10's finding that dev's scenario file spends 18.2 s of 56.3 s in that poll sleep
      (`S/u35/laneV/v10/pa_dev_-1.log`; the two largest scenarios 5.6 s and 4.4 s), an efficiency item, not growth;
      U36 holds tests/_sensortask_scenarios.py.
    - U36: D2b's (a), `_finish_write()` completes a cancelled config write with no yield, a stretch the flash-hold trace
      does not bound (src/asy_config_manager.py); reached only by a cancel or Ctrl-C at a write's yield.
    - T4 (W8): P3's twin fact, `_flash_stall` stalls the whole write at close (digital_twin/_flash_stall.py:57-66),
      conservative, for digital_twin/README.md.
    - D3: D2b's (b), whether E.5.1 misses src/asy_wifi_service.py's `_push_wifi_led()` False arm and
      src/asy_isl29125_driver.py's unreachable persist fallback, read from the W6 gate's coverage report.
    D2c (owner answers 1-4 and 6, CLAUDE.md, the README) runs on `audit/u35-d2` fast-forwarded to `03c46b6`; D2d after.
    Int rebuilt at `03c46b6`; the twin re-record runs there (`S/u35/lead/record/record.sh`, H3's script and reasons).
84. **D2c's points** (lead, 2026-10-22; D2c `5392e71` on `audit/u35-d2`; its merge waits for the re-record, which runs
    in int's tree): owner questions 1 (A.10's CI-suite paragraph), 2 (C.9's read-trigger failure path, C.4.1 pointing
    there), 3 (C.8, CLAUDE.md's `scd30_extra_write` sentence, three README places: up to 12 further writes, 13 a
    session with both flags, plus at most one start command; each figure checked against the four marked tests),
    4 (A.4's SCD30 start sequence, M.2 pointing there) and 6 (CLAUDE.md's "How a block is counted") land with the
    owner's words and questions, and leave BACKLOG.md; its owner-question list now holds none. H3's and U3e's README
    items landed. Reviewed in full: quotes match REGISTER.md's three U33 rows; the 2026-09-16 one-write cap keeps its
    words with the 2026-10-21 decision named beside it. Routed: H3's twin-record text in digital_twin/README.md to T4;
    HEAP_FRAGMENTATION_MEASUREMENTS.md:282 to U36 (the next unit holding it). D2d (D1's open steps, the 17 scans) runs.
    Owed in the U35 report, at the owner's question (2026-10-22): a wear assessment of the config write's extra
    littlefs commits (the sibling's create and the rename, per accepted changing write), against CLAUDE.md's wear rule.
85. **Wear of the write-then-rename** (lead, 2026-10-22, for the U35 report; the owner's question of 2026-10-22; read
    in the pinned lib/littlefs at v1.29.0). Before P4 a rewrite of an existing config file was `open(..., "w")`
    (O_TRUNC: no commit at open, lfs2.c:3146-3149) and one metadata commit at its close (lfs2_file_sync_, :3434).
    Now each write makes three: the sibling's create (:3125-3128, the sibling being absent after the last rename),
    its close, and the rename's one commit (:4062-4070, the old entry's delete in the same commit). Data blocks are
    unchanged: littlefs is copy-on-write, so a rewrite always took new blocks, and a file at most `inline_max` lives
    inside its commit either way. Each commit pads to `prog_size` (256 B, lfs2_dir_commitcrc(), :1670-1677), so a
    4,096-byte metadata block takes about 16 commits before its pair compacts (one sector erase): about one erase per
    5 config writes now, against one per 16. littlefs relocates a metadata pair every 100 erases (`block_cycles = 100`,
    extmod/vfs_lfsx.c:101), which spreads that wear over the filesystem's blocks. Writes stay rare: only an accepted
    PUT that changes a value (compare-before-write), the one boot repair and an absent file's defaults. So the cost is
    about 2 more page programs a write and about 3x the metadata-pair erases, against the W25Q16JV's 100,000 cycles per
    sector, spread by wear leveling: no device-visible wear at these rates. The persistence_write budget counts
    logical writes and is unchanged. Decision (agent, 2026-10-22): kept; whole-document safety is worth the cost, for
    the owner's review with P4's decision.
86. **Owner decision on the config write** (owner, 2026-10-22, 06:32 UTC: "For your records, your suggested next steps are
    fine (go back to the single write). Don't start working yet, I have more questions."; the steps: both write sites
    back to the pre-U35 single `with open()` write with its docs; the stall finding closed as an accepted degradation
    with its consequences (no reset, no loss; a late answer, a late read, one LED stutter, a DNS retry, on dev's bench
    link one failed and resynced transaction); the checklist gains: a flash or NVM write change is always the
    owner's question, and a fix that misses its premise or creates a new hazard stops for re-evaluation). The owner's
    findings, agreed by the lead: the sibling-and-rename scheme contradicts the rules (avoidable flash wear, not the
    conservative option), came from a runaway chain on a misread root cause (stacked datasheet maxima; a bench-only
    Ctrl-C), needed a question, and costs effort on a limited device. LEAD NOTES 85's wear assessment is void (owner:
    "No need to do wear assessment"). Work on it waits for the owner's go.
87. **Least wear becomes a central rule** (owner, 2026-10-22: "The least wear rule is even more important for the
    production code than for the tests, as it will run potentially for years. This is something to be added to our
    pillars, a completely central important rule. Document and integrate this, plan whatever action this requires to
    be enforced, but don't start coding yet."). Documented: CLAUDE.md's new hard rule and the audit's sharpened wear
    pillar (int `6dabd9b`, after D2c's merge `c2ba6c8`; citations, decision vocabulary and legacy paths pass, 24);
    CHECKLIST 24 and common_u35.md's Rules. Enforcement planned, nothing coded: `S/u35/lead/least_wear_plan.md` (E1 the
    single write back, E2 a pinned list of every production write site, E3 per-write flash-operation pins, E4 a
    read-only sweep of every write path, E5 the SPEC checklist), with three questions to the owner. Waits for the go.
88. **Owner answers on the least-wear plan** (owner, 2026-10-22, 07:17 UTC): question 1 (keep the boot write under the config
    lock): "1. is good."; question 3 (inside U35 or its own unit): "3. Inside U35, so it already gets into the first
    wave of real hardware runs"; question 2 (the guard's scope) asked back: "that guard is policy only, as far as I
    understand?", answered in session; "Still wait for my go ahead." Nothing started.
89. **Owner answer on the guard's scope** (owner, 2026-10-22, 07:21 UTC: "yes, it's about pattern enforcement only, and
    it's valid for both firmware and the test scripts, but with the gate variable applied in the tests, it is already
    well set up. So the rule applies for all and is already well implemented in the tests, no need to change. No go
    ahead yet."): the least-wear rule binds firmware and tests alike; the tests' marker gates already enforce it, so E2
    pins the firmware's write sites (`src/`, buildgen's templates, the generated modules) and nothing in the tests
    changes. Still no go-ahead.
90. (lead, 2026-10-22) Owner concern: the pillars (no awkward or inefficient patterns, fewest flash writes, a
    limited device, no runaways) were all broken by the config-write chain and the rules and safeguards missed it;
    "How can it be ensured that no similar incidents happened elsewhere". Measured: the audit changed src/ 13,218 ->
    16,675 lines; write sites 2 at base, 5 now (3 the sibling scheme, 1 the reset's remove from U11, unchecked
    against the rule). Proposed a retrospective: mechanical triage, independent fresh-agent review per area without
    our records, premise re-check, one short ranked page for the owner; plus prevention (define "conservative",
    the chain stop for all areas, a per-unit independent pillar review and a product-change digest). No go-ahead.
91. (lead, 2026-10-22) Owner: certainty that no other rare pillar-violating event happened, without dozens of
    candidates or re-reading every line, sparse on tokens. Proposed: three scripted marks (cost added over base,
    a chain of fixes reshaping one function, no owner mandate or a computed premise), calibrated on the config
    write first; only cost AND (chain OR no mandate) gets one fresh read-only agent; cap about 5, else tighten the
    filter. Lane history exists locally only for U10-U35 (345 branches); U1-U9 fall back to squashes and records.
    No go-ahead.
92. (lead, 2026-10-22) Owner go-ahead for the screening only ("Yes, go ahead with it, and prove your checks really
    find their targets."). S/screen/: inventory.py + compare.py (cost constructs, base 798e5a7 vs int 6dabd9b, src and
    generated modules), costpath.py (lane commits changing a module's cost per unit; COSTPATH_MODE=const for re-tuned
    values), mandate2.py (a unit's step whose Site names module and function). Proofs: inventory 9/9 planted
    positives, 0/5 negatives; chain synthetic repo 3/3 checks; mandate 4/4 positive and 2/2 negative controls; real
    control (config write) flagged by all three, the only cell over 2. Candidates left: UART-link hazard mode (U35),
    captive DNS per-datagram yield (U18), shutdown task and gate lock/event (U20); one fresh read-only reviewer.
    E1-E5 still not started.
93. (lead, 2026-10-22) Screening result (S/u35/handbacks/SCREEN_review_final.md; 35 calls, ~184k tokens). Lead
    spot-checks held: uart_comm `_err` persists every fault (err_s) and dev wires both link ends to FRAM, so the hazard
    mode's provoked faults land in the evidence logs; `_shutdown_task` is write-only in src/; the captive DNS int-addr
    `try` is pre-existing (base captive_dns.py:102-104). Outcome: one violation of the incident's kind (the config
    write, E1); one agent-decided pillar conflict (UART-link hazard mode: test machinery in the product, FRAM
    evidence) -> owner question; two simplifications (shutdown gate lock and park-cancel, captive DNS MemoryError
    handling) and two test-port branches in the product (captive DNS int addr, the exception-handler check) -> owner
    question on timing. No other flash or NVM write added. E4's write-site half is done by this; its per-trigger half
    stays with E3's pins.
94. (lead, 2026-10-22) Owner on question 1: is the "test code in a product" a pure part of the UART link module?
    Checked: yes. The hazard mode is wholly in src/asy_uart_link_driver.py (header: "Bench-only UART crossover-link
    exerciser"); asy_uart_comm.py carries none of it; only dev's generated module wires it (2 lines), the other five
    devices do not freeze the module. Requirement owner's (2026-10-21, "b - system shall be proven stable unter max
    load allover"), the mode the agent's. The reviewer's P4 label is withdrawn (the lead passed it on unweighed).
    Left: the website text "Bench-only; nothing is stored." omits the provoked faults' FRAM error entries (text fix);
    the two-at-once part is redundant on the device (keep, recommended). The screening's only pillar violation is now
    the config write.
95. (lead, 2026-10-22) Owner decision on the UART link module (after the screening's hazard-mode finding): "the
    link module is a necessity for testing, and it's testing code inside a module, but for a good reason, and the
    guard from being included in real deployed firmware is the fact that the module is never included in the config
    files for deployment boards. So this is a substantial exception from the usual scheme, but for good reasons."
    Hazard mode stays. Checked: buildgen validates a link's structure (one initiator, one responder, buses, timing)
    but nothing fails if a deployment board's TOML declares `driver = "uart_link"`; the guard is convention today.
    Proposed (not started): a tests_scripts pin allowing uart_link in dev.toml only, and the exception written into
    CLAUDE.md's UART bullet with the quote at U35's records. Still no go-ahead for E1-E5 or the cleanups.
96. (lead, 2026-10-22) Owner go-ahead: "This is fine, and the cleanups are fine as well, as long as their intended
    behavior and resilience are either unaffected or even improved. Be sure not to intruduce a regression. With this,
    you have my go-ahead." Blocks (briefs/blocks_zmo.md, base 6dabd9b, files outside lanes.py's base check): Z the
    single config write and the write pins; M the shutdown gate without its lock and a supervisor that returns; O the
    captive DNS Unix-port branch out of the product and the hazard text. Then J (write-site guard, uart_link dev-only
    pin, SCD30 write pins) on Z's merge, and D2e (SPEC A.4/C.7.3/F.3/J.6/Part N, Part D item, C.8 pointer, CLAUDE.md:
    the guard named, the UART link exception with the owner's words) after D2d, Z and J. Kept by lead decision under
    the owner's no-regression condition: the exception-handler guard (a firmware-wide contract with its own check and
    device scripts relying on it), `_shutdown_task` (read by tests in four files), and the captive DNS MemoryError
    re-raise (narrowing DNSQuery's handler would let one bad datagram pause the server 3 s). Freed 11 finished
    worktrees (11G free).
97. (lead, 2026-10-22) Owner: "I just want to be sure you are not breaking anything which is there for a good reason.
    So double check where it came from what it affects, what its intended function is. So if you found opportunities
    to improve with no risk is absolutely desirable, but no regressions, also no hidden ones." Sent to Z, M and O as a
    binding addendum (briefs/blocks_zmo.md, last section): a provenance table per change. At each merge the lead
    re-traces every row of that table in git before accepting it.
98. (lead, 2026-10-22) D2d was found stopped (last entry 06:02 UTC, no commit, worktree clean); its stop had not been
    recorded. Relaunched fresh from `6dabd9b` (fast-forward, rebuilt), with the config write-path sentences held for
    D2e. Load: Z, M, O, D2d (4, no lead gate or tier running).
99. (lead, 2026-10-22) Block M handed back with nothing committed (handbacks/M1_final.md); both parts stopped under the
    owner's no-regression condition, and the lead agrees after re-tracing in git. M.1: the lock and the tentative claim
    are the 2026-09-30 owner design's rule 3 (audit/actions/SUPP_owner_0930.md:46-60, origin 9735d02); the preflight
    does suspend in the product (`_report_chip_lost()` awaits err_s with `initialized` already False, so
    `get_write_protected()` awaits err_s too; asy_fram_driver.py:254-259, :342-348), and the lock-free form lets a
    mempause and another word in during it (the agent's scratch guard, bitten). M.2: the cancel is pinned
    (test_asy_system_service.py:2195) and stated by the same design ("parks and is proven stopped"; park 5eb81d0,
    cancel 9735d02, pinned 877c57d, shape 51c11aa): kept. Taken on: the scratch guard pins rule 3's yielding case,
    which no test pinned, so it joins block J as its own small test file (the 10 s file does not grow). Routed to U36
    (the next unit holding both files): in the chip-loss window `erase_ready()` answers True, since
    `get_write_protected()` answers "not protected" for an uninitialised driver; the erase then ends in code 9 at
    erase_chip's own re-check, so it is not silent.
100. (lead, 2026-10-22) D2d (`d1a60f7`, handbacks/D2d_final.md): steps 34, 37 (5), 111, 112, 126, 128, 143 (4) and 144
    landed; reviewed in full: the type-narrowing restatement matches the in-place comments (asy_uart_comm.py:575-1110,
    asy_fram_manager.py:475-628, asy_wifi_service.py:650), the unreachable-branch paragraph is M_SPEC's verbatim text,
    the DHCP tag mirrors tests_hardware/README.md's; no audit IDs. Merged into int as `efc50b9`; the orphaned J.7
    allow-list line dropped (`99bc22c`; vocabulary, citations, legacy paths 24/24). Step 142 (BACKLOG.md's owed-hardware
    rows for U35's new instruments) stopped on D2d's tool budget, not on a dependency: it is U35's, and joins D2e (the next docs
    block; it needs no measurement), which checks each instrument in tests_hardware/ before writing its row.
101. (lead, 2026-10-22) Z (`447ae0b`, handbacks/Z1_final.md) and O (`15da695`, O1_final.md) merged into int as
    `dfbf384` and `4bd27cc`. Re-traced in git: Z's write sites equal f3fff0e's three lines, moved into one sync
    `_write_file()` (ruff's statement ceiling; no await); its hunk table's six commits (934539c, b52f3b6, 8f2f15f,
    65f7454, 480d4cf, 8edb5aa) each touch the files it names, and every class-b hunk it kept is kept in the tree.
    Lead edits for the mechanism's leftovers outside Z's files (`b025371`): digital_twin/_flash_stall.py back to
    `IO[str]` and `len(data.encode())` (lane V's `len(data)` undercounted non-ASCII text), the concurrent-reader
    comment in test_bus_hazard_multi_device.py, the remove stand-in's `os.stat()` in test_asy_system_service.py. O:
    rp2's recvfrom returns (str, int) (extmod/modlwip.c:417-425, :1357-1364 at v1.29.0), the Unix port a raw sockaddr
    (ports/unix/modsocket.c:302-330); the guard came from a Unix-port run (7c16ed0); `ipv4_to_int()` returns None
    for any malformed str. O's new fact, a hazard run fills UART_resp's 10-entry FRAM log and so overwrites its older
    history: the website text now says so before the run is confirmed (`cd8f077`, lead, under O3's scope); D2e adds it
    to A.8 and the bench README. ruff and the three mypy passes clean (cold cache). J launched from `cd8f077`.
    Merge checks on `cd8f077` (u35/lead/m4/run.out): config manager, system service, multi-device hazard, captive DNS, twin machine and twin UART link, each at -1 and 32768: 12/12 rc 0, zero memory markers.
102. (lead, 2026-10-22) The container restarted at about 09:45 UTC with J mid-run (its paired SCD30 base/head run, pid 17805, cut short). Worktrees, toolchain and scratchpad survived; J's uncommitted work intact. J resumed from its transcript, told to close that RUNS.md line and re-run the pair from the start.
103. (lead, 2026-10-22) J (`20b84f9`, handbacks/J1_final.md) merged into int as `37a9558`. The write-site guard pins
    9 sites (the config file's one write and one remove; seven SCD30 NVM sends), none in the six devices' generated
    modules; the UART link guard keys on `[device] bench = true` (a quoted device name is refused by
    test_no_variant_literals.py); SCD30: n changed compared keys send n storing frames (n = 0..4), setup() and the
    whole boot start sequence send none (its frames pinned in order). The brief's "a PUT changing none sends none"
    was the lead's overreach: AmbPres and ForceCalRef are sent on every PUT and ContMeas=false always stops, each an
    owner decision already in SPEC A.4 (owner, 2026-09-26) and C.8's count; J pinned what the decisions say. The gate
    tests moved inline (`5b05a53`, lead decision): their own file imported the whole test module and remapped
    TmpScratch's key before the import; inline they are cheaper (paired -1 26.34/25.99 s, 32768 27.82/28.08 s) and
    still bite (lock-free gate: test 1; lock removed with the claim kept: test 2). J's class-3 note, the static scan
    cannot see an aliased `open` or a command through a local, stays a stated limit of the guard (D2e).
104. (lead, 2026-10-22) D2e (`bbf808d`, handbacks/D2e_final.md): carry items 1-5 and 7 landed, reviewed in full;
    the owner quotes match LEAD NOTES 86, 87 and 95 word for word (the UART exception quotes the answer from "the
    link module is a necessity" on). Lead edit `4f44af1`: D.3's least-wear item said "an unchanged value
    never written", which A.4's AmbPres/ForceCalRef and C.8's ContMeas=false contradict by the owner's 2026-09-26
    decisions; it now names them as the exception (docs checks 39/39). Step 142: two owed rows landed (the torn-write
    bench run, the lone BMP3xx under general calls); the rest of queue_c's list (the memory gates' silicon arm, the
    two-image GC proof, the read-stagger timestamps, the speed-probe bands, the interaction cells) has no instrument
    in tests_hardware/ yet, and queue_c.md is U37's: routed there. D2e merges into int after the re-record.

LEAD NOTES 105 (lead, 2026-10-22, 12:45 UTC). W6 gate (S/u35/gate1 on 069b9fe) ended 12:44: phase A green at both stages (5796 tests, 115 files, 0 retries, 0 markers; tests_scripts 6809/6806, the 3 html-validate skips at 32768 as in every gate); 30 more unit skips than U34 = 6 new twin-integration tests each run on one device, all 6 pass; npm green; twins wozi, grkizi, arzi, schlafzi green. Three reds, each once, evidence in S/u35/gate1/evidence/: (1) klkizi GC -1 reset_errors_while_the_escalation_logs_is_refused_and_clears_nothing (entry write past the 1200 ms escalation bound under host load, hypothesis) -> G1a; (2) dev GC 32768 uart_ring_under_concurrent_load (a load thread TimeoutError) -> G1b; (3) coverage: test_sensortask[dev] ring-saturation scenario MemoryError 262145 bytes at tests/_sensortask_scenarios.py:2195 under build-settrace (a 256 KiB FRAM-image copy, lane V's new scenario) -> G1c. Brief S/u35/briefs/blocks_g1.md. After their merge: the twin legs and the coverage leg re-run on the merged head before W7.

LEAD NOTES 106 (lead, 2026-10-22, 13:18 UTC). G1a accepted and fast-forwarded into int (02e3be8): the escalation scenario's knob held its entry on the firmware's own 1200 ms bound (72b1281 added the bound after 06a8ae5's scenario), so host pace chose the path; the bound now starts at the release and the scenario holds past it on every host (reviewed: the asyncio proxy passes every other name through; the window it widens is the same reachable state). Carried: (a) to T4a, a twin scenario of the escalation's timeout path (entry held past its bound and never released: ResetReason 20, the relaunch's BUSY block healed and logged), deterministic, with a knob mode that counts the hold; (b) the hold's feed-gap residual (about 3.3 s of host time inside the 6000 ms check) to the records. G1b: firmware finding, no commit: a refused connection's close waits on its FRAM trace with no bound (asy_webserver_service.py:920-925, 799-802), past the scenario's 10 s client timeout under FRAM-log writes and flash holds. Decided on the owner's behalf (lead, conservative, reversible, for the owner's review): G1b's p1 shape, the trace held at most one per-call timeout, its entry kept in RAM for the next write, trace-before-close kept as the pacing it is; G2 implements it test first, with the FRAM chunk-write cancellation-safety proof (already reachable through the escalation bound and the outer cap), the escalation message's wording (asy_system_service.py:580) and the scenario timeout check. Brief S/u35/briefs/blocks_g1.md G2.

LEAD NOTES 107 (lead, 2026-10-22, 13:24 UTC). After the report of the G2 decision and the parameter question ("UART ring: are the 5 seconds hardcoded or set as a defaulted parameter (the preferred option) and ideally set at one common place?"; answer: the existing ServingLimits.per_call_timeout_s, default _DEFAULT_PER_CALL_TIMEOUT_S, one tunable), the owner asked: "So with this, you can continue and fix the issues cleanly?" No objection to the decision; it stays the lead's decision on the owner's behalf (decision rule 2: an agent recommendation stays the agent's even when accepted). G2 told to reuse the parameter, no new constant or literal.

LEAD NOTES 108 (lead, 2026-10-22, 13:31 UTC). Owner decision on the order after U35 (the open question of task #85, "which order and at what time to start the parallel hardware session and the doc works"): "Looking at the remaining percentages, I will start the hardware session once U35 is done and defer U36. So close U35 cleanly, but don't put additional effort into the preparation of U36 unless I give you the go." For the lead: U35's close is unchanged in scope and rigor; a finding routed to U36 is recorded with its route only (no brief, no packet, no plan work); the hardware session starts on the owner's own go-ahead in this conversation, not before (CLAUDE.md's hardware rule).

LEAD NOTES 109 (lead, 2026-10-22, 13:35 UTC). G1c accepted and cherry-picked into int (a81a65a): the coverage MemoryError was the rebuild's one 262,145-byte copy of the 256 KiB chip image under settrace's scattered survivors (37.5 KB largest free run; reproduced alone, so not order); the fix copies the image in 4 KiB pieces and places them back (rotation and shift there), with a size assert; three new sites plus four latent ones since 2977c4e. Reviewed: rotation (-3, wrap) and shift (at=shift, blank head) match the old transforms; no copy over 4 KiB. Proof in S/u35/handbacks/G1c_final.md (105/105 x 6 devices at settrace, -1, 32768; paired times no growth). Waiting on G2; then the full gate on the merged head.

LEAD NOTES 110 (lead, 2026-10-22, 13:53 UTC). G2 reviewed (43d1a6b on audit/u35-g1b, not yet merged): the refusal bound on self._per_call_timeout_ms (no new number), test first (:633 failed on 069b9fe); the escalation message now "its entry write did not finish within N ms and was cancelled"; the UART load threads' client timeout derived from src (_OUTER_CAP_S + _FLASH_HOLD_MAX_MS), the device's owed bound for an admitted request. G2's cancel sweep (every await of a chunk write) found CS, locks and RAM entries safe, and one firmware defect: asy_fram_manager.py _write() writes block 0 then block 1 whatever their state, so a cut leaving block 1 BUSY then a cut inside block 0 leaves both BUSY and setup() overwrites the history (196/784 cut pairs lose it on 069b9fe). CHECKLIST 24: FRAM is not wear, so not the owner's question. Decided on the owner's behalf (lead, conservative, for review): the write-order fix (the non-IDLE block first; FRAM status reads only) lands in U35 with the refusal bound, which adds a cancel source to that path; and the bound covers every trace _serve() awaits before its close (refusal, bad head, peer reset, the three reclaim arms), one helper, as G2's firmware question asked. G3 does both test first, the fram_manager test's +12/+15 % growth (LEAD NOTES 4), and G2's open proofs. Brief G3 in S/u35/briefs/blocks_g1.md.

LEAD NOTES 111 (lead, 2026-10-22, 13:56 UTC). Owner, on the report of the two decisions in LEAD NOTES 106 and 110 (the refusal trace bounded at one per-call timeout through the existing parameter, every pre-close trace in _serve() under the same bound, and the FRAM chunk's write order fixed in U35, non-IDLE block first): "Solutions you proposed agreed." Recorded in the docs and commit messages as the agent's decision, accepted by the owner with that quote (decision rule 2), not as an owner decision.

LEAD NOTES 112 (lead, 2026-10-22, 15:23 UTC). REC1 (`befa1aa` on audit/u35-rec, from a81a65a; handbacks/REC1_final.md; 71 calls) accepted for its part: 70 double-quoted strings checked against the plan, the hand-backs, the base records, CLAUDE.md and CHECKLIST.md, every owner quote verbatim (the rest are spans between quotes, not quotes). Evidence restored: lane G's own G2 hand-back (`7d7c594`) had been overwritten by the gate block G2's under the same name; recovered from its transcript into handbacks/G2lane_final.md (the gate block's stays G2_final.md); REC2 corrects the record's line saying it is gone. Carried to REC2: the 21 blocks without a harness line (counted from their transcripts), steps 75, 78, 91, 92 and 98 re-checked against their texts on the final head (landed at the base, no lane checked them), OF-71/149/150/188 after B2 and T4, line numbers on the final head, assemble.sh run and evidence_README.md. For the owner report (CHECKLIST 24, REC1's list): Z's sync `_write_file()` holding the single write (LEAD NOTES 101), H2's `_PREREQUISITE_DEVICE_SCRIPTS` row (`50e22ab`, LEAD NOTES 53), D.3's SCD30 exception text (`4f44af1`), J's SCD30 send pins (103), the hazard command's dispatch-only form (12): each listed for the owner's review, none presented as decided. OF-260 (H3's class-4 thread deaths that leave only PytestUnhandledThreadExceptionWarning; LEAD NOTES 58's W6 item to weigh, not taken up): taken into U35 (lead decision, conservative: it strengthens a check, one config line, reversible; the owner's "I just want to make sure no evidence to a bug, be it in the firmware or the tests, is silently lost."). Pinned pytest 9.1.1 raises the warning when it is an error (_pytest/threadexception.py:58-67). G2+G3 change src/asy_fram_manager.py, asy_system_service.py and asy_webserver_service.py, which 27 device scripts import (by text match), so the twin record's hashes go stale and it is re-recorded on the merged head before gate 2 anyway; block H4 does both: tests_hardware/conftest.py turns the warning into an error, seen biting on a planted dying thread through the twin first, then the re-record at both stages; a death it unmasks gets no reason until root-caused.

LEAD NOTES 113 (lead, 2026-10-22, 15:37 UTC). G3 (`c2a81a6` on audit/u35-g1b over G2's 43d1a6b; handbacks/G3_final.md; 143 calls, past the valve) reviewed and accepted. Write order: `_write_chunk(buf, -1)` reads block 1's status pair (one 2-byte READ into the preallocated `_pair_buf`) inside the first block's own session and takes block 0 first only when both bytes read IDLE; a failed read logs FRAM_STATUS_READ and takes block 1 first (agent's, kept: with the bus failing, the next command's guard fails before a byte is sent); `self._first` carries the pick to `_write()` under the write lock. Seen failing on the old order; the two-cut sweep with one geometry: 196/784 lost on 069b9fe, 0/784 fixed (G2's script mixed a 10-slot store with 3-slot relaunches and read 784/784 both ways). Allocation: blank setup 29,728 -> 29,888 B (30,000 budget; G2's separate session read 31,296). Wire trace +1 CS cycle per chunk write, no cycle removed (SPEC's "every CS cycle stays", owner 2026-09-18); status cells 3 operations per write. The link the owner was not told on 13:56: SPEC's FRAM text records the both-copies-marked history loss as accepted (owner, 2026-09-11; confirmed 2026-09-26: "no recovery scheme is wanted for a reboot that catches the chip mid-operation"; the invariant is all-or-nothing). The write-order fix is no recovery scheme: it removes the write path's way into that state and leaves the read path's (a read marks its copy busy, "don't fix it", owner 2026-09-10), so the accepted loss stays possible, rarer; the owner's acceptance, its actor and scope stay as written. Reported to the owner now; the most recent owner decision (13:56, "Solutions you proposed agreed.") stands unless the owner says otherwise. G3's open finding (a cut read with block 0 already busy leaves both busy) is that owner-confirmed read lock, not a new defect: no row. Traces: `_trace_before_close()` bounds the refusal, bad head, peer reset and the three reclaim arms (bad head and socket error seen failing on 43d1a6b). The task top's "Connection task failed:" stays a direct err_s (lead decision, conservative: it is reached only when the count, a proxy, a release or a trace itself raised, effectively an exhausted heap, where wait_for_ms's extra task is one more allocation; tests_scripts/test_task_tops.py pins a direct err_s at every task top, a firmware-wide contract): the one pre-close trace left unbounded, to be stated in SPEC A.8 and the owner report. Test time: the fram_manager file 6.31/7.63 -> 1.17/2.26 s (the Unix port's CS-settle sleep_us(2) cost about 250 us per session; a module swap in the test file, the settle pinned by test_asy_spi_driver.py). Proofs on e62b601/c2a81a6: sensortask 6 devices x 2 stages, 33 readers x 2 stages, settrace three files, twin integration, uart_ring 3/3 per stage beside 4 burners, the webserver concurrency family 20/20 per stage; the 4x plant passed but the twin's log level cannot show refusals were hit (the unit test at :633 carries the mechanism); tests_scripts tier not re-run clean after G3's own frozen-module removal (gate 2 runs it). D3 lines: SPEC 183-191, 207, 212-214 (the 1-in-8 rate, from 399c027's twin run 5b, measured on the old order), 8258-8262, 6588, 11773, plus G2's 12216 and 9785.

LEAD NOTES 114 (lead, 2026-10-22, 15:43 UTC). Correction to LEAD NOTES 113 and to the lead's report: the read's busy mark was given as a decision without its reason. The reason (SPEC :192-198, the MB85RS64V datasheet's endurance note): FRAM reads are destructive, every read is internally a read-then-restore, so a power loss mid-read can tear the copy as a write can; the mark is what lets the next boot refuse a copy whose restore was cut. The loss that remains is therefore inherent, not a missing fix: when one copy is already marked, the whole copy must be read to be used, and that read is itself an operation a cut can tear. No ordering can remove it. The owner pointed this out (owner, 2026-10-22: "you also should have found why. I already explained several times that FRAM reads are destructive."). D3g told to keep the reason beside the mechanism sentence; the squash message and the owner report carry it.

LEAD NOTES 115 (lead, 2026-10-22, 15:49 UTC). Owner decision on the connection task's last-resort error trace ("Connection task failed:", asy_webserver_service.py `_serve()`'s outer catch), asked whether it stays a direct, unbounded err_s or takes the 5 s per-call bound like the six other traces before the close: after the explanation (reached in practice only on an exhausted heap; the bound's wrapper is one more allocation there; test_task_tops.py's direct-err_s contract; the cost, a connection open longer and holding its slot while the device is in trouble, closed for sure by the finally), the owner asked "In practice, not within the test, the worst thing it may cause is a (real network) connection which stays open a bit longer if the device itself is in real trouble,, but closes for sure at some moment?", answered yes (the finally closes on success, failure or cancel; the log path waits only on locks whose holders do bounded SPI work; a refused new client meanwhile), and decided: "Fine, keep it." Recorded as the owner's decision with that quote and question (the proposal was the lead's). D3g told to tag it so in SPEC A.8.

LEAD NOTES 116 (lead, 2026-10-22, 15:55 UTC). Timestamps of LEAD NOTES 112-115 corrected to their real write times from the session transcript (15:23, 15:37, 15:43, 15:49; the lead had written them without reading the clock). D3g (`dcf8ff1`, handbacks/D3g_final.md, 73 calls) accepted and fast-forwarded into int: A.4's write order and status-cell counts, the read's busy mark with its destructive-read reason (LEAD NOTES 114), A.8's bounded traces with the owner's "Fine, keep it." on the last-resort trace, H.7, F.2's wait inventory, F.3 and Part N rows, J.7; its one deviation kept (a cut repair write cannot leave both copies marked: the repair follows a whole read of the other copy, which ends IDLE, asy_fram_manager.py:239-254, :318). The 1-in-8 sentence stays at SPECIFICATION.md:229 for B2c and D3. Of D3g's two finds outside its files: (1) the UART load's client timeout left out a request reclaimed at its outer cap (cap, then a reclaim trace of up to one per-call timeout, each timer late by up to one flash hold): fixed by the lead before gate 2 (`85caca5`: outer cap + per-call timeout + 2 flash holds, read from src/; J.7 and four Part N rows; 148 readers green, host mypy clean), and T4a carries its plant proof (a reclaimed request near both bounds, red on the old timeout); (2) src/asy_webserver_service.py:951's comment says no arm "persisted" the entry where "traced" is now exact: not changed, since any src edit stales the twin record H4 is re-recording, and the meaning holds (a cut entry persists at the logger's next write); REC2 rows it to the next unit holding the file, route only if that is U36.

LEAD NOTES 117 (lead, 2026-10-22, 16:13 UTC). Usage at 89% (owner's figure); the lead's estimate for the rest of U35 6-7%, 8-9% with one root-cause round. Asked whether to keep B2's two measurement-only items (the tests_scripts shard trial for the coverage leg; the local OF-150/OF-71 times) in U35 or move them to U37, with the lead's proposed savings (T4a and T4b as one block, D3 folded into REC2): owner, 2026-10-22: "Don't change too much, keep going." Taken as (paraphrase): the plan stays as briefed: both measurements stay in B2, T4a/T4b and D3 stay separate blocks; the lead still does items of a few calls itself.

LEAD NOTES 118 (lead, 2026-10-22, 18:18 UTC). Gate 2 (S/u35/gate2 on 7851668, 16:25-18:16) green on every leg, read line by line with S/gate_read.sh and against gate 1: phase A rc=0 at both stages (85/85 files, 0 failed, 0 retries; tests_scripts 6809 passed 6 skipped at -1, 6806/9 at 32768, the 3 extra skips html-validate absent in wt-u7g as in gate 1; the only memory-marker lines are passing injection-test names); twins rc=0 on all six (wozi 118, dev 124, arzi 120, grkizi/klkizi/schlafzi 118 PASSED, 0 FAILED; every clean-shutdown and marker check OK at both thresholds, counts equal to gate 1's, marker-line shapes identical; gate 1's dev and klkizi reds now pass); npm 1691 passed 6 skipped, coverage 1339, the five statics rc=0; coverage leg Result: PASS, 82 files, 0 markers (gate 1's three gone, G1c), src 10557 stmts 1139 missed 89%, 963 s against gate 1's 1078 s. W7 B2 starts on 7851668.
