P1b record, U35 steps 46-110 (agent, 2026-10-21). Tree: S/wt-u33plan at 1dd6dd5; tests/test_asy_neopixel_driver.py read as 970b63b. All 65 steps were located; ~68 tool calls. Paths are repo-relative. "nsd" = notification service test, tests/test_asy_notification_service.py.

## 1. STEP TABLE

| # | M.ID | file(s) edited (current names) | verdict and evidence |
|---|---|---|---|
| 46 | TEST_UNIT.088 | tests/test_asy_notification_service.py | **part landed.** Landed: :988 renamed tuple-order test; fold (1) `test_the_sample_reports_why…` :1566; fold (2) :658. **Left (driven time):** `_one_cycle()` :162-170 still does `await asyncio.sleep(wait)` with the 3-line "real wall-clock time" comment; waits 3.5/1.2 s at :941,:959,:981,:1001; `test_flashes_run_strictly…` still sleeps 0.05/1.3 s at :1021,:1024 |
| 47 | TEST_UNIT.089 | nsd | **part landed.** Landed: `_in_window` table :1088; 23:30 cycle :1103; clock-step test :1128; CALLBACK :1184; `"FlashDur": 0.01` gone. **Left:** the gating tests still use `_one_cycle`'s real 0.1 s default (:1053,:1082,:1143,:1162,:1179,:1197) |
| 48 | TEST_UNIT.090 | nsd | **part landed.** Landed: `src_int(...,"_MAX_OVERRIDE_TIME")` :1280; `_OVERRIDE_SECS` tagged :37-38. **Left:** real sleeps 0.05/1.1/0.05 at :1216,:1220,:1224 and :1252,:1254,:1260. **Tag removal:** `# @tunable l1.asy_notification_service_override_bound_ms = 3200` :40-41 and its Part N row (3 SPEC hits) are withdrawn with the literal |
| 49 | TEST_UNIT.092 | nsd | **part landed.** Landed: `test_no_signals…` :1358; one CALLBACK slot :1395; the pre-finalize test is gone. **Left:** real `sleep(0.1)` :1366; the cb-raising cycle still real |
| 50 | TEST_UNIT.103 | tests/test_asy_ntp_client.py | **landed**: `_FakeUDPSocket` :1266; forwards test :1306; NTP_NOT_SENT :1337; SOCKET_TEARDOWN :1344; cancelled fetch :1356; `ready.wait()` :1399; 48-byte reply :1407; ipoll comment :375; tags :93-:108; invalid-addr tests gone |
| 51 | TEST_UNIT.037 | tests/test_asy_fram_driver.py | **landed**: event gate :1557-1572; limit comment :1608; typed `capture` :1694 (no noqa); codes :1713 |
| 52 | TEST_UNIT.076 | tests/test_asy_isl29125_driver.py | **part landed.** Landed: `_gather` typed :4024; comment cut :4062-4063; new tests :4088,:4118,:4143. **Left:** :4046 `await asyncio.sleep(0)  # let the reader get partway…` becomes an Event gate; :4075 comment becomes "# one yield lets configure() park on the held lock (a limit, not an interleaving claim)" |
| 53 | TEST_UNIT.078 | tests/test_asy_neopixel_driver.py (970b63b) | **part landed.** Most scenarios already run under the file-local `_DrivenClock` (:92-105, the shared `_fake_time.DrivenTime` plus `_YieldOnlyAsyncio` :61-89). **Left:** 15 real sleeps at :396,:429,:445,:466,:479,:497,:512,:643,:661,:664,:666,:1024,:1061,:1084,:1099; the :1183 comment becomes "a limit"; `cancel_all` is used where the packet says `cancel(*tasks)`. **Conflicts** (stale packet text): it drops `debug`, but `_event_driver()` passes `debug=4` (:55); it writes `_neopixel_freq`, but the product attribute is `neopixel_freq` (src/asy_neopixel_driver.py:83) |
| 54 | TEST_UNIT.106 | tests/test_asy_ntp_client.py | **landed**: `_refresh_loop` tests :1741-1831; `_FIRED_PROBE_S` :95-96,:1780; `_ASYNC_INTERVALS` :88-89; stale :1852; inverted :1870; age restart :1899; due counter :1923 |
| 55 | TEST_UNIT.110 | tests/test_asy_ntp_client.py | **part landed.** Landed: :2526,:2602,:2624,:2639. **Left:** `test_the_sync_task_survives_a_cancel_at_every_await`; it needs tests/_cancel_sweep.py, which is absent |
| 56 | TEST_UNIT.111 | tests/test_asy_ntp_client.py | **part landed.** Landed: redirect :2719; shared server :311-314; tags :97-115. **Left:** `await asyncio.wait_for(…, 5)` at :2723,:2775,:2813,:2827 becomes `assert await server.serve_once(reply) is True`. Lands after step 57 |
| 57 | TEST_HELP.058 | tests/_ntp_frames.py | **part landed.** Landed: shared builder :14-16. **Left:** `async def serve_once(self, reply: "bytes | None") -> None:` (:36) gets the bool return: `return True` after answering (:47), `return False` once the budget runs out. The constructor is `FakeNtpServer(port, *, poll_ms, poll_tries)` (:22): the caller owns the budget |
| 58 | TEST_UNIT.124 | tests/test_asy_scd30_driver.py | **part landed.** Landed: wire names :2291-2293; `_gather` :2285. **Left:** :2340 `await asyncio.sleep(0)  # let the reader get partway…` becomes an Event gate |
| 59 | TEST_UNIT.166 | tests/test_asy_uart_comm.py | **part landed.** Landed: `session_lock` :3094,:3111. **Left:** write the sweep test. UART: test only; no emitted byte, accept/reject rule or recovery timing changes |
| 60 | TEST_UNIT.171 | tests/test_asy_uart_driver.py | **to write.** :988-990 `await asyncio.sleep_ms(400)` becomes an un-set Event, with cancel in `finally`; add the one comment line. `_SHORT_CANCEL_ACK_MS` is already tagged (:52-53). UART: test only, no wire/rule/timing change |
| 61 | TEST_UNIT.177 | tests/test_asy_uart_driver.py | **to write** (new sweep). UART: test only |
| 62 | TEST_UNIT.184 | tests/test_asy_uart_link_driver.py | **to write** (new sweep). UART: test only |
| 63 | TEST_UNIT.187 | tests/test_asy_udp_socket.py | **landed**: `_FIRST_ATTEMPT_S` tag kept :84-85; no `wait_time_ms`; withdrawn IDs absent from file and SPEC |
| 64 | TEST_UNIT.190 | tests/test_asy_udp_socket.py | **part landed.** Landed: disconnect test :1594-1617. **Left:** the join test :1631 `await asyncio.sleep(_FIRST_ATTEMPT_S)` moves to driven time with `run_until` then `advance(500)`. That needs an asyncio shim, which the tree's DrivenTime lacks (§4) |
| 65 | TEST_UNIT.193 | tests/test_asy_udp_socket.py | **to write** (new sweep) |
| 66 | TEST_UNIT.208 | **moved:** tests/test_asy_webserver_connections.py | **landed (U19 form)**: :968 (file-local `_DrivenClock`); :1038; `_EagainWriter` :206. **U35 part, open:** swap in the shared driven clock. It depends on the §4 DrivenTime decision; until then **check-only** |
| 67 | TEST_UNIT.209 | the webserver tests | **to write** (sweep over `_serve()`). File choice (agent, 2026-10-21): use test_asy_webserver_connections.py, which holds `_serve()`'s reader/writer doubles. A.U35.48 names test_asy_webserver_service.py |
| 68 | TEST_UNIT.214 | tests/test_asy_wifi_service.py | **landed**: `_release_wifi_lock` gone; :1684-1687; :1775; :2469; parks stated as "a park" (:861,:1380,:1417,:1421) |
| 69 | TEST_UNIT.219 | tests/test_asy_wifi_service.py | **landed**: power-cycle comment :3152; QTYPE comment :3960; one status call :4668. The shared-WLAN assertions are **check-only** |
| 70 | TEST_UNIT.220 | tests/test_asy_wifi_service.py | **landed**: `PortAllocator` :3950-3953; ordered proof :3977; `# ----` dividers; `_CONNECT_BOUND_S` :66; `_FLASH_CANCEL_BOUND_S` :82 |
| 71 | TEST_UNIT.221 | tests/test_asy_wifi_service.py | **to write** (sweep) |
| 72 | TEST_UNIT.226 | tests/test_asy_base_classes.py | **landed**: `logger=` tests gone; one log path src/asy_base_classes.py:412; tests :1015,:1695 |
| 73 | TEST_UNIT.234 | tests/test_bus_hazard_multi_device.py, tests/_bus_hazard_catalog.py | **part landed.** Landed: chip-id loop :83-88; fold (1) through catalog :293-296,:336. **Left:** `switches >= 2` at :131,:174 becomes `sibling_inside_window`. That helper is absent from the catalog (M.TEST_HELP.027) |
| 74 | TEST_UNIT.235 | tests/test_bus_hazard_multi_device.py | **part landed.** Landed: L3 script; tests_hardware/flash/test_bus_concurrency.py:267; twin_record.json:182. **Left:** delete `:219 assert all(entry[1] != _BMP_ADDR …)` with its comment, and the test at :248-~290. **Hardware:** R1 H29 |
| 75 | TEST_UNIT.127 | tests/test_asy_sgp40_driver.py | **landed**: :297, :309-326, :329-338 |
| 76 | TEST_UNIT.236 | tests/test_bus_hazard_multi_device.py, tests/_bus_hazard_catalog.py | **part landed.** Landed: datasheet oracle :640-659; fold (1) :337,:364. **Left:** :291 test gets `wait_for(…,_ISOLATION_BOUND_S)` plus `bus_lock` asserts (**adds tag** `l1.bus_fault_isolation_bound_s = 5` and its Part N row); :689-691 reserved-address test still loops the hand-kept :64-67, and needs adapters' `default_address` (none on `I2CHazardAdapter` :158) |
| 77 | TEST_UNIT.237 | tests/test_bus_hazard_multi_device.py | **to write**: :699-750 and :753-786 are still SPIDevice/sync-worker forms; no `FRAM_SPI` used |
| 78 | TEST_UNIT.152 | tests/test_asy_spi_driver.py | **landed**: :773-796 |
| 79 | TEST_UNIT.248 | tests/test_asy_captive_dns.py | **to write** (sweep; `_FakeUDPS` :408) |
| 80 | TEST_UNIT.255 | tests/test_asy_config_manager.py | **landed**: :1633, :1641. The CONTRACT counts at the other sites are **check-only** |
| 81 | TEST_UNIT.257 | tests/test_asy_config_manager.py | **landed**: `dumps` :2419; :2471,:2814,:2881,:2899,:2912,:2937; fold (1) :2952. **Conflicts**, see §4: the non-dict test :1981 |
| 82 | SRC_CORE.043 | src/asy_config_manager.py | **landed**: :325 `absent_at_boot`; :326 `unpersisted`; :527-528 dir fault; :530 `except (MemoryError, OSError)` (no TypeError); :534-535; :580; :584-589. OF-225 joins here |
| 83 | TEST_UNIT.254 | tests/test_asy_config_manager.py | **landed**: :2488, :2538, :952 |
| 84 | TEST_UNIT.260 | tests/test_asy_crc_checks.py | **landed**: imports :6,:8; `_crc(...,0x31)` :34,:40; :781,:788 |
| 85 | TEST_UNIT.262 | tests/test_asy_crc_checks.py | **part landed.** Landed: :206. **Left:** add `base.length() == 0` to :394-397, and the new pure-pass-through test. Both fail until M.SRC_CORE.131 lands: today `CRCBase(1,0x1FF,">B")` keeps `_num_bytes` 1 (src/asy_crc_checks.py:22, `length()` :155-158) |
| 86 | TEST_UNIT.274 | tests/test_neopixel_wifi_integration.py | **landed in a yield-bounded form**: `_run_until` :45-52; scenario :57-80, no sleeps; `set_ext_led` test gone. The packet's DrivenTime form and the `setup()` calls are not written; that waits on the §4 decision. **Check-only** |
| 87 | TEST_UNIT.276 | tests/test_notification_neopixel_integration.py | **part landed.** Construction landed: :61,:78-80,:119,:136-139. **Left:** real `sleep(1.3)` :125 and `sleep(2.5)` :146 |
| 88 | TEST_UNIT.278 | tests/test_notification_scd30_integration.py | **part landed.** Landed: `reset_id`, `UTCValid`, `inject_fault` :180,:214. **Left:** :135, :164, :190 (0.2 s), :242 |
| 89 | TEST_UNIT.281 | tests/test_notification_sgp40_integration.py | **part landed.** **Left:** :146, :175 (0.2 s), :218 |
| 90 | TEST_UNIT.280 | tests/test_notification_scd30_sgp40_integration.py | **part landed.** **Left:** :199 (2.6 s), :238 |
| 91 | TEST_UNIT.283 | tests/test_ntp_fram_system_integration.py | **landed**: :197-201, :226, :252, :280, :447 |
| 92 | TEST_UNIT.284 | tests/test_ntp_fram_system_integration.py | **landed**: tick with clock :310,:327,:352; :393-396; :510,:525; ValueRef :545-546 |
| 93 | TEST_UNIT.290 | tests/test_asy_print_log.py | **landed**: :295-297, :318, :238, :363, :429/:433, :546/:562, :810, :1335. One case was not located by name: "pre-setup entries kept after the stored ones" (store merge). :242 covers RAM slots only; reading the store section :827-900 settles it |
| 94 | TEST_UNIT.303 | tests/test_asy_system_service.py | **landed**: :303, :318, :431, :467, :496, :545, :569. The clock is the shared `_fake_time.DrivenTime` (:121-123); a U35 swap only if §4 changes the class. **Check-only** |
| 95 | TEST_UNIT.304 | tests/test_asy_system_service.py | **landed**: :604, :612, :620, :648, :672 |
| 96 | TEST_UNIT.309 | tests/test_asy_system_service.py | **landed**: :2722; :2951,:2982 (22 dead),:3065,:3088; :3154; :3205,:3225; :2894; :2109,:2216,:2320; :4097-4270; `_RUN_BOUND_S` :69 |
| 97 | TEST_UNIT.339 | tests/test_driven_time.py (new) | **to write.** Neither file exists. tests/test_shared_helpers.py:168-300 already self-tests `_fake_time.DrivenTime` (§4) |
| 98 | TSC.175 | tests_scripts/_devices.py | **landed**: :1-3, `bench_device` :25, `devices_with` :42 |
| 99 | TWIN.132 | tests/test_digital_twin_network_neopixel.py | **part landed.** Landed: tags :29-32; singletons :223-238; power_dip fake case :499-507; downed AP :416; chip-down :448. **Left:** negative windows `sleep(1.0)` :197,:379 become structural; the A.U22.01 test (U25 stage, absent); fold (1)'s driver case, which is absent at L1 too (`power_dip` appears only at :504) |
| 100 | TWIN.158 | tests/test_digital_twin_uart_link.py | **landed, except U35's piece:** :568-581 still runs only `uart_get(0x01)`. Add the 140-byte `uart_set(0x02, …)` asserted True while the noise tasks run. UART: test only, public API, no wire change. OF-223 site |
| 101 | HW_DEV.060 | tests_hardware/flash/test_fram_storage.py | **landed**: :1-2, :19-31, :95-104, :179. A.U35.22's part is **check-only** (:96 stays the N.28 proof). Hardware R1 H22/H72 are not in U35's rounds |
| 102 | PROC.022 + SCR.024 | audit/b3/* (new); scripts/lint.sh | **PROC.022 to write**: audit/b3 is absent. Hardware parks: H43 (R1 end, the memory-gate silicon arm), H71 (R1, silicon cells), H56 (R0, speed bands). **SCR.024 landed**: lint.sh:1-25, :99 (U35 runs it: check-only). A.U35.09/.28 scenarios are absent from the tree |
| 103 | HW_BENCH.002 | **moved:** tests_hardware/markers.py | **landed** :11-25, registered at conftest.py:97; A.U35.51 part **check-only** (conformance.md) |
| 104 | PROC.025 | audit/b3/raising.md | **to write** (procedure). The module names are right; `src/math_helpers.py` keeps its name |
| 105 | PROC.028 | Part N rows and tags | **to write.** 918 of 937 `l0`-`l4` rows read "estimated" (grep). l3/l4 rows: **hardware** H55 (R1, R4, R5) |
| 106 | SCR.006 | scripts/_run_lower_levels.sh | **landed** :1-46 (npm leg :46). **Check-only** |
| 107 | SCR.042 | scripts/test.sh | **part landed.** Landed: `_check_heavy_list` :674-683; 10-entry list :661-672; L0 test test_test_sh.py:1999. **Left:** re-order from timing.md |
| 108 | PROC.024 | scratch, audit/sweeps/ticks30_build.sh | **to write** (procedure). OF-32 joins |
| 109 | SCR.060 | scripts/_digital_twin_ci_suite.py | **landed** :919-934; **check-only** (run at both stages) |
| 110 | SPEC.018 | SPECIFICATION.md A.5 (:489-535) | **landed** (pin v2.7.0, checklist, ladder, rebind, HTTPDropped, `_StaticRoutes`); **check-only** for A.U35.36 |

**Tunable tags.** Removed: step 48 (`override_bound_ms`). Added: step 76 (`bus_fault_isolation_bound_s`), which step 77 reuses. Step 105 changes values and basis only. None at steps 53, 60, 99 (their rows are already gone). Step 56 removes nothing: `l1.asy_ntp_client_serve_wait_s` lives on in test_ntp_fram_system_integration.py:65 and test_ntp_wifi_dns_integration.py:67, so its row stays. Check at execution whether driven waits drop `l1.notification_neopixel_wait_until_timeout_ms` (tests/test_notification_neopixel_integration.py:87).

**error_catalog.json:** no step in this range adds or removes a row.

**Twin-record input:** none new; step 74's entry already exists.

**UART:** no step in 46-110 edits src/asy_uart_comm.py, src/asy_uart_link_driver.py or UART_C_PORT_CHANGELOG.md. Steps 59-62 and 100 are tests only: no emitted byte, no accept/reject rule, no timing change. A changelog Class B entry appears only if a sweep finds a defect (A.U35.48 Blast).

## 2. CARRIED ACTIONS → STEPS
- A.U35.13 → 46, 47, 48, 49, 53, 87, 88, 89, 90
- A.U35.12 → 50, 51, 52, 53, 54, 58, 68, 69, 91, 92, 95, 96
- A.U35.48 → 55, 59, 61, 62, 65, 67, 71, 79
- A.U35.15 → 56, 57 (confirmation runs at 102)
- A.U35.14 → 60, 63, 64, 70, 99
- One step each: A.U35.45 → 72; A.U35.16 → 73; A.U35.21 → 74; A.U35.17 → 74, 75; A.U35.18 and A.U35.19 → 76; A.U35.20 → 77, 78; A.U35.44 → 84 (test side only); A.U35.10 → 97 (self-test)
- A.U35.43 → 80, 81, 82, 83
- A.U35.08 → 98, 102; A.U35.22 → 100, 101, 102; A.U35.35 → 93, 102
- Step 102: A.U18.05 (its code landed at src/asy_udp_socket.py:33-35,:122-132; only the twin idle measurement is left), A.U35.01/.03/.04/.05/.09/.23/.28/.37/.41/.50/.51
- A.U35.51 → 102, 103; A.U35.02 → 102 (SCR.024), 106, 109; A.U35.36 → 104, 110; A.U35.56 → 105; A.U35.23 and A.U35.24 → 107; A.U35.32 → 108

## 3. OPEN FINDINGS IN THIS RANGE'S FILES
- **OF-81** (src/asy_base_classes.py:123-126, `__aexit__` swallows `RuntimeError` on a double release): open. It joins the cancel-sweep helper's step (M.TEST_HELP.067, not in this range); the sweeps in 55/59/61/62/65/67/71/79 assert its invariants.
- **OF-211** (unit files depending on 127.0.0.1:123/:53): open. Joins steps 50 and 56 (tests/test_asy_ntp_client.py).
- **OF-221** (src/asy_print_log.py:181-182,:190-191, shared `_reset_mark`, still there at :151-152,:358-359): open. Joins step 93.
- **OF-223** (tests/test_digital_twin_uart_link.py soak rate): open, target U36; its file's U35 holder is step 100.
- **OF-225** (src/asy_config_manager.py:396-402 and :582-588, one non-yielding flush): open. Joins step 82.
- **OF-32** (digital_twin/machine.py `_epoch_us` on a 2**30 build): open. Joins step 108, whose twin leg would hit it.
- None of the other U35 rows sits in this range's files.

## 4. PACKET VS CODE
- **DrivenTime collision (it decides steps 46-49, 53, 64, 66, 86-90, 94, 97, 99(1)).** The packet's M.TEST_HELP.065 is a new tests/_driven_time.py with `install()`, async `advance()`, `run_until()` and an asyncio shim. The tree already has a `DrivenTime` in tests/_fake_time.py:15-37: it swaps only `time`, has a synchronous `advance()`, and is used in 8 files. The file-local asyncio shims are `_YieldOnlyAsyncio`/`_DrivenClock` (neopixel test :61-105) and the webserver-connections `_DrivenClock`.
  - Proposal (agent, 2026-10-21; CLAUDE.md "check Part G's catalog first for an existing primitive to reuse"): extend tests/_fake_time.py's class, or promote the neopixel shim beside it, rather than add a second class of the same name. P2 and the M.TEST_HELP.065 owner decide.
- **Moved files:** step 66 → tests/test_asy_webserver_connections.py; step 103 → tests_hardware/markers.py.
- **Renamed files** (asy_ prefix): test_asy_config_manager.py, test_asy_crc_checks.py, test_asy_captive_dns.py, test_asy_print_log.py, test_asy_system_service.py, test_asy_base_classes.py; src/asy_config_manager.py.
- **Stale names:** `_neopixel_freq` should be `neopixel_freq`; the packet's `FakeNtpServer(port)` is now `(port, *, poll_ms, poll_tries)`; the packet's "TempOffs" is "TempOffset" in markers.py.
- **Step 81/83 conflict.** A.U35.43 (2) removes tests that pass non-dict data. But src/asy_config_manager.py:622 now checks a non-object explicitly (E BAD_ARG), and tests/test_asy_config_manager.py:1981 pins that branch. Keep the test while the branch exists (agent, 2026-10-21, conservative).
- **A.U35.43 (3) not landed:** the C.5 "don't remove them" sentence is still at SPECIFICATION.md:3156-3161. No step in 46-110 edits it, so P2 locates its step.
- **A.U35.44 code half not landed:** src/asy_crc_checks.py:37-38 `_crc()` pass-mode guard and :92-95/:110-113 `except ValueError`. That is M.SRC_CORE.116's step, outside this range; step 85's new cases also need M.SRC_CORE.131 first.
- **SPEC pointers:** the packet cites "C.14.3" for the registration shape (steps 87-90). In the tree, C.14.2 is the `_WIRING` convention (SPECIFICATION.md:4333) and C.14.3 is the error fan-in (:4436); the files cite C.14.2. Keep C.14.2 (agent, 2026-10-21). E.5.1's heading is now at :5218, under a different title; A.U35.41 has to re-locate the unreachable-branch register.
- **Not determinable read-only:**
  - Whether driven waits keep their counts exact (needs a run).
  - Step 93's store-merge case (read :827-900).
  - Step 69's shared-WLAN assertions (read :1593-1694).
  - Step 86/87 docstring wording ("(SPECIFICATION.md L.2)" against the packet's "(buildgen/codegen.py)").

## 5. FILES (step numbers)
- **tests/test_asy_notification_service.py:** 46, 47, 48, 49
- **tests/test_asy_ntp_client.py:** 50, 54 (check), 55, 56
- **tests/test_asy_udp_socket.py:** 63 (check), 64, 65
- **tests/test_asy_uart_driver.py:** 60, 61
- **tests/test_asy_wifi_service.py:** 68, 69, 70 (all check), 71
- **tests/test_asy_config_manager.py:** 80, 81, 83 (all check)
- **tests/test_bus_hazard_multi_device.py:** 73, 74, 76, 77; with tests/_bus_hazard_catalog.py: 73, 76
- **tests/test_asy_crc_checks.py:** 84 (check), 85
- **tests/test_ntp_fram_system_integration.py:** 91, 92 (check)
- **tests/test_asy_system_service.py:** 94, 95, 96 (all check)
- **tests/test_asy_webserver_connections.py:** 66, 67
- **Notification integration files:** tests/test_notification_neopixel_integration.py 87; tests/test_notification_scd30_integration.py 88; tests/test_notification_sgp40_integration.py 89; tests/test_notification_scd30_sgp40_integration.py 90
- **Driven-time and twin tests:** tests/test_asy_neopixel_driver.py 53; tests/test_neopixel_wifi_integration.py 86; tests/test_driven_time.py (new) 97; tests/test_digital_twin_network_neopixel.py 99; tests/test_digital_twin_uart_link.py 100
- **Other tests, one step each:** tests/_ntp_frames.py 57; tests/test_asy_fram_driver.py 51 (check); tests/test_asy_isl29125_driver.py 52; tests/test_asy_scd30_driver.py 58; tests/test_asy_uart_comm.py 59; tests/test_asy_uart_link_driver.py 62; tests/test_asy_base_classes.py 72 (check); tests/test_asy_sgp40_driver.py 75 (check); tests/test_asy_spi_driver.py 78 (check); tests/test_asy_captive_dns.py 79; tests/test_asy_print_log.py 93
- **src/asy_config_manager.py:** 82 (check; OF-225)
- **tests_scripts/_devices.py:** 98 (check)
- **tests_hardware:** flash/test_fram_storage.py 101 (check); markers.py 103 (check); flash/test_bus_concurrency.py and device_scripts/bmp3xx_alone_survives_a_general_call.py 74 (landed, H29)
- **audit/b3/*:** 102, 104, 105, 107 (timing.md); audit/sweeps/ticks30_build.sh 108
- **scripts:** lint.sh 102; _run_lower_levels.sh 106; test.sh 107; _digital_twin_ci_suite.py 109 (all except test.sh's re-order are check)
- **SPECIFICATION.md:** A.5 110 (check); Part N rows 48, 76, 105

The helper scripts I used are in /tmp/claude-0/-home-user-sensors/185d5b0e-d0ae-57c0-8798-ed52081f7df8/scratchpad/u35/plan_scratch/b/ (wo*.py, of.py, hw.py, plus extracted texts).