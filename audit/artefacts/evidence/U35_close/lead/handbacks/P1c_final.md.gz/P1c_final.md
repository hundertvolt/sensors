# P1c record: U35 steps 111-144 (agent, 2026-10-21)

**Scope.** I read the packet's standing sections, steps 111-144 and the 30 carried actions those steps name. The tree checked is `S/wt-u33plan` at `1dd6dd5` (HEAD confirmed, working tree clean). All path:line citations are at that commit. I made no edits. My helper scripts are in `S/u35/plan_scratch/c/` (`g.py`, `of.py`, `s1-s4.json`). I used about 63 tool calls.

**Numbering.** The packet's step numbers govern, as the brief says. `audit/order/work_order.json` lists U35's steps in a different order: its #111 is M.TEST_UNIT.124, and packet step 111 (M.SPEC.081) is its #57.

## 1. STEP TABLE

| # | M.ID | files | verdict | evidence / what is left |
|---|---|---|---|---|
| 111 | M.SPEC.081 | SPECIFICATION.md E.5-E.5.3 (:5184-5361) | part landed; U35 (2) **to write** | **Landed:**<br>• A.U28.15: there is no Codecov step and no Cobertura XML anywhere in `ci.yml`, `test.sh`, `_render_coverage.py` or `.gitignore` (grep finds only doc mentions). The four publish steps are `ci.yml:611-644`; the count of 8 is asserted at `tests_scripts/test_test_sh.py:1973`; `--xml-file` is refused at `tests_scripts/test_render_coverage_anchors.py:39`.<br>• E.5 body: the archive and incomplete-file sentences :5193-5194, :5208.<br>• E.5.2 probe bullet :5296-5310.<br>• E.5.3 `Result: PASS (coverage report not rendered)` :5357-5358.<br>**U35 writes:**<br>• The convention paragraph (absent: grep "A branch no input can reach" finds nothing).<br>• The register at :5234-5259, rewritten per A.U35.41's table.<br>**Stale at HEAD:**<br>• :5246 "`except Exception` around `type(nt).__name__`" — the catch is gone (`src/asy_config_manager.py:257-258`).<br>• :5247 the wifi `ifconfig()` `return None` — `get_wlan_ifconfig` is gone.<br>• :5249 the sgp40 `readlen is None` — gone.<br>**Go:**<br>• "That pass left **31 genuinely uncovered lines across 8 files** …" (:5254-5256).<br>• "Two more were found exactly that way in the 2026-09-22 pass" (:5263) gets reworded.<br>**Earlier-stage gap:** U24's tracer classes are missing from E.5.1's first paragraph (:5220-5230 lists only const, decorator and `while True`). |
| 112 | M.SPEC.092 | SPECIFICATION.md F.1 | **to write** (U35's two sentences) | Already in place: wall clock (2) :6053-6073 and C stack (3) :6075+.<br>U35 inserts two sentences after :6051 ("…`tests/test_ticks_rollover.py` and the drivers' own test files)."):<br>• "Wrap safety was run once on a 2**30-period Unix build … (agent, <date>)" — only after step 108 (M.PROC.024, P1b) has run.<br>• "On silicon the rollover round's tick-offset test image crosses … about 15 minutes after boot (B.14.5, E.6.3)" — B.14.5 exists at :2516.<br>REGISTER.md:414 (U14 ruling 7) confirms the scratch-build sentence is U35's. The A.U36.544 item-12 sentence is U36's. |
| 113 | M.SRC_CORE.130 | src/math_helpers.py | **landed** | All five catches read `except (ArithmeticError, ValueError):` at :68, :120, :147, :167, :227.<br>End-state function order holds: :53 abs_humidity, :72 cct_mccamy, :90 chromaticity_xy, :102 dew_point, :124 ema_step, :137 pressure_at_height, :151 rel_humidity, :174 rgb_to_hsb, :196 rgb_to_xyz, :210 wet_bulb_temperature. |
| 114 | M.TEST_HELP.042 | tests/_sensortask_scenarios.py | **to write** | None of the four groups exists (grep for fault_storm, forty_days, dropped_one_second, stops_every_feed, `_log_dead_task`, persisted_log: nothing).<br>**Blocked on step 32** (M.TEST_HELP.065, P1a): `DrivenTime` (`tests/_fake_time.py:15-37`) is only a ticks module swap. It has no asyncio sleep shim, no async advance/run_until/jump and no wait_for shim; `Ticks30Time.advance()` is synchronous (`tests/_ticks30.py:27`).<br>**Seams present:**<br>• `tests/machine.py`: `Timer.all_timers` :1232, `drop()` :1288, `trigger()` :1320, `WDT.feed_count`/`feed_times` :1372-1389, `SimulatedRebootError` :1448.<br>• Supervisor: `_log_dead_task` `src/asy_system_service.py:297`, `_TASK_FAIL_MAX` :69, `_reset_armed` :550, `supervise_tasks()` :783.<br>• Generated `main()` emitter `buildgen/codegen.py:544-559`.<br>• The scenarios already read `chip.write_transactions` (:1357). `tests/_fram_chip_fake.py` has no per-logger write counter. |
| 115 | M.TEST_UNIT.229 | tests/test_asy_base_classes.py | **landed**; check-only | • `get_cfg_schema()` :119, :1894-1933.<br>• `assert run(reader.setup()) is True` :1871.<br>• FRAM-rule comment verbatim :2086-2087; no "stays public" left.<br>• The RAM-only class test exists under another name: `test_a_reader_that_keeps_its_config_log_off_fram_still_logs_its_own_to_fram` :2164-2188 (`_CFG_LOG_FRAM = False` :2161). |
| 116 | M.SPEC.058 | SPECIFICATION.md C.7 (:3329) | part landed; U35 (7) **to write** | Already in place: pitfall and RAM-only text (1)/(12)/(13) :3331-3355; per-layer and mixed-kind rule :3431-3439; report_if_fatal :3491; WIFI rule (15) :3505-3510.<br>U35 inserts at :3439, after "…(`tests_scripts/test_fault_or_warning_never_both.py`)." and before "A failed config read is persisted…": "An expected condition prints only: a normal situation never logs a code, and a test of one asserts no entry (owner, 2026-09-12, `8a45060`: '…')".<br>The "one save primitive" pointer stays U36's (current text at :3337-3338). |
| 117 | M.TEST_UNIT.230 | tests/test_asy_base_classes.py | **landed**; check-only | • Header comment :2279-2281 ("(owner, 2026-09-26)").<br>• "(agent, 2026-08-03)" :3191.<br>• No "Final project decision", "(project decision)" or "benign" left.<br>• Unknown-key test :3027-3037.<br>• New tests :2285, :2302, :2414 (with `WriteCountingOpen` :2440), :2454, :2492, :2523, :2548, :2568.<br>• Fold (1) :1624. |
| 118 | M.SCR.049 | scripts/_digital_twin_ci_suite.py `_run_1_baseline` :1089-1124 | part landed / **to write** / part **conflicts** | **Landed:** the null-before-sync check :1099-1100; ResetErrors `Valid` plus budget in `_put_reset_errors_timed()` :682-696 (called at :1116); the `ctx.state_dir` check :1123.<br>**To write (before :1116):**<br>• One `GET /status`/`/system` read, kept as `run1_errcount.json`.<br>• Every module's history: no E and no W entry (`_error_codes()` :521).<br>• Fold (1): the reformat relaunch with exactly one W `CONFIG_LOST` (the catalog row exists), kept as `run1_reformat_errcount.json`.<br>**Conflicts:** the step wants a poll until `NTPSynced` is true in Run 1. Run 1 has no station link (its comment :1090-1091; the SSID is set in Run 6 :1349). HEAD proves the synced half in Run 5 :1236 and Run 8 :1409-1412.<br>Conservative choice (agent, 2026-10-21): keep the synced half where it is and write no Run-1 poll.<br>HEAD has no `runs/` directory (the archive is `ctx.logs_dir/"state_archive"` :340), so the files go under `ctx.logs_dir/"runs"`. |
| 119 | M.TEST_UNIT.273 | tests/test_math_helpers.py | **to write** | No stand-in exists (grep for `ArithmeticError`, `mh.math`, "stand-in": nothing).<br>The module is imported as `mh` (:4). The test goes before the final `microtest.run(globals())` trailer.<br>Math calls to stand in: `pow` :67/:165, `log` :117, `exp` :146, `atan`/`sqrt` :221-225. |
| 120 | M.TSC.134 | scripts/test.sh, tests_scripts/test_test_sh.py | **landed** (U35 part); one re-measure left | • Heavy list :661-671; `_check_heavy_list` with its message and exit 2 :672-681.<br>• Tests :1988-2000.<br>• Tunables :36-39.<br>• `--help` :1319-1350; exit-2 cases :1251-1335; `fixture_device` :1120.<br>Left: A.U35.24 (3), re-measuring the list against A.U35.23's timing. The list has 10 entries, not the 15 the action names. OF-200 joins this. |
| 121 | M.TWIN.031 | digital_twin/machine.py :1474-1538 | **check-only** | • Cap comment :1474-1475; TEST_API :1482.<br>• Comment block :1494-1495; bounded logs :1497-1499; `_armed_at_ms` :1502.<br>• Saturating counters :1530, :1536; `feed_times` append :1537. |
| 122 | M.TWIN.054 | digital_twin/run_device_script.py | **check-only** | • Header :1-3; prewarm then shim :105-106; `# @tunable wdt.timeout_ms = 8000` :27.<br>• WDT armed :122-123; `gc.threshold` :126; exec comment :128-129.<br>• Reset exits :132-135; `sys.exit(main(…))` :148.<br>HEAD goes beyond the packet: exit code 6 (watchdog starved) :13 and a `--state-dir` option. Only the `machine_wdt.c:43-57` citation is missing from :122's comment. |
| 123 | M.TWIN.102 | tests/test_digital_twin_bus_hazard_concurrency.py | **check-only** | • Derived devices :33, :104-106; no in-DUT burst; `dropped` check :275; `resets` :283.<br>• Heater, soft-reset and re-apply cases :756-894; `owner=` :457-650.<br>• Owner tag :478 "(owner, 2026-09-04, paraphrase)".<br>Not determinable read-only: whether reset-reachable cases catch `SimulatedRebootError` (grep: none). Running the file settles it. |
| 124 | M.TWIN.144 | tests/test_digital_twin_sensortask_integration.py | part landed; U35 **to write** | **Landed:** header :1-3, `PER_DEVICE` :21; tests 1 :401, 3 :446, 4 (now :567 plus :599), 5 :644, 10 :662 (MEASURE :683), 6 :719, 7 :743, 8 :777, 9 :814; (19) is in tests/test_digital_twin_wifi_modes.py:221.<br>**Test 2 (A.U35.31 (1)) to write:** :422-443 still uses `_feed_watchdog_periodically()` (:213-216, :433) and hand-started timers and tasks (:429-432). It becomes a `main()` run under `run()`, renamed, plus:<br>• the offline-boot assertion `public_destinations_refused == 0` (today only printed on the runner's shutdown line, `run_generic_integration.py:465`);<br>• the comment's second line.<br>**Fold parts (11)-(16) and (18) to write** (packet :205-242; grep for WLAN_NO_VERDICT, `_SAMPLE_MAX_AGE_S`, burst_answered: none). (17) is covered in wifi_modes :231. |
| 125 | M.SCR.018 | scripts/_digital_twin_scenarios.py; digital_twin/run_generic_integration.py | part landed; U35 **to write** | **Landed:** (d) :484, (e) :572, measurements_and_sensors_shape :1086, (j) :1040, (k) :907/:1367, (l) :932/:1170/:1286, (m) :1872.<br>**To write:**<br>• (f) watchdog_fault_*: needs the runner flag `--test-watchdog-fault` and a `WDT_AT_FAULT` line (absent; the flag table is at :384-409).<br>• (g) A.U35.09's two recombinations (use `NTPHost`, Run 8 :1420).<br>• (h) the bounded storm: needs `fram_writes=`/`fram_writes_by=`/`fram_writes_unattributed=` on the shutdown line (absent at :463-465). It depends on step 151 (M.TWIN.050, P1d).<br>• (i) zero_think readers.<br>• Folds (1)-(3). Their product fields exist: `HTTPDropped` `buildgen/codegen.py:661`, `ConfigUnpersisted` :673, catalog rows CHIP_GET and CFG_FILE_WRITE. |
| 126 | M.DOCS.065 | BACKLOG.md "## Deferred / explicitly out-of-scope work" :537 | **to write** (U35 part) | Remove the bullet at :1174-1184 ("Network fault injection against the real dev bench unit is complete … **Still open**: the NTP-outage-x-bus-load fault recombination has no twin/mock-tier equivalent … not chased yet. …") once step 125 (g)(a) lands. The rest of the step is U37's. |
| 127 | M.HW_DEV.106 | tests_hardware/device_scripts/scheduler_saturation_drop.py | **check-only** (hardware R1 [H48]) | `_N_TIMERS` :24, 900 µs steps :28/:49-51, arming span :47, heal window :30, facts :59-65 (`dropped` is computed inside the fact at :64). |
| 128 | M.SPEC.160 | SPECIFICATION.md E.2.3 (new), E.6.6 :5532, K.10 :10041 | **to write**; unit mismatch | None of the five E.2.3 sentences exists, E.6.6 has no DHCP sentence, and K.10 has no fault-planting gate.<br>**Mismatch:** the merged text's Unit says U36; the work order puts it in U35 (#66, carrying A.U35.04/.28/.33).<br>Conservative choice (agent, 2026-10-21): land it in U35, after step 143 creates E.2.3 and after the tests that make its sentences true. |
| 129 | M.HW_BENCH.016 | tests_hardware/harness.py | **check-only** | Markers :58-63, `boot_lines` :444, `crash_lines` :455, `observe_during` :521 with its tunable :143-144, `wait_for_boot` :686. |
| 130 | M.HW_BENCH.060 | tests_hardware/bench/conftest.py | **check-only** (hardware: every round's first step [H04]) | `check_image` :71, `board_image` :83-94. |
| 131 | M.HW_BENCH.074 | tests_hardware/bench/test_memory_stress_bench.py | **check-only** (hardware R1 [H83], soaks R5 [H64]) | Derived names :81, routes :24, crash/boot lines :136-137, floor :33-34, `test_http_soak_stays_live` :93, failure rate :39, COVERS list :18, comment :115. |
| 132 | M.HW_BENCH.075 | tests_hardware/bench/test_modlwip_send_stall.py | **check-only** (hardware R1 provisional / R4 [H39, H40]) | :83, :93-118. `check_image()` appears as `_load.image_deviations(request, dut_ip, record)` (:112, :118). |
| 133 | M.HW_BENCH.091 | tests_hardware/twin_board.py | **check-only** | :49-58, `run_isolated` :109, `_unix_port.sh` :25/:42/:46, micropypath :27/:66. A.U27.12/.15 landed here. |
| 134 | M.HW_BENCH.092 | tests_hardware/twin_record.json | part landed; U35 **to write** | 122 entries (19 bench, 88 device scripts, 15 flash): 21 pass, 101 exception. All carry `gc_threshold: -1`, dated 2026-10-21.<br>U35 owes the re-record at both GC stages after B2's and B3's last hardware-facing change, plus a review of every exception.<br>59 device-script entries are charged with their flash file's silicon-only case (OF-229). |
| 135 | M.HW_BENCH.121 | tests_hardware/README.md :522-541 | **check-only** | 12 habits, each with its enforcing check; the twin-first habit is at :538. |
| 136 | M.HW_DEV.010 | twin_record.json and every instrument | **to write** (procedure) | The re-runs at both stages (with step 140), the bite review (A.U35.03), the gates proven through the twin (A.U35.05), and the wear gates (A.U35.51). |
| 137 | M.PROC.023 | audit/b3/intent.md, audit/b3/levels.md | **to write** | `audit/b3/` does not exist at `1dd6dd5`. A.U35.01 opens it, and that step is in another range. |
| 138 | M.PROC.027 | audit/b3/conformance.md | **to write** | Same. |
| 139 | M.PROC.037 | throwaway worktree; the flash and bench runners | **hardware** (phase C, R1 end, [H43]) | Nothing in the tree. REGISTER.md:722: hardware session 1 waits for the owner's order after U35. |
| 140 | M.SCR.022 | scripts/record_twin_instrument_runs.py (+ tests_scripts/test_twin_record.py) | part landed; U35 **to write** | Landed: tmp file plus replace :143-145; the `pytest --twin` flash run :41; the binary and MICROPYPATH through TwinBoard.<br>To write: the second GC stage. Today there is a single `_GC_THRESHOLD = -1` (:32) and one `gc_threshold` per entry (:140); each entry needs an outcome at -1 and at 32768. OF-229 sits at :125-130. |
| 141 | M.PROC.029 | audit/b3/queue_c.md | **to write** (hardware preparation) | Absent. |
| 142 | M.DOCS.064 | BACKLOG.md "## Real-hardware work still owed" :194-536 | **to write** (U35's rows only) | Existing rows include the general-call ACK/NAK row :368-372 and the lwIP row :333-338.<br>U35 adds rows for its new instruments as A.U35.54 lists them (the silicon arm of the gates first). The lone-BMP3xx flash test exists at `tests_hardware/flash/test_bus_concurrency.py:267`. |
| 143 | M.SPEC.077 | SPECIFICATION.md E.2 :4846-4955 | part landed; U35 (4) **to write** | **Landed:** (1) :4848-4865, harness :4867-4882, helpers :4884-4897, buildgen homes :4899-4906, "Waits poll" (5) :4908-4912 (sitting in E.2, since there is no E.2.3).<br>**Not landed:** no E.2.2/E.2.3 headings; the "Session 6.2" sentence :4940-4942 is U36's.<br>**U35 writes:** "### E.2.3", with "**A test bites** …" and "**Time at L1 is driven** …". The second needs step 32's virtual sleeps first.<br>Conservative choice (agent, 2026-10-21): the hygiene sentences already in E.2 (:4857-4860) stay; U36 relocates them. |
| 144 | M.SPEC.137 | SPECIFICATION.md J.7 (:9512); maybe tests/test_uart_comm_hazard.py | U35 (5) **to write** | "The accepted trade-off is that neither test would now catch a *latency* regression below 240 ms — …" (:9641-9643) is replaced after A.U35.06's plant. (6) has landed at :9666-9673.<br>**UART:** test and doc only. No emitted byte, accept/reject rule or recovery timing changes; nothing is logged in UART_C_PORT_CHANGELOG.md. |

**UART files.** No step in this range edits `src/asy_uart_comm.py`, `src/asy_uart_link_driver.py` or `UART_C_PORT_CHANGELOG.md`. Step 125 (m) only reads `_FLASH_HOLD_MAX_MS` by `ast` (already landed). Nothing here is a wire-format conflict.

**`# @tunable` tags:**
- Step 120's two tags have landed (`tests_scripts/test_test_sh.py:36-38`).
- Step 125 (i) adds a reader-floor tag.
- Steps 114 and 125 (f) may add tags for their driven or watchdog windows (per A.U8.02).
- Step 144 adds one bound tag only if no existing test bites.
- Step 124's test-2 rewrite drops this file's use of the `l2.twin_wdt_feed_interval_s` loop.

**`error_catalog.json`:** no step here adds or removes a row. Step 118 reads `CONFIG_LOST`; step 125 reads `CHIP_GET` and `CFG_FILE_WRITE`.

**Twin-record inputs:**
- Steps 134, 136 and 140 change the record and its shape (a per-stage field), so `tests_scripts/test_twin_record.py` must follow.
- Step 125 (f)/(h) changes `run_generic_integration.py`. That file is not in `runner_sha256` (`RUNNER_FILES` = `run_device_script.py` + `twin_board.py`).

## 2. Carried actions → steps

| action | step(s) and state |
|---|---|
| A.U28.15 | 111 (landed) |
| A.U35.41 | 111 (E.5.1 text); 113 (row; landed) |
| A.U35.42 | (1) → 113 and 119. (2), the FRAM half, sits outside this range (packet steps around 22-23) and appears landed: no `errno=98` in `src/asy_fram_driver.py`. |
| A.U35.32 | 112 (the sentence); the scratch run itself is step 108 |
| A.U35.36 | 113 (the map itself is step 104) |
| A.U35.03 | 114, 136, 143 |
| A.U35.10 | 114, 143 (needs step 32) |
| A.U35.28 | 114 (1), 125 (h), 127, 128 |
| A.U35.30 | 114 (2) |
| A.U35.33 | 114 (3), 128 |
| A.U35.34 | 114 (4) |
| A.U35.37 | 115, 116, 117, 118 |
| A.U35.38 | 118 (the action is dropped; the step carries its successor text) |
| A.U35.24 | 120 |
| A.U35.31 | 121 (check), 124 (test 2), 125 (f) |
| A.U35.49 | 122, 134, 135, 136, 140 |
| A.U35.09 | 123 (adds nothing), 125 (g), 126 |
| A.U35.21 | 123, 134 (script and flash test already in tree) |
| A.U35.50 | 123 |
| A.U35.29 | 125 (i) |
| A.U35.04 | 128 |
| A.U35.05 | 129-133, 136, 139 |
| A.U35.07 | 137, 143 |
| A.U35.22 | 137 |
| A.U35.53 | 138 |
| A.U35.51 | 136 |
| A.U35.54 | 141, 142 |
| A.U27.12, A.U27.15 | 140 (landed through twin_board.py) |
| A.U35.06 | 144 |

## 3. OPEN FINDINGS whose site is in this range's files

| finding | site | state | joins |
|---|---|---|---|
| OF-149 | twin integration test failed once under build-settrace | open | step 124 |
| OF-188 | the same file's settrace heap drift | open | step 124 |
| OF-229 | `scripts/record_twin_instrument_runs.py:125-130` charges each script with its flash file's outcomes | open; visible in 59 record entries | step 140; gates steps 134 and 136 |
| OF-200 | `tests/test_sensortask.py` duration | open | step 120's re-measure (or the A.U35.23 timing step) |
| OF-32 | `digital_twin/machine.py` `_epoch_us` :900, `_now_us` :930 on a 2**30 build | open | step 108 (P1b), the only run that trips it; my step 121 holds the file check-only |
| OF-184 | CONFIG_LOST in scratch builds | open, target C | related to step 118 fold (1) only |
| OF-47, OF-187 | — | closed at U30 | — |
| OF-199 | test_test_sh.py's half | closed at U28 | — |

Register rows:
- REGISTER.md:414 → step 112.
- REGISTER.md:691/:722 (firmware final at U35's end; hardware session order is the owner's call) → steps 139 and 141.

## 4. PACKET VS CODE

**Renames:**
- Source modules: `system_service.py`, `base_classes.py`, `print_log.py`, `config_manager.py` and `crc_checks.py` are now the `src/asy_*.py` versions.
- `tests/test_base_classes.py` is now `tests/test_asy_base_classes.py`; the packet's :743-1851 citations are stale.
- The supervisor's `start_and_check_tasks()` is gone. It is now `start_tasks()` :744, `supervise_tasks()` :783 and `_supervise()` :524.
- `NTP_Host` is now `NTPHost`.

**Moved:**
- `tests/_driven_time.py` and its self-test do not exist; `DrivenTime` is at `tests/_fake_time.py:15`.
- M.TWIN.144's test 4 was rewritten from reconstruction to radio re-selection (:567, :599).
- (19) is one combined test in `tests/test_digital_twin_wifi_modes.py:221`.
- `check_image` is `_load.image_deviations`.
- TwinBoard's `gc_threshold` is a constructor keyword, not a `run_isolated` keyword.

**Done by earlier units:**
- A.U35.21's script and flash test are in the tree (the mock copy's deletion is another range's step).
- A.U28.15 and A.U27.12/.15 have landed.

**Stale or diverging:**
- Three E.5.1 entries (row 111).
- The heavy list has 10 entries, not 15.
- `reset_code_boot_phase_hang.py` passes in the twin, though the packet expects a silicon-only exception.
- `bmp3xx_alone…` is recorded as an exception, though A.U35.21 expected it to pass by construction (see OF-229).
- E.2.1's heading is `##`, not `###` (U36 renumbers).

**Not determinable read-only, and what would settle each:**
- Whether A.U14.32's full tick sentence (U17's stage) has landed — compare F.1 :6043-6051 with the action text in `audit/actions`.
- Whether the bus-hazard file still guards resets — run the file.
- Whether E.5.1's tracer classes hold on `build-settrace` — a `--coverage` run.
- Whether folds (11)-(16) can be driven in-process with today's seams (for example `_SAMPLE_MAX_AGE_S = const(10800)` at `src/asy_notification_service.py:69` needs the twin wall clock) — write and run.

## 5. FILES (with step numbers)

| file | steps |
|---|---|
| SPECIFICATION.md | 111, 112, 116, 128, 143, 144 |
| tests/test_math_helpers.py | 119 (113 is landed, no edit) |
| tests/_sensortask_scenarios.py | 114 (depends on tests/_fake_time.py, step 32) |
| tests/test_asy_base_classes.py | 115, 117 (check) |
| scripts/_digital_twin_ci_suite.py | 118 |
| scripts/test.sh, tests_scripts/test_test_sh.py | 120 (landed) |
| digital_twin/machine.py | 121 (check) |
| digital_twin/run_device_script.py | 122 (check) |
| tests/test_digital_twin_bus_hazard_concurrency.py | 123 (check) |
| tests/test_digital_twin_sensortask_integration.py | 124 |
| scripts/_digital_twin_scenarios.py | 125 |
| digital_twin/run_generic_integration.py (+ digital_twin/README.md flag list) | 125 (f); (h) via step 151 |
| BACKLOG.md | 126, 142 |
| tests_hardware/device_scripts/scheduler_saturation_drop.py | 127 (check) |
| tests_hardware/harness.py | 129 (check) |
| tests_hardware/bench/conftest.py | 130 (check) |
| tests_hardware/bench/test_memory_stress_bench.py | 131 (check) |
| tests_hardware/bench/test_modlwip_send_stall.py | 132 (check) |
| tests_hardware/twin_board.py | 133 (check) |
| tests_hardware/README.md | 135 (check) |
| tests_hardware/twin_record.json | 134, 136, 140 |
| scripts/record_twin_instrument_runs.py, tests_scripts/test_twin_record.py | 140 |
| audit/b3/{intent,levels,conformance,queue_c,load}.md | 137, 138, 141 (114 and 125 add load.md entries) |
| tests/test_uart_comm_hazard.py | 144 (only if no existing test bites) |
| throwaway worktree | 139 |

**Cross-range dependencies for P2:**
- Step 32 (M.TEST_HELP.065) must come before steps 114, 143 (4) and 144.
- Step 108 (M.PROC.024) must come before step 112.
- Step 151 (M.TWIN.050) must come before step 125 (h).
- A.U35.01, which opens `audit/b3/`, must come before steps 137, 138 and 141.
