# U35 plan, block P1a: steps 1-45 (agent, 2026-10-21; read-only at 1dd6dd5)

I used about 70 tool calls and covered all 45 steps. Every line number is at `1dd6dd5` in `S/wt-u33plan`, except `tests/test_asy_neopixel_driver.py`, which I read at `970b63b` (copied to `S/u35/plan_scratch/a/neo_970.py`). My helper scripts are in `S/u35/plan_scratch/a/` (wo.py, wo2.py, has.py). The order in the work order (U35 `order[0:45]`) matches the packet's step order. Nothing in the tree was edited.

Tags used in the table:
- **[UART]**: the step edits `src/asy_uart_comm.py` or `UART_C_PORT_CHANGELOG.md`. None of these steps changes an emitted byte, an accept/reject rule or a recovery timing; all are comments or Class B "no C impact" rows.
- **[TAG]**: the step adds or removes a `# @tunable` tag.
- **[CAT]**: the step adds or removes a row in `error_catalog.json`.
- **[TWIN]**: the step changes an input of `tests_hardware/twin_record.json`, so that file must be re-recorded.

Verdict counts: landed 16 (1, 2, 7, 11, 12, 13, 14, 15, 16, 18, 19, 30, 31, 33, 38, 42), check-only 1 (17), to write 6 (21, 22, 23, 32, 36, 39), part landed 22. Steps 3, 5, 6 and 7 also need the bench.

## 1. Step table
| # | M.ID | files | verdict | evidence at 1dd6dd5 |
|---|---|---|---|---|
| 1 | HW_BENCH.050 | tests_hardware/error_log_helpers.py | landed | Docstring :1-3. `code` re-export :15-16. Comment and both tags :47-52. `reset_all_error_logs(dut_ip, reason)` calls `save_errcount()` first (:159-162). `save_errcount` is at :170-173. |
| 2 | HW_BENCH.052 | same | landed | `_nonempty` is gone (no match in tests_hardware or tests_scripts). The `clean` helper and its comment are at :78-83; the only wording difference is "deliberately". |
| 3 | HW_BENCH.068 | tests_hardware/bench/test_end_to_end_timing.py **[TWIN]** | part landed; hardware R1, the backup-reset test R3 H68 | Already done: burst probe :112-113; banners :117-119, :126, :128; owner tag :132; reasons :140, :171; `recover_by_reset` :155, :167; `persistence_write` :138. **Left (A.U35.40 (1))**: :159 `assert_module_error_log_empty(dut_ip, "FRAM")` becomes `assert_module_error_log_clean(dut_ip, "FRAM", allowed_warnings=(code("W", "FRAM_BLOCK_INVALID"),), allowed_errors=(code("E", "FRAM_STATUS_BYTE"),))` with the owner comment. The import at :12 gains `assert_module_error_log_clean` and `code`. The code mapping is in section 4, item 2. |
| 4 | HW_BENCH.131 | tests_hardware/README.md | part landed | Fold (1) bullets are at :1283-1298, under the heading at :1020. **Left (U35)**: the torn-write bullet. It is absent: `test_real_hard_resets…` appears only at :1870, in another section. U36's parts are also still open: the hotspot-fallback bullet (absent) and the BACKLOG session citation at :1224. |
| 5 | HW_DEV.090 | device_scripts/bus_topology_autodetect_and_hazard_sweep.py, device_scripts/_shared/bus_reader_loops.py **[TWIN]** | landed + OF-02/OF-05 to write; hardware R1 (H73 rerun) | Already done: constants :40-46; `BENCH` :128-130; `recover()` step :92-101; heater-off :165-167; fact keys :174; fold facts :180-182; host asserts in flash/test_bus_concurrency.py:243-245. The open findings are in section 3. |
| 6 | HW_DEV.092 | device_scripts/bmp3xx_alone_survives_a_general_call.py; tests/test_bus_hazard_multi_device.py | part landed; hardware R1 H29 | The script was added at U26 (`0c0ad52`): `arm()` :43, `BENCH` :44-47, general call through `I2CDevice(i2c, 0x00)` :61, facts :76-82, `done()` :87. The twin record has its entry at twin_record.json:182. **Left (A.U35.21 (3))**: delete the mock test `test_general_call_absent_sibling_bmp3xx_alone_on_the_bus_survives_a_broadcast_too` (test_bus_hazard_multi_device.py:248-289). |
| 7 | HW_DEV.080 | tests_hardware/flash/test_bus_concurrency.py | landed; hardware R1 H29 | Timeouts :24-37. Markers :98, :200-202. PRST comment :218. Sweep facts :232-245. New tests :250, :267, :339, :358. CS comment :291. Bench-counterpart lines throughout. |
| 8 | HW_BENCH.117 | tests_hardware/README.md | part landed | Already done: c_stack_budget :791, loop_stretch :805, flash_write_loop_gap :815, held SDA :921, sgp40 cadence :1322, and the F.3 rows line :836-839 (it says "Four", not "three"). **Left (U35)**: no bullet for `bmp3xx_alone_survives_a_general_call.py`, and :1737-1739 still credits the topology script's self-hazard branch for the lone-BMP case. Rewrite that bullet to name the script (L3, no write, no flash cycle, ungated). |
| 9 | SPEC.054 | SPECIFICATION.md | part landed | Already done: :3139-3145, :3150, :3161-3164, :3171-3177, :3181, :3187, :3195. **Left (U35, stage 7)**: :3158-3161 "`ConfigManager` carries three defensive catches … — don't remove them, covered independently by `tests/test_asy_config_manager.py`." becomes "Type mismatches are rejected statically: …". The scope paragraph ("one explicit scope", absent) is U36's. |
| 10 | SPEC.065 | SPECIFICATION.md | part landed | Already done: :3845-3859 owner decision with heater-off; :3861 standing rule; :3867 recovery ladder; :3933 every writer; :3955 `98dc1b2`; :3981, :3984. **Left (U35)**: in :3845-3859, add "a flash-tier script checks that a BMP3XX alone on its bus keeps its configuration and readings across the broadcast" (REGISTER:476 parks this for U35). U36's parts are open too: "derived, never listed" (absent) and "Session 6.2" at :3994. |
| 11 | SPEC.083 | SPECIFICATION.md | landed (check-only) | E.6.6 table :5502-5530. The lone-BMP case is in the `flash-only-bus-checks` row at :5522. |
| 12 | SRC_CORE.036 | src/asy_base_classes.py | landed | :400-430: no `logger=`; `module.max_error` tag :404; `_data_lock`, `_set_lock`, both callback dicts, ladder state, `_timer_error`. `tests/test_asy_base_classes.py` has no `logger=`. |
| 13 | SPEC.071 | SPECIFICATION.md | landed (U35 part) | :4301-4302 "before `make_logger()`". A.U22.02 has landed: no `last_value` or `.triggered` in src, buildgen, digital_twin or the test. U36's parts are open: :4278-4280 and :4308-4309. |
| 14 | SRC_CORE.048 | src/asy_config_manager.py | landed | :71, :75, :342-358, :360-369, :428-459, `get_dict` KeyError only at :443. A.U35.43 (1) is done: comment :394, test test_asy_config_manager.py:2912. A.U35.43 (2) is done: excepts :404, :530, :588, :618 carry no TypeError or AttributeError. See section 4, item 13. |
| 15 | SRC_CORE.090 | src/asy_fram_manager.py | landed | :454-495, with the narrowing comment at :464-465. |
| 16 | SRC_CORE.087 | same | landed | :507-620: tuple order, `utc_now()` :565/:600, the bare pack and unpack at :614/:553, the signed-age comment :567, narrowings :534, :550, :617. |
| 17 | GEN.034 | buildgen/error_catalog.json **[CAT: none]** | check-only | U35's only part is retiring the timestamp-pack code, and no such row exists: it is absent at U2 (`43aced0`) and now. Rows from other stages are present: E25, E28, W69, E91-93, W80, E65 retired, ResetReason 20/21. `FRAM_FULL` is absent; that is U16's stage. |
| 18 | SRC_CORE.101 | src/asy_fram_driver.py | landed | :38-114: `const()` command bytes, tags :74-81, status bits, codes. |
| 19 | SRC_CORE.107 | same | landed | `verify_present()` :477-502: `wait_for_ms` :485, no `id_error`. There is no errno-98 row (E98 absent). |
| 20 | SRC_CORE.116 | src/asy_crc_checks.py | part landed | Already done: tag :8, `_crc(…, poly)` :33-36, `_crc_wide` :52-74, callers pass `self._poly` at :89, :108, :124, :142, :170. **Left**: delete :37-38 `if self._poly is None: return crc` (REGISTER:336). |
| 21 | SRC_CORE.117 | same | to write | Bounds-first is already done (:100-103, :133-137). Unwrap the `try`/`except ValueError` around `pack_into` at :91-95 (`add()`) and :109-113 (`add_into()`). |
| 22 | DOCS.024 | UART_C_PORT_CHANGELOG.md **[UART]** | to write (U35 row) | The table holds B1-B86, numbered by landing order, which differs from the packet's numbers. **Left**: a new row after :209 (B87): "`CRCBase._crc()` takes the polynomial its caller already checked, and `add()`/`add_into()` no longer wrap `pack_into` in an unreachable catch \| No emitted byte changes" (Class B, `applied-python`). |
| 23 | SRC_CORE.131 | src/asy_crc_checks.py (+ tests/test_asy_crc_checks.py) | to write | :24-28 sets `_num_bytes` before validating the polynomial, so an out-of-range poly still reports `length() == num_bytes`. Fix: compute the mask, check the poly against it, then set every width field from the result. Add one test per width. **[UART]**: no valid config changes, since a TOML can select only `none` or `crc16`. I propose a Class B row B88 (agent, 2026-10-21; the changelog logs Python-internal changes too). |
| 24 | SRC_NET.164 | src/asy_uart_comm.py **[UART: comment only]** | part landed | Already done: sync `_note_valid_frame` :629-632, its call sites, owner tag :1021. **Left**: at :1007 `if buf is None:`, add "# Unreachable: _prepare_tx() returned False if the TX buffer were missing - kept to narrow the Optional for the type checker." (the premise holds at :664-666). |
| 25 | SRC_NET.166 | same **[UART: comment only]** | part landed | **Left**: comment at :758 `if err or rx is None:` covering the `rx` half (the premise holds: `_read_frame` returns False on a missing RX buffer, :723-725). Comment at :783 `if not fits:`; see section 4, item 10. |
| 26 | SRC_NET.167 | same **[UART: comment only]** | part landed | Already done: gate first :1104, shared-tail comment :839, stream comment :1191, B71 at changelog:194. **Left**: complete the inline comment at :1110 with "- kept to narrow the Optional for the type checker." |
| 27 | SRC_NET.168 | same **[UART: comment only]** | part landed | Already done: `exp` :578, `_note_valid_frame()` :586. **Left**: comment at :575 `if rx is None:`. Add the same comment at :712 (`_read_answer_header`), which A.U35.47 does not list; this follows D.10 (agent, 2026-10-21). |
| 28 | TEST_HELP.026 | tests/_bus_hazard_catalog.py | part landed | Already done: public reserved ranges :40-44, `reset_id` :55, BMP constant :103, ERR_REG and EVENT seeding :114-122, `exercise_raises` :171, heater-off :269, altitude :355. **Left (U35, item 5)**: `releases_bus_mid_read` (True for sgp40) and `default_address` on `I2CHazardAdapter` (:158-180). U36's item 8 is open: comment :343-344. |
| 29 | TEST_HELP.027 | same | part landed | Already done: every writer :489-497, both Skips :494/:590, SPI catalog :401-407, recovery scenario :721, sweep :740-763, C.8 tag :585. **Left (item 5)**: `sibling_inside_window()`; the `switches >= len(occupants)` floor at :456-457 should apply only to buses with no flagged occupant. |
| 30 | TEST_HELP.052 | tests/_fast_sleep.py | landed | `FastAsyncSleep` :26-35. Its parameter is `clock`, not a per-caller count. |
| 31 | TEST_HELP.064 | tests/_ticks30.py | landed | :20-38. |
| 32 | TEST_HELP.065 | new driven clock + self-test | to write; name conflict | See section 4, item 7. |
| 33 | TEST_HELP.011 | tests/machine.py | landed | :1369-1509: WDT bound :1369, `feed_times`, the `Simulated*` classes, `mem_backup`, `power_on`, both registers :1429-1430. |
| 34 | SPEC.111 | SPECIFICATION.md | part landed | The watchdog entry is at :7470-7481 and its shutdown-ownership part has landed. **Left (U35)**: A.U35.30's sentence naming the planted-failure scenarios, which do not exist yet. Also absent is item 10's shared-codec sentence ("Each driver constructs its own codec"); the packet gives it to "U35/U36", and I propose U35. |
| 35 | TEST_HELP.022 | tests/_fram_chip_fake.py | part landed | Already done: `drop_next_wren` :42, `write_transactions` :61 (A.U35.28's counter), page citations, sizes as `SIZE` plus the subclass at :157. **Left**: `cut_after_bytes`/`bytes_written` (a local copy exists at test_asy_system_service.py:1043-1079), the opcode `match=` key, ":100 '1.29'" → "v1.29.0", and `TEST_API`. |
| 36 | TEST_HELP.067 | new tests/_cancel_sweep.py | to write | Absent. It depends on step 38, which has landed. |
| 37 | SPEC.064 | SPECIFICATION.md | part landed | Already done: lock table :3770, :3756-3757, :3811, cancellation paragraph :3836-3843. **Left (U35, item 5)**: "A test sweep cancels every such path at each of its awaits (agent)." Also left from U16: :3794 "(owner's decision, 2026-09-18)" → "(owner, 2026-09-18)". |
| 38 | TEST_HELP.043 | tests/_async_harness.py | landed | `cur_task` refusal :91, tracking :95-96, `cancel` :223, `cancel_all` :234, `run` :248, `run_timed` :253, `CoroutineOf` :22. |
| 39 | TEST_UNIT.016 | tests/test_asy_bmp3xx_driver.py | to write | The test is at :1410-1435 and only counts acquires; its comment :1415-1417 says the interleaving "can't be reproduced". Fold (1) has landed at :1399. |
| 40 | TEST_UNIT.028 | tests/test_asy_dns_client.py | part landed | Tags :44-54, constructed asserts :410/:542/:552/:584/:594, mask comment :430, :503, :545, :678 and :737 have landed. **Left**: `test_cancelling_a_resolve_at_each_await_leaves_no_socket_open`, which needs step 36. |
| 41 | TEST_UNIT.034 | tests/test_asy_fram_driver.py | part landed | The lost-flag assertions have landed. **Left**: the lock-busy test (:1010-1048) runs `_RecordingWaitFor` on a real 1 ms bound; it should run on the driven clock: `advance(999)` not done, then `advance(1)` gives False. |
| 42 | TEST_UNIT.043 | tests/test_asy_fram_manager.py | landed | Order :970/:989/:1077/:1769; :2364, :2373; negative age :3003; the four removed tests are gone. |
| 43 | TEST_UNIT.079 | tests/test_asy_neopixel_driver.py (970b63b) | part landed | :228/:268, :300, :941, :1203, :1213 have landed. **Left (A.U35.13)**: replace the local `_YieldOnlyAsyncio` (:59) and `_DrivenClock` (:92) with the shared clock. |
| 44 | TEST_UNIT.080 | same | part landed | :545-556, :580, :675, :708, :733, :784, :814 and :898 have landed. **Left**: real sleeps at :497 `sleep(1.5)` and :512 `sleep(1.1)` move to `advance`; :628 `>= 30` becomes `== 31`. |
| 45 | TEST_UNIT.082 | tests/test_asy_notification_service.py **[TAG]** | part landed | Imports :7-19, `ValueRef` :148, `_FakeValue` :70 and shared `FakeTime` have landed. **Left**: `_make_coordinator` (:129, 64 uses) becomes `_make_service` (drop `debug=`, call `setup()`); `_one_cycle` real `sleep(wait)` at :166, and :1024/:1220/:1254, move to driven time. Decide per literal which tags at :35-42 and :152 go with their literals (Part N rows withdrawn, A.U35.13 Blast); `_MAX_ROUNDS` stays as the hang guard. |

## 2. Carried actions
| Action | Steps | State |
|---|---|---|
| A.U35.40 | 1, 2, 3, 4 | Parts (1) and (4) are left (steps 3 and 4). (2) and (3) have landed. |
| A.U35.50 | 5, 7 | This is the four-tier matrix in `audit/b3/conformance.md`; `audit/b3/` does not exist yet. It goes with the B3 working files (A.U35.01). |
| A.U35.21 | 6, 7, 8, 10, 11 | (1), (2) and the E.6.6 row have landed. Left: (3) the mock deletion, the README line and the C.8 sentence. |
| A.U35.09 | 7 | The L2 scenarios go in `scripts/_digital_twin_scenarios.py` plus the matrix row. They are outside this block's files; P2 places them with the twin lanes. |
| A.U35.43 | 9, 14 | Code and test have landed. The SPEC sentence is left (step 9). |
| A.U35.45 | 12, 13 | Landed. |
| A.U22.02 | 13 | Landed. |
| A.U35.47 | 15, 16, 24-27 | The FRAM half has landed. The UART half (5 comments + :712) is left. |
| A.U35.55 | 16, 17, 42 | Landed. There was no catalog row to retire. |
| A.U35.42 | 18, 19 | The FRAM half has landed. **The math_helpers half is left**: there are no stand-in tests in `tests/test_math_helpers.py` (P2: grep ArithmeticError there). |
| A.U35.44 | 20, 21, 22 | All left. |
| A.U35.16, A.U35.19 | 28, 29 | Left: the hand-written floors at test_bus_hazard_multi_device.py:130-131/:173-174, and the reserved test :689-691 still using constants. |
| A.U35.10 | 30, 31, 32 | Left: step 32. |
| A.U35.30 | 33, 34 | Left: the four scenarios in `tests/_sensortask_scenarios.py` and the G.2 sentence. |
| A.U35.28 | 35 | Its write counter has landed. The load ledger and scenario sit outside this block's files. |
| A.U35.48 | 36, 37, 38, 40 | Helper, SPEC sentence and DNS sweep are left. |
| A.U35.11 | 39 | Left. |
| A.U35.13 | 43, 44, 45 | Left. |

## 3. Open findings in this block's files (REGISTER rows too)
- **OF-02** (open). bus_topology…py:114-120 `except OSError: pass`: a NAKed general call is swallowed. Joins step 5. Fix: count sent and NAKed broadcasts as facts (as bmp3xx_alone…py:76-78 does), and have the host test (flash/test_bus_concurrency.py:232-245) require at least one sent.
- **OF-05** (open). _shared/bus_reader_loops.py:79-81: `read_scd30` returns None after any `read_measurement()`. Joins step 5. Fix: range-check against `BENCH["bounds"]`, as the BMP reader at :89-93 does. The shared reader feeds other scripts too, so re-record the twin record.
- **OF-81** (open). asy_base_classes.py:115-128 `Lockable.__aexit__` swallows `RuntimeError`. Joins step 36: the sweep's lock invariant plus a pin in tests/test_asy_base_classes.py, which a later block holds; P2 joins them. The row asks for a pin, not a product change.
- **OF-167** (open, routed to U35 by M.SRC_CORE.087/.090; steps 15/16 have landed). A blank-chunk read cannot be told from an undriven bus (asy_fram_manager.py:28, :197). P2 to decide. The smaller option is an RDID probe via `verify_present()` on a blank read; a non-zero blank marker changes the FRAM layout and needs a migration. It must be seen failing first against the twin's undriven level (digital_twin/_fram_chip.py:266-267).
- **OF-60** (open, C R2 H17). Its read-path probe option sits with these steps. Not done (agent, 2026-10-21): the silicon latency is not measured yet; it is the same decision as OF-167.
- **OF-70** (open, C R2 H37). A comm-side cause string only if the bench shows it is needed. Parked as hardware; the bench session runs after U35 (REGISTER:722).
- **OF-225** (open). The config flush in asy_config_manager.py is one non-yielding stretch. Chunking it re-derives J.6's `uart.rx_ring_floor`, a local construction refusal (B68), not the wire. It is not on step 14's sites; give it to the config-manager lane (P1b step 82 holds the file).
- **OF-232** stays with U37: its source module has no U35 edit; only its test is touched (step 45).
- **REGISTER:336**: the `_crc()` guard was left for U35 → step 20.
- **REGISTER:476**: U15 lane D 19, the BMP3XX broadcast sentence → step 10.
- **REGISTER:233**: local stand-ins until the shared helpers land → steps 32 and 43-45.
- **REGISTER:691/:722**: firmware is final at U35's end. The firmware edits in this block are steps 20, 21, 23 (asy_crc_checks) and 24-27 (comments in asy_uart_comm). Added comment lines shift the line tables in the frozen bytecode; behaviour is unchanged.

## 4. Packet vs code
1. **Step 1**: the save is `evidence.save_text(f"errcount-{reason}.json", body…)`, the verbatim body, not `save_json`. The import is `from tests._error_codes import code` after appending the repo root (:15-16), not an append of `tests/`. Both forms work.
2. **Torn-write codes.** In `699836e` (`_set_check_sb`, err=30), E31 is "Read status byte is not idle but X", which is today's E46 `FRAM_STATUS_BYTE`. It is **not** the write failure (that is E102 `FRAM_STATUS_WRITE`, HEAD's E32). HEAD's W71 and W72 ("Invalid data in block 0/1") are both today's W63 `FRAM_BLOCK_INVALID` (asy_fram_manager.py:213-241). So the allowed set is one error and one warning, and the comment becomes "the status byte left busy and the block-invalid recovery warning". (agent, 2026-10-21: mapped by message identity to the owner's settled trace.)
3. **README** (steps 4 and 8): the "Real-hardware coverage: sensors, FRAM and the API end to end" heading no longer exists. The F.3 line says four rows, not three.
4. **E.6.6**: the lone-BMP case sits in the combined `flash-only-bus-checks` row (:5522); there is no `bmp3xx-general-call` row.
5. **Changelog numbering**: the tree's B33-B86 are in landing order (for example, tree B64 is the PieceBuffer chunking). U35's rows are therefore B87 and B88.
6. **Catalog**: neither the timestamp-pack code nor the errno-98 ID-check code ever had a row (absent at `43aced0` and now), so steps 17-19 retire nothing.
7. **Name conflict (step 32).** `DrivenTime` already exists at `tests/_fake_time.py:15`. It is a ticks-only clock with no sleep or `wait_for` driving, imported by 9 files (U24 `aa3530f`). The packet wants a second `DrivenTime` in a new `tests/_driven_time.py`. Conservative choice (agent, 2026-10-21; CLAUDE.md "check Part G's catalog first … reuse"; G.2): extend the existing class in place. Its time-only use stays the default; the `asyncio` shim, `advance`, `run_until`, `jump` and the `wait_for`/`wait_for_ms` shims are opt-in. Its models are the neopixel `_YieldOnlyAsyncio` (970b63b:59-105), test_asy_webserver_connections.py:249 and test_asy_webserver_service.py:367. The self-test still goes in `tests/test_driven_time.py`.
8. **Step 35**: sizes come from a class attribute and a subclass, not a `size=` keyword. The power cut is a local subclass in test_asy_system_service.py.
9. **Step 30**: `FastAsyncSleep(clock=…)` is the parameter, not a per-caller count.
10. **Step 25**: the dest bound moved to :776-785 (U17's PieceBuffer). It is still unreachable: `_get_unlocked` refuses a short caller buffer at :279-281, and `_recv_train` bounds the copy by `exp_size` at :763. There is no Optional here, so the comment cannot say "narrow the type". Proposed comment: "kept: it guards the copy into a caller's buffer" (agent, 2026-10-21).
11. **Step 14**: test_asy_config_manager.py:1981 (the non-dict data test) pins `compare_before_write()`'s BAD_ARG. That guard is not among A.U35.43's removed excepts, so the test is kept (agent, 2026-10-21).
12. **Already done by earlier units**: steps 6 and 7 at U26 (`0c0ad52`); 12-19 at U11/U16; 33 and 38 at U24; 42 at U16.
13. **Not determinable read-only**:
    - The H29 and H68 results (bench).
    - Whether driven frame counts equal `_YieldOnlyAsyncio`'s; running the neopixel and notification files at both GC stages settles it.
    - Which notification tags lose their literal; settled at the edit.
    - Whether `tests/test_math_helpers.py` already has stand-in tests; a grep settles it.

## 5. Files (current names → steps)
- tests_hardware/error_log_helpers.py: 1, 2
- tests_hardware/bench/test_end_to_end_timing.py: 3
- tests_hardware/README.md: 4, 8
- tests_hardware/device_scripts/bus_topology_autodetect_and_hazard_sweep.py and device_scripts/_shared/bus_reader_loops.py: 5 (OF-02/OF-05)
- tests_hardware/twin_record.json (re-record): 3, 5
- tests/test_bus_hazard_multi_device.py: 6, 28/29 (A.U35.16, A.U35.19)
- SPECIFICATION.md: 9, 10, 34, 37 (11 and 13 check-only)
- src/asy_crc_checks.py and tests/test_asy_crc_checks.py: 20, 21, 23
- UART_C_PORT_CHANGELOG.md: 22 (and 23's row)
- src/asy_uart_comm.py: 24-27
- tests/_bus_hazard_catalog.py: 28, 29
- tests/_fake_time.py (+ new tests/test_driven_time.py): 32
- tests/_fram_chip_fake.py: 35
- tests/_cancel_sweep.py (new): 36
- tests/test_asy_bmp3xx_driver.py: 39
- tests/test_asy_dns_client.py: 40
- tests/test_asy_fram_driver.py: 41
- tests/test_asy_neopixel_driver.py (base 970b63b): 43, 44
- tests/test_asy_notification_service.py: 45
- tests/_sensortask_scenarios.py: 34 (A.U35.30)
- tests/test_math_helpers.py: 18/19 (A.U35.42)
- No U35 edit needed (landed): src/asy_base_classes.py, src/asy_config_manager.py, src/asy_fram_manager.py, src/asy_fram_driver.py, buildgen/error_catalog.json, tests/machine.py, tests/_async_harness.py, tests/_fast_sleep.py, tests/_ticks30.py, tests/test_asy_fram_manager.py, the flash test and the lone-BMP script.
