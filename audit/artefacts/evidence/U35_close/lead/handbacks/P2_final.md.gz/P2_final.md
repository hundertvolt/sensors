# U35 plan, block P2: cut, waves, rulings, risks, blocks (agent, 2026-10-21; read-only at 1dd6dd5)

This block used about 25 tool calls. All line numbers are at `1dd6dd5` in `S/wt-u33plan`. Nothing in the tree was edited. Helper scripts are in `S/u35/plan_scratch/p2/`:
- `of.py`: the open-findings rows routed to U35;
- `bt.py`: base times across the earlier units;
- `readers.py`: the tests_scripts readers per lane. Rerun it as `python3 -I readers.py S/wt-u33plan`.

### P2.1 Findings that change the cut (beyond P1)
- **Tags and Part N rows are paired across files.** `tests_scripts/test_tunables_register.py:250` fails on a tag that has no Part N row, and on a row that has no tag. Lanes change tags, but SPEC is D's file:
  - step 48 withdraws `l1.asy_notification_service_override_bound_ms`;
  - step 76 adds `l1.bus_fault_isolation_bound_s = 5`;
  - steps 114, 125 (f), 125 (i) and 148 may add tags.
  - Handled by R-17.
- **The explicit-`Any` residue is tied to four config files.** Its lines are in `pyproject.toml` (ANN401 entries :261-276, baseline :417-433), `digital_twin/typecheck.ini:32-40`, `host_typecheck.ini:43-52` and `tests_scripts/test_mypy_any_baseline.py:16-34` (`_RESIDUAL`).
  - The "same commit" rule ties each module to those lines. Five of the 13 modules also carry U35 steps: `_bus_hazard_catalog` (28, 29), `test_bus_hazard_multi_device` (6, 73, 74, 76, 77), `_sensortask_scenarios` (114), `test_asy_uart_comm` (59) and `test_asy_uart_driver` (60, 61).
  - So lane Y holds the config files, the bus family and the scenarios. The two UART files are handed from lane U to Y (R-16).
  - `pyproject.toml` and both inis are not in U35's work-order files (U36 and U37 hold them). The brief and U34 R-2 route these removals here; logged (R-15).
- **The fifth step-2 dependency.** `asy_crc_checks` is imported by `src/asy_fram_manager.py`, `asy_framing_codecs.py`, `asy_print_log.py`, `asy_scd30_driver.py`, `asy_sgp40_driver.py`, `asy_uart_driver.py` and by `buildgen/buildspec.py` and `codegen.py`. Steps 20, 21 and 23 therefore reach every device. Only invalid polynomials change behaviour.
- **Every device has FRAM.** All six `devices/*.toml` wire `driver = "fram"`, so OF-167 and OF-225 reach every device.
- **OF-225 needs no extra copy.** The config flush already serialises before the open (`src/asy_config_manager.py:399`, `:584`), so chunking adds no whole-document copy.
- **DrivenTime importers.** `DrivenTime` (`tests/_fake_time.py:15-37`) is imported by 9 files. P1b's count of 8 left out `tests/test_shared_helpers.py`, whose `:168-300` self-tests the ticks-only part.
- **OF-233's sixth site is not U35's.** FX8 found the same hazard at `tests/test_ticks_rollover.py:223-229`. In work_order.json that file is U37's, and it is outside OF-233's five files.
- **OF-32's test file.** `tests/test_digital_twin_machine.py` is U36's next file. U35's `tests` entry covers it, and OF-32's seen-failing test lives there.
- **Runner hash.** `runner_sha256` covers only `run_device_script.py` and `twin_board.py`. T's runner edits do not make the twin record stale; H1's comment citation in `run_device_script.py` does (the lead re-records anyway).
- **OF-226's row** still names U33 (`audit/sweeps/open_findings.md:234`). The brief routes it here, so the lead re-points the row.

### P2.2 The cut (one owner per file at a time; at most five agents at once)

The base is U34's close head (`1dd6dd5`, unless U34's squash changes the tree; the lead sets it). Times are "base to measure" unless they come from `S/u32/base_times.tsv` (written "U32 a/b" = seconds at -1/32768). Earlier units' figures are given for balance only.

**Lane C: core time and cancel sweeps**
- **Files:**
  - tests/_fake_time.py
  - tests/test_driven_time.py (new)
  - tests/_cancel_sweep.py (new)
  - tests/_ntp_frames.py
  - tests/test_shared_helpers.py
  - test_asy_{dns_client, ntp_client, udp_socket, webserver_connections, wifi_service, captive_dns, base_classes, bmp3xx_driver, isl29125_driver, scd30_driver, fram_driver}.py
  - a guard file, only if R-28's guard can be made deterministic.
- **Steps written:** 32 and 97 (<CORE>), 36 (<SWEEP>), 57, 40, 55, 56, 64, 65, 66, 67, 71, 79, 39, 41, 52, 58.
- **Steps checked:** 30, 31, 38, 50, 51, 54, 63, 68, 69 (read :1593-1694), 70, 72, 115, 117.
- **Findings:** OF-81 (R-11), OF-211 (R-28).
- **Size:** about 700 lines in 17 files.
- **Runs, both stages, all base to measure.** Earlier figures: ntp 23.9/25.6 (U30), captive 25.6/25.6 (U30), wifi 24.4/24.7 (U31), scd30 22.1/28.9 (U31), bmp3xx 13.7/13.8 (U31), udp 7.2/7.2 (U31), isl 2.6/3.5 (U30), webserver_connections 1.2/1.3 (U31), base_classes 0.9/0.5 (U31), dns 0.8/0.8 (U30). fram_driver and shared_helpers have no earlier figure; test_driven_time is new (after-time only).
- **Readers:** import_placement, microtest, radio_shape_corpus, plus the repo-wide scans of the common brief.
- **Seen failing first:**
  - the shim self-test bitten by planted off-by-ones in `advance` (a sleeper due at n+1 must stay parked), `run_until`, `jump` and `wait_for_ms`;
  - <SWEEP> names a planted path that leaks a socket or leaves a lock unbalanced on cancel;
  - 56: `assert await server.serve_once(reply) is True` fails against today's `-> None` (`tests/_ntp_frames.py:36`);
  - 41: `advance(999)` not done, `advance(1)` gives False, bitten by a bound 1 ms short;
  - 39: the BMP interleaving reproduced on a planted unlocked read;
  - each sweep (40, 55, 65, 67, 71, 79) fails on a planted missing cleanup;
  - the OF-81 pin fails on a planted double release.
- **Depends on:** nothing. C publishes <CORE> first, then <SWEEP>.

**Lane N: notification and neopixel driven time (OF-233)**
- **Files:**
  - tests/test_asy_notification_service.py
  - tests/test_asy_neopixel_driver.py (on 970b63b)
  - tests/test_notification_{neopixel, scd30, sgp40, scd30_sgp40}_integration.py
  - tests/test_neopixel_wifi_integration.py
  - tests/test_digital_twin_network_neopixel.py
- **Steps written:** 43, 44, 45, 46, 47, 48 (tag withdrawn), 49, 53, 87, 88, 89, 90, 99; 86's `setup()` calls only (R-3).
- **Findings:** OF-233 (R-13).
- **Size:** about 400 lines in 8 files.
- **Runs:**
  - neopixel U32 9.56/9.55 (FX8's after-times 7.25/7.29);
  - the rest base to measure. Earlier (U31): notification service 19.0/19.1, network_neopixel 15.6/15.6, notification_neopixel 6.4/6.4, notification_scd30 4.5/4.5, scd30_sgp40 4.2/4.2, sgp40 2.9/3.2, neopixel_wifi 2.7/2.8.
- **Readers:** import_placement, ticks_wrap_scan, tunables_register.
- **Seen failing first:**
  - every converted assertion bitten by a planted driver, at both stages (FX8's method: no restore, the lock ignored, t truncated);
  - 44: `>= 30` becomes `== 31`;
  - 48: the bound read through `src_int` (:1280).
- **Depends on:** <CORE>; <PARTN> merged before N2's reader run.

**Lane U: UART tests**
- **Files:**
  - tests/test_asy_uart_comm.py and tests/test_asy_uart_driver.py, until <HANDOVER-UART>
  - tests/test_asy_uart_link_driver.py
  - tests/test_digital_twin_uart_link.py
  - tests/test_uart_comm_hazard.py
- **Steps:** 59, 60, 61 (U1); 62, 100, 148, plus the plant evidence for 144 (U2).
- **Findings:** none worked (R-12).
- **Size:** about 200 lines.
- **Runs:**
  - U32: uart_comm 61.39/62.22, link_driver 2.35/2.43, twin uart_link 55.35/59.39, hazard 104.88/108.69, cancel_sweep 40.17/40.10 (reader);
  - uart_driver base to measure (U30 5.94/9.80).
- **Readers:** import_placement, mypy_any_baseline, suppression_form, uart_changelog.
- **Seen failing first:**
  - each sweep on a planted missing cleanup;
  - 60's Event (cancel in `finally`) on a planted leak;
  - 100's 140-byte `uart_set(0x02, …)` with a planted drop;
  - 148: the 20 ms and 100 ms plants, made in a throwaway worktree, turn the `PollRoundClock` hammers (`tests/_uart_comm_harness.py:122-158`) red. If they do not, U2 adds a bound test and the tag `l1.uart_comm_hazard_clean_transaction_virtual_ms`, relayed to D.
- **Depends on:** <SWEEP>.

**Lane P: product (`src/`) and persistence**
- **Files:**
  - src/asy_crc_checks.py, tests/test_asy_crc_checks.py
  - UART_C_PORT_CHANGELOG.md, src/asy_uart_comm.py
  - tests/test_math_helpers.py
  - src/asy_fram_manager.py, tests/test_asy_fram_manager.py, tests/_fram_chip_fake.py
  - tests/test_asy_system_service.py, tests/test_digital_twin_fram.py
  - src/asy_config_manager.py, tests/test_asy_config_manager.py
  - src/asy_print_log.py, tests/test_asy_print_log.py
- **Steps written:** 20, 21, 23 then 85, 22 (B87 and B88), 24-27 plus the :712 comment, 119, 35 (the copy at test_asy_system_service.py:1043-1079 swapped for the shared fake).
- **Steps checked:** 12-19, 42, 80-84, 93 (read :827-900), 94-96, 113.
- **Findings:** OF-167 and OF-60's read-path half (R-8), OF-225 (R-9), OF-221 (R-10), OF-184 (R-12).
- **Size:** about 400 lines.
- **Runs:**
  - U32: system_service 24.92/26.40, twin_fram 0.58/0.69, ntp_fram_system (reader) 7.63/7.68, twin integration[dev] 22.95/23.65 as the product smoke;
  - base to measure: crc, math (U28 0.02/0.03), fram_manager, config_manager (U30 0.20/0.28), print_log (U30 0.31/0.56).
- **Readers:** api_reference, build_firmware, buildgen_{driver_registry, error_contract, frozen_modules, generate, limits, source_agreement, validate}, code_conventions, config_schemas, counter_steps, device_script_config_schemas, digital_twin_ci_suite_errcount, digital_twin_scenarios, exception_handler_contract, fake_surface_conformance, fatal_report_sites, fault_or_warning_never_both, fram_chunk_crc_sites, fram_chunk_owner_sites, import_graph, import_placement, js_api_mirrors, lint_ceilings, memory_catalog, microtest, persistence_write_marker_completeness, readiness_gates, result_words, setter_contract, stored_config_golden, suppression_form, task_tops, timing_budget, uart_changelog, watchdog_feed_sites; also lock_order (R-8).
- **Seen failing first:**
  - 23 and 85: `CRCBase(1, 0x1FF, ">B")` still reports `length()` 1 (src/asy_crc_checks.py:24-28, :155-158); one case per width plus the pass-through case;
  - 119: the stand-in `ArithmeticError` cases fail with the except narrowed;
  - OF-167: the twin's undriven read (`digital_twin/_fram_chip.py:266-267`) and the L1 fake read as blank (False), where the test expects lost;
  - OF-225: a stalling fake file exceeds a loop-stretch bound set near one erase;
  - OF-221: the two-overlapping-resets case.
  - 20 and 21 are dead-code removals: the existing tests stay green and the E.5.1 register records the change.
- **Depends on:** nothing. The mpy-cross byte compare of every `src/` file it touches (U34 precedent).

**Lane T: twin runner, harness, CI suite, twin README**
- **Files:**
  - scripts/_digital_twin_ci_suite.py, scripts/_digital_twin_scenarios.py, scripts/_twin_process.py, scripts/_check_gc_collect_sites.py
  - digital_twin/run_generic_integration.py, digital_twin/README.md
  - tests/test_digital_twin_sensortask_integration.py
  - tests_scripts/test_twin_runner_test_flags.py, test_digital_twin_ci_suite_soak.py, test_digital_twin_ci_suite_errcount.py, test_digital_twin_generated_boot.py, test_gc_collect_sites.py
- **Steps written:** 151, 152, 154 (T1); 118, 157 (1)-(3), 160, 164, 166 (T2); 125, 149, 124, 155 harness (T3); 157 (4), 165, 167, 169, 170, 171 (T4).
- **Steps checked:** 109, 156, 168.
- **Findings:** OF-215 stage 3 (R-27), OF-149 and OF-188 (R-26).
- **Size:** about 660 lines.
- **Runs:**
  - twin integration per device (U32 a/b): arzi 119.08/118.64, dev 22.95/23.65, grkizi 21.65/22.05, klkizi 21.69/21.89, schlafzi 21.64/21.66, wozi 22.14/22.31;
  - `run_digital_twin_ci.sh` for dev and arzi at both stages, base to measure. All six devices run at the lead's gate.
- **Readers:** bench_restores_serving, citations, conftest, device_script_bench_facts, device_tomls, digital_twin_ci_suite_{ceiling, errcount, matrix, soak, state}, digital_twin_generated_boot, digital_twin_scenarios, exception_handler_contract, gc_collect_sites, harness_mpremote_retry, import_placement, legacy_paths, level_containment, lint_sh, live_command_device_args, no_variant_literals, persistence_write_marker_completeness, port_bands, request_timeout_ceiling, run_digital_twin_ci_sh, run_unix_port_integration_sh, setup_toolchain_env, stripped_image_boots, test_sh, twin_board, twin_entry_point_order, twin_never_needs_tests_on_its_path, twin_process_js_spawn, twin_process_spawn, twin_runner_test_flags, twin_wiring_contract.
- **Seen failing first:**
  - `fram_writes*` parser cases;
  - the flag table, until `--test-watchdog-fault` and `WDT_AT_FAULT` exist;
  - a planted W fails Run 1, and the reformat relaunch logs exactly one W `CONFIG_LOST`;
  - the backwards-clock fixture (164);
  - a planted excess write rate (160);
  - one W, and one NTP entry, each fail the normal boot (149, 166);
  - a planted public destination fails test 2 (124);
  - the stop-file path (OF-215).
- **Depends on:** nothing for T1; <SHUT> (T1) before T2 and T3; B2's figures before T4.

**Lane H: hardware tier and twin-record script**
- **Files:**
  - tests_hardware/bench/test_end_to_end_timing.py
  - tests_hardware/device_scripts/bus_topology_autodetect_and_hazard_sweep.py, tests_hardware/device_scripts/_shared/bus_reader_loops.py
  - tests_hardware/flash/test_bus_concurrency.py
  - tests_hardware/bench/test_memory_stress_bench.py, tests_hardware/device_scripts/loop_lag_under_combined_load.py
  - digital_twin/run_device_script.py (comment only)
  - scripts/record_twin_instrument_runs.py, tests_scripts/test_twin_record.py
  - tests_hardware/twin_record.json (H2's shape proof only)
- **Steps written:** 3 (R-7), 5 with OF-02 and OF-05, OF-226 (R-14), 122's citation (R-25), 140 with OF-229 (R-20).
- **Steps checked:** 1, 2, 7, 101, 103, 127, 129-133.
- **Size:** about 150 lines.
- **Runs:** no GC-stage files. `pytest --collect-only tests_hardware`; the twin runs of the changed scripts; the device-script mypy pass; test_twin_record.
- **Readers:** digital_twin_scenarios, exception_handler_contract, level_containment, memory_error_gate_agreement, tests_hardware_persistence_write_gating, twin_record, plus every device_scripts reader (U32 lane T's list).
- **Seen failing first:**
  - the host check requires at least one sent broadcast (flash/test_bus_concurrency.py:232-245), bitten by an all-NAK twin;
  - an out-of-bounds SCD30 reading is caught (bus_reader_loops.py:79-81);
  - OF-229: a sibling test broken in a scratch copy is charged only to its own scripts.
- **Depends on:** nothing.

**Lane Y: typing residue, bus-hazard family, sensortask scenarios**
- **Files:**
  - pyproject.toml, digital_twin/typecheck.ini, host_typecheck.ini, tests_scripts/test_mypy_any_baseline.py
  - tests/machine.py, digital_twin/machine.py, tests/test_digital_twin_machine.py, src/asy_system_service.py
  - tests/test_bus_hazard_generated.py, tests/test_digital_twin_bus_hazard_concurrency.py
  - tests_hardware/conftest.py, tests_hardware/device_scripts/serving_at_default_gc.py, tests_scripts/test_cross_browser_smoke_probe.py
  - tests/_bus_hazard_catalog.py, tests/test_bus_hazard_multi_device.py
  - tests/_sensortask_scenarios.py, tests/test_sensortask.py
  - from <HANDOVER-UART>: tests/test_asy_uart_comm.py and tests/test_asy_uart_driver.py
- **Steps written:** 6, 28, 29, 73, 74, 76 (adds the tag), 77, 114, the residue (R-15), OF-32 (R-30), OF-200 (R-31).
- **Steps checked:** 33, 121, 123 (this run settles whether reset-reachable cases catch `SimulatedRebootError`).
- **Size:** 183 `Any` sites (T1's list) and about 450 lines of step work.
- **Runs:**
  - U32: twin bus hazard 150.15/152.79; test_sensortask per device arzi 36.89/33.50, dev 46.32/53.94, grkizi 28.91/32.62, klkizi 28.40/33.11, schlafzi 28.94/33.24, wozi 32.31/37.63; uart_comm 61.39/62.22;
  - base to measure: bus_hazard_generated (U30 63.6/64.3), bus_hazard_multi (U30 3.3/3.6), twin machine, uart_driver;
  - `scripts/typecheck.sh` after every module commit.
- **Readers:** 77 in all (readers.py). They include pyproject's readers (ci_workflow, config_paths_resolve, host_annotations, lint_ceilings, lint_type_scopes, mypy_any_baseline, no_variant_literals, preview_server, ruff_exemptions_live, script_metadata_pins, suppression_form, tool_pins, typecheck_sh), fake_surface_conformance, twin_fake_catalog, the system-service readers (U32 lane C's list) and the device-script readers.
- **Seen failing first:**
  - OF-32: a twin `ticks_us` driven past 2**29 misreads;
  - 73: a switch planted outside the window is named;
  - 76: a planted `bus_lock` leak;
  - 114: each group bitten by a planted defect (the WDT fed despite a stuck task; a FRAM write storm over its bound).
  - The `Any` removal has no seen-failing case; its proof is the three passes plus ruff_exemptions_live and mypy_any_baseline.
- **Depends on:** <PARTN> (Y2), <CORE> (Y4), <HANDOVER-UART> (Y3).

**Lane D: documents**
- **Files:** SPECIFICATION.md, BACKLOG.md, tests_hardware/README.md.
- **Steps written:** <PARTN> (rows for 48 and 76), 4, 8, 9, 10, 34, 37, 111, 112, 116, 126, 128, 142, 143, 144 (J.7), 145, 146, 147 and 105 (Basis cells), 158, 159 (conditional), 161, 162, 163. Also R-23's I.4(e)(6), R-28's E.1, R-9's J.6, R-8's FRAM sentence, and :3794's actor form.
- **Steps checked:** 11, 13, 110, 135.
- **Readers:** 110 (they are the lead's tier). D3 runs citations, decision_vocabulary, legacy_paths, comment_block_cap, tunables_register, timing_budget, memory_catalog, lock_order and task_inventory.
- **Depends on:** D2 on the integration head plus B1's step-108 run; D3 on B2.

**Lane W: web and tests_scripts hygiene**
- **Files:**
  - js/shell.js, tests_js/shell.test.js (base 970b63b)
  - tests_js/mock-data-compose.test.js, tests_js/live-backend-put-matrix.test.js
  - tests_scripts/test_definitions_js_mirrors.py, test_host_text_encoding.py, test_port_lock.py, test_tool_help.py, _repo_scan.py, test_lint_ceilings.py, test_device_script_config_schemas.py
- **Findings worked:** OF-144, -231, -214, -197, -199, -206, -207, -212 (R-29).
- **Steps checked:** 174-179.
- **Size:** about 250 lines.
- **Runs:** the full web tier in its own network namespace, never beside a MicroPython tier; test_citations (U34 13.3 s; OF-206 must bring it under 10 s).
- **Readers:** the 28 that readers.py lists, plus the repo-wide scans.
- **Seen failing first:**
  - a reflash between page load and the first watch is seen;
  - a planted format the compose branches miss is named;
  - a new put-matrix skip fails until listed;
  - a planted non-literal `encoding=` fails;
  - a stray ruff ahead on PATH fails;
  - a skipped schema site is named.
- **Depends on:** nothing.

**Lane B: B3 records and measurements**
- **Files:** audit/b3/* (new; A.U35.01 opens the directory), audit/sweeps/ticks30_build.sh (new), scripts/test.sh.
- **Steps written:** 102 (PROC.022), 104, 137, 138, 141, 153, 108 (B1); timing.md (A.U35.23), load.md (160), 107 and 120's re-measure, 136's bite, gate and wear procedures, 156 (A.U35.05), the Run 11 calibration and l0-l2 basis measurements (B2).
- **Steps checked:** 106, 109; 102's SCR.024 (lint.sh, run at the gate).
- **Readers:** _devices, build_firmware, ci_workflow, conftest, coverage_runner, device_script_fram_regions, device_tomls, digital_twin_boot_contiguity, hardware_runners, level_containment, memory_error_gate_agreement, micropython_overrides, microtest, port_lock, render_coverage_anchors, retry_counts, setup_toolchain_env, summary_block, test_sh, threshold_runner, tool_help, twin_record.
- **Seen failing first:**
  - the 2**30 build trips OF-32 at base and passes after Y's fix;
  - each memory gate turns red on a planted `MemoryError` in a throwaway worktree, its message worded clear of both markers.
- **Depends on:** B1 on nothing; B2 on the lead's W6 gate.

**Lead:** the twin-record re-record (134, 136, 172), the tests_scripts tier, the OF and REGISTER rows, and CI after the push (OF-71's CI times).

### P2.3 Waves and order (at most 5 blocks at once)

**Waves:**
- **W0 (lead):** set the base, prove the file sets disjoint (handovers included), and open `S/u35/relay.md` with sections C, N, U, P, T, H, Y, D, W, B.
- **W1:** C1, D1, P1, T1, Y1.
- **W2:** C2, N1, U1, Y2, T2.
- **W3:** C3, N2, U2, Y3, B1.
- **W4:** N3, P2, T3, Y4, H1.
- **W5:** P3, Y5, H2, W1, W2.
- **W6 (lead):** merge C, N, U, P, T1-T3, Y, H, W, D1 and B1 into `audit/u35-int`; rebuild; re-record the twin record at both stages; run the full gate at both stages (unit tier, twin per device, coverage, web tier). Its per-file times feed timing.md.
- **W7:** B2, alone on the host for the timing runs (CHECKLIST 12).
- **W8:** T4 and D2.
- **W9:** D3.
- **W10 (lead):** merge; rerun Run 11 per device at both stages, test_test_sh, then the tests_scripts tier once; push; watch CI. Then stop for the owner's order of hardware session 1 and the U36/U37 document work (L-5).

**Dependencies, each with its reason:**
- **Step 32 (<CORE>) before** 41, 43-49, 53, 64, 66, 87-90, 99, 114 and 143's "time at L1 is driven". They need virtual sleeps and `wait_for`; today `DrivenTime` swaps only `time` (`tests/_fake_time.py:24-37`).
- **Step 36 (<SWEEP>) before** 40, 55, 59, 61, 62, 65, 67, 71, 79 and OF-81's pin. They are all sweeps over that helper.
- **Step 57 before 56.** `serve_once` returns `None` today (`tests/_ntp_frames.py:36`).
- **Step 108 before 112.** The sentence reports that run (REGISTER.md:414).
- **Step 151 before 125 (h), 160 and 166.** They read the `fram_writes*` fields, which are absent from `_shutdown_line()` (runner :458-467).
- **Step 152 before 125 (f) and 171.** The flag must exist first.
- **A.U35.01 (B1's first commit) before 137, 138, 141 and 153.** `audit/b3/` is absent.
- **M.SRC_CORE.131 (23) before 85's new cases.** They fail until the width fix lands.
- **Prerequisites for later SPEC text:**
  - 143 before 128 (E.2.3 must exist);
  - 125 (g) before 126 (the BACKLOG bullet goes once the recombination exists);
  - U2's plant before 144's J.7 sentence;
  - Y4's scenarios before 34;
  - C's sweeps before 37.
- **Every `src/`, device-script, flash or bench file and runner edit before the W6 re-record.**
- **B2 before 107, 146, 147, 157 (4), 161 (3), 162 and 163.** They need measured values.
- **P3 before J.6 (R-9); P2 before the FRAM sentence (R-8).**

**First commits other lanes need:**
- <CORE> (C1's first): the shim and test_driven_time.
- <SWEEP> (C1's second).
- <PARTN> (D1's first).
- <SHUT> (T1): the runner and `ShutdownLine`.
- <T30> (B1): ticks30_build.sh, for Y's OF-32 confirmation.
- <HANDOVER-UART> (U1's last): relay line `<HANDOVER-UART> <hash>`; U never edits those two files again.

### P2.4 Rulings draft (agent, 2026-10-21)

**Process rulings**
- **R-1 The cut** as in P2.2.
- **R-16 Handover.** test_asy_uart_comm.py and test_asy_uart_driver.py pass from U to Y at U1's end. Only one owner holds a file at any time.
- **R-17 <PARTN>.** D1 writes the Part N rows for the tag changes known now (48 and 76). A tag decided during execution is relayed as `<TAG name value basis>`. Until the lead merges D's row, that lane's tunables_register run is red on that one named row only (test_tunables_register.py:250).
- **R-21 B3 measurement is lane B, not the lead's.**
  - B1 writes the B3 documents from the records: intent, levels, conformance (from `audit/actions/SUPP_recovery.md`), queue_c, raising, and the 2**30 build.
  - B2 measures on the integration head: timing.md from the gate logs at both stages, load.md, the Run 11 calibration and the l0-l2 Basis values.
  - The lead's gate is B's input; the B documents are writing work.
- **R-33 Check-only steps** are verified on the base by their lane's first block and again at the gate.

**Rulings applying L-1 to L-4**
- **R-2 (L-1).** <CORE> extends `DrivenTime` in place. Its opt-in parts are tested in test_driven_time.py. The ticks-only cases at test_shared_helpers.py:269-300 stay, because they test the default, which is unchanged. N1 and C2 delete the local `_YieldOnlyAsyncio`/`_DrivenClock` copies (neopixel 970b63b:59-105; webserver connections :968).
- **R-3 Step 86.** Write the `setup()` calls. `_run_until` (:45-52) stays: it reads no clock. Step 94 is check-only (test_asy_system_service.py:121-123 uses the default).
- **R-4 (L-2).** Applies to 118, 149, 166 and 169: no E and no W entry, read before `l2.scenario_shared_boot_deadline_s`. 166's NTPSynced case targets `_wait_for_ntp_sync` (suite :1713). Run files go under `ctx.logs_dir/"runs"`. This settles every NTP conflicts row (P1c 118; P1d 149, 166, 169).
- **R-5 (L-3).** 157 and 170 keep the tree's wire-log wording.
- **R-6 (L-4).**
  - 128 lands in D2 after 143.
  - The non-dict test at test_asy_config_manager.py:1981 stays (settles P1b's 81/83 conflict).
  - Names follow the tree: `neopixel_freq` (src/asy_neopixel_driver.py:83), `UARTComm`, `FakeNtpServer(port, *, poll_ms, poll_tries)` (tests/_ntp_frames.py:22).
  - Step 53's `debug=4` (:55) stays while the constructor takes it.

**R-7 Torn-write mapping (step 3)**
- `allowed_errors=(code("E", "FRAM_STATUS_BYTE"),)` and `allowed_warnings=(code("W", "FRAM_BLOCK_INVALID"),)`. Not `FRAM_STATUS_WRITE`.
- Settled by message identity: `699836e` E31 "Read status byte is not idle but X" matches the catalog's "a block status byte is neither idle nor uninitialised"; W71/W72 "Invalid data in block 0/1" match "a chunk block held invalid data; it is repaired from the other copy" (buildgen/error_catalog.json).
- Proven on silicon at R3, H68.

**R-8 OF-167 and OF-60's read-path half: the blank chunk against an undriven bus**
- The fix: when a block's status byte reads blank (`_STATUS_UNINIT = const(0x00)`, src/asy_fram_manager.py:28; `_read()` :197), P2 probes with `verify_present()` (RDID; src/asy_fram_driver.py:477-502).
  - If the chip answers, the block is blank, as today.
  - If it does not, the existing lost path and chip watch take over.
- The probe runs after the read has released the SPI lock (lock table, SPEC :3770). Its buffer is preallocated.
- The non-zero blank marker is not taken: it changes the FRAM layout and needs a migration.
- Per device and bus: all six devices, on the FRAM's SPI bus. There is one RDID transaction, and only on a blank read.
- What it closes:
  - a silent chip during a read-only stretch is now found at its first read, not at the next write;
  - a dropped READ opcode with the chip still answering stays covered by L1's wire-trace tests (tests/test_asy_fram_wire_trace.py).
- OF-60's silicon latency stays R2 H17.
- Settled by CLAUDE.md's rule for decisions during execution (conservative, reversible, grounded in sources), reuse-first (G), and MB85RS64V p10. Decided on the owner's behalf and logged for review.

**R-9 OF-225: the config flush in chunks**
- Both sites, :399-401 and :584-586, use one helper: fixed-size slices of the text that is already serialised, with a yield between slices. No `flush()` or `sync` between chunks.
- P confirms littlefs's commit-at-close semantics against v1.29.0's `lib/littlefs` before writing.
- D re-derives J.6 and `uart.rx_ring_floor` from P's relayed figures. dev's configured ring stays as it is, since the floor can only fall. If B68's threshold moves, P adds a Class B changelog row.
- Settled by the finding's own plan and F.3.

**Rulings on the other findings**
- **R-10 OF-221.** Write the test first; fix `src/asy_print_log.py` only if it fails.
- **R-11 OF-81.** A pin, with no product change: <SWEEP>'s lock-balance invariant, plus a pin in test_asy_base_classes.py.
- **R-12 Findings with no code in U35:**
  - OF-70: waits on R2 H37, which comes after U35;
  - OF-184: no code (agent, 2026-10-14); its file changes only under R-15;
  - OF-232: U37; OF-223: U36 (U32 R-16); OF-180: owner question 5; OF-181: waits on R1;
  - OF-150 and OF-71: B2 measures, and the lead reads the CI times from U35's push. Their cause is the product's allocation volume, in no U35 file.
- **R-13 OF-233** is lane N's work. The lead adds test_ticks_rollover.py:223-229 to the row for U37.
- **R-14 OF-226.** The bench loop-lag run gains the twin's HTTP load (scripts/_digital_twin_scenarios.py:1038) and asserts its evidence the way the twin does. U35 only collects it; it runs at R1 (H83).

**R-15 The explicit-`Any` residue**
- 13 modules, each cleared in one commit together with its baseline line, its ANN401 entry and its `_RESIDUAL` row:
  - `_sensortask_scenarios`, `test_asy_uart_comm`, `test_asy_uart_driver`, `_bus_hazard_catalog`, `machine` (tests/), `test_bus_hazard_generated`, `asy_system_service`, `test_bus_hazard_multi_device`;
  - `machine` (twin pass), `test_digital_twin_bus_hazard_concurrency`;
  - `test_cross_browser_smoke_probe`, `conftest`, `serving_at_default_gc`.
- `scripts._hardware_verdict` stays: its one site comes from the bare import at :22, which U34 R-4 sends to U37. `_boot_contiguity_probe` and `_uart_link_contract` are U36's.
- A module that cannot lose its `Any` without a cast or an ignore stays listed with its sites (U34 R-2's form).
- When the twin pass empties, digital_twin/typecheck.ini's :35-36 comment and the clause at :32 go with it.

**R-18 UART: the wire stays untouched (owner, 2026-09-25)**
- Steps 24-27 are comments only, plus the :712 comment (D.10).
- Step 25's comment reads "kept: it guards the copy into a caller's buffer".
- B87 covers steps 20 and 21; B88 covers step 23. Both are Class B.
- Steps 59-62, 100 and 148 are test-only. If a sweep finds a defect, its row goes through P.

**Rulings on placement and smaller points**
- **R-19** 67's sweep goes in test_asy_webserver_connections.py, which holds `_serve()`'s test doubles. 66 swaps that file's clock for <CORE>.
- **R-20 The twin record.**
  - H2 adds the second GC stage (step 140) and the OF-229 fix, and proves the new shape on its branch.
  - The lead re-records once at W6, at both stages, after every input is final (134, 136, 172).
  - B2 reviews every exception and runs the bite, gate and wear checks into conformance.md (A.U35.03, .05, .49, .51).
- **R-22 The Run 11 sampler (157 (3), 163, 165).** B2's sparser-sampling run decides whether the sampler keeps its `gc.collect()`. If no interval gives the same verdict, D2 enters owner question 8 (step 159) and the collect stays (owner, 2026-09-26: the twin's one exception).
- **R-23** I.4(e)(6) states the landed DebugLevel state (REGISTER.md:729; owner, 2026-10-20: "Option 1 is good").
- **R-24 Other agent proposals, accepted:**
  - P1a: the :712 comment; step 34's codec sentence lands in U35 if the tree holds it; B88.
  - P1b: the C.14.2 pointers stay.
  - P1c: 143's hygiene sentences stay where they are; U24's tracer classes are added to E.5.1 (paragraph :5220-5230) inside step 111.
  - P1d: 160's bound is derived as window ÷ 627 ms × 2, stated beside the assertion; the PLW0603 entry (pyproject.toml:309-312) stays; 149 asserts the boot order at the booted level too.
  - Stale-doc rule: :3794's actor form.
- **R-25** H1 adds the missing `machine_wdt.c:43-57` citation to run_device_script.py:122.
- **R-26 OF-149 and OF-188.** T4 runs the twin integration file once per device under build-settrace. No change unless one reproduces.
- **R-27 OF-215 stage 3** is T1's: `shutdown()` (scripts/_twin_process.py:366-388) uses `--stop-file`, with SIGINT as the fallback.
- **R-28 OF-211.** C2 tries to build a deterministic guard. If it cannot, it reruns the held-responder audit over every socket file. D2 states the E.1 rule.
- **R-29** OF-144, -197, -199, -206, -207, -212 (its schema half), -214 and -231 go to lane W (the fallback rule).
- **R-30 OF-32.** Y re-anchors `_epoch_us` (digital_twin/machine.py:900, :930). It is seen failing first in test_digital_twin_machine.py and confirmed on <T30>.
- **R-31 OF-200.** Y5 profiles one device at 32768 first; any fix lands only in a U35 file.
- **R-32** Hardware stays parked: the list is below.
- **R-34 For the owner:** nothing now; one conditional item (R-22).

### P2.5 Risks
- **Every mode:**
  - CRC widths come from the validated polynomial; every valid configuration is byte-identical.
  - The UART wire (dev only) is untouched.
  - The FRAM probe (R-8) runs only on a blank read.
- **STA and AP:** a config-persisting PUT (OF-225) stretches the loop by about one sector erase instead of up to 2129 ms. The UI watch (OF-144) now sees a reflash that happens between page load and its first watch.
- **Silent:** no API, so no runtime flush.
- **Off:** the boot write at :584-586 runs inside the setup batch, which already feeds the watchdog.
- **USB:** a silent FRAM chip prints its lost-chip line at the first blank read, instead of a run of CRC and block-invalid lines.
- **Frozen image:**
  - asy_crc_checks (steps 20, 21, 23);
  - asy_uart_comm (24-27 and :712: line tables only);
  - asy_fram_manager (R-8) and asy_config_manager (R-9);
  - asy_print_log (only if R-10's test is red);
  - asy_system_service (annotations only; mpy-cross is expected to show no change);
  - the frozen website (js/shell.js).
  - Nothing in `ext/` or `buildgen/` changes. Firmware is final at U35's end (REGISTER.md:691/:722), so all of this must land before W6.
- **Memory gates:**
  - all four read zero at -1 and 32768, and the coverage leg too;
  - the shim's sleeper queue is bounded;
  - the sweeps' allocation churn passes at -1 with no `gc.collect()` prop;
  - OF-225 adds no copy;
  - step 157 (3) touches the gc-collect checker row (:68).
- **Timing:**
  - Expected faster: lane N's files, network_neopixel's two 1.0 s windows, and udp :1631.
  - Growth risks:
    - the sweeps (ntp, captive, wifi, uart_comm): driven time and bounded pollers only;
    - test_sensortask per device (114, already above the 10 s bar, OF-200): forty_days by `jump`;
    - 124's `main()` run;
    - Run 1's reformat relaunch: reuse Run 1's state;
    - 148's possible bound test;
    - the re-record: two stages.
  - Any growth over 10 % and 0.5 s, or over 10 s, is made efficient, never by cutting strictness.

### P2.8 Blocks (60-80 calls; no file split across a lane's blocks; each lane's last block runs its complete checks)

**Lane C**
- C1 (W1): <CORE>, then <SWEEP>, then <NTPF> on _fake_time, test_driven_time, _cancel_sweep, _ntp_frames and test_shared_helpers.
- C2: dns, ntp (OF-211), udp, webserver_connections.
- C3: wifi, captive, base_classes (OF-81), bmp3xx, isl, scd30, fram_driver; then C's checks.

**Lane N**
- N1: neopixel (43, 44, 53).
- N2: notification service (45-49, merging <PARTN>).
- N3: the four integration files, neopixel_wifi and network_neopixel; then N's checks.

**Lane U**
- U1: uart_comm and uart_driver (59-61), then <HANDOVER-UART>.
- U2: link_driver, twin uart_link, the hazard plant; then U's checks.

**Lane P**
- P1: crc, the changelog, the uart comments, math.
- P2: fram_manager, the chip fake, the system-service copy swap, twin fram (R-8).
- P3: config_manager (R-9), print_log (R-10); then P's checks with mpy-cross.

**Lane T**
- T1: the runner, _twin_process, test_twin_runner_test_flags.
- T2: the suite and its tests_scripts readers, gc_collect_sites.
- T3: the scenarios, generated_boot, the twin integration file.
- T4: values, README and settrace; then T's checks, the twin CI for dev and arzi at both stages.

**Lane H**
- H1: the tests_hardware edits and run_device_script.
- H2: the record script, test_twin_record and the shape proof; then H's checks.

**Lane Y**
- Y1: the config files plus machine (both), asy_system_service, bus_hazard_generated, twin bus hazard, conftest, serving_at_default_gc, cross_browser_smoke_probe.
- Y2: _bus_hazard_catalog and test_bus_hazard_multi_device (steps and `Any`).
- Y3: the two UART files' `Any`.
- Y4: step 114.
- Y5: _sensortask_scenarios' `Any`, test_sensortask (OF-200); then Y's checks: typecheck.sh, lint.sh, the readers, per device at both stages.

**Lane D**
- D1: <PARTN>, tests_hardware/README, the SPEC items with no dependency (9, 10, 116, 145 (b), 161's clause, R-23).
- D2: the dependent SPEC sentences and BACKLOG.
- D3: B2's values and the Basis cells (scripted); then D's scans.

**Lane W**
- W1: the web files.
- W2: the tests_scripts hygiene; then the web tier.

**Lane B**
- B1: the documents and the 2**30 build.
- B2: the measurements, test.sh, the conformance review.

Commits are named `U35 lane <L>: …`. Branches are `audit/u35-<l>`.

### Base-time shards (`path@-1`/`@32768`; seconds are U32's or earlier figures, balance only)
- **A (about 780 s):**
  - tests/test_digital_twin_bus_hazard_concurrency.py@-1 (150), tests/test_uart_comm_hazard.py@-1 (105), tests/test_bus_hazard_generated.py@-1 (64), tests/test_asy_uart_comm.py@-1 (61), tests/test_asy_captive_dns.py@-1, tests/test_asy_ntp_client.py@-1, tests/test_asy_system_service.py@-1;
  - tests/test_digital_twin_sensortask_integration.py[arzi, dev, grkizi]@-1 and @32768.
- **B (about 780 s):**
  - the same seven files @32768;
  - test_digital_twin_sensortask_integration[klkizi, schlafzi, wozi] at both stages;
  - tests/test_sensortask.py[arzi, dev] at both stages.
- **C (about 780 s):** at both stages:
  - test_digital_twin_uart_link, test_asy_wifi_service, test_asy_scd30_driver, test_asy_notification_service, test_digital_twin_network_neopixel, test_asy_bmp3xx_driver, test_asy_neopixel_driver, test_asy_uart_driver, test_asy_udp_socket;
  - the four notification integration files, test_neopixel_wifi_integration, test_bus_hazard_multi_device, test_asy_isl29125_driver, test_asy_uart_link_driver, test_asy_fram_driver, test_asy_fram_manager, test_asy_crc_checks, test_asy_dns_client, test_asy_webserver_connections, test_asy_base_classes, test_digital_twin_fram, test_asy_config_manager, test_asy_print_log, test_math_helpers, test_shared_helpers, test_digital_twin_machine;
  - tests/test_sensortask.py[grkizi, klkizi, schlafzi, wozi];
  - plus the changed tests_scripts files: twin_runner_test_flags, ci_suite_soak, ci_suite_errcount, generated_boot, gc_collect_sites, twin_record, mypy_any_baseline, cross_browser_smoke_probe, definitions_js_mirrors, host_text_encoding, port_lock, tool_help, lint_ceilings, device_script_config_schemas, test_sh, citations.
- Twin per-device rows run under the 4-process cap.
- New files are after-only: test_driven_time, the sweep files.

### Hardware session 1 (parked by L-5; each run needs the owner's go-ahead in its session, the FRAM logs read first, the wear gates)
- **R0:** H56.
- **R1:**
  - H29 (steps 6, 7, 74);
  - H73 (step 5's rerun with OF-02/OF-05);
  - H43 at the end (102, 139, 156);
  - H44 and H55 (147);
  - H71 (153, from queue_c);
  - H83 (131 and OF-226);
  - step 3's timing;
  - H48 (127; not in U35's work-order rounds);
  - H04 (130, every round);
  - H39/H40 provisionally (132);
  - R-8's probe through the FRAM flash run;
  - R-9's silicon loop stretch (the lead assigns the H row);
  - OF-181's raw steps.
- **R2:** H17 (OF-60), H37 (OF-70).
- **R3:** H68 (step 3's backup-reset test), H73.
- **R4:** H55, H39/H40.
- **R5:** H55, H64.
- **Phase C:** 163's release proof.

### Not determinable read-only
- Whether every `Any` site has a form mypy accepts without a cast (Y).
- Whether `Task[Any]` (src/asy_system_service.py:229-230) can become `Task[object]` under the stubs.
- The shim's frame counts against `_YieldOnlyAsyncio`'s (N1 runs settle it).
- littlefs's commit point (P3).
- Whether folds (11)-(16) can be driven in-process (T3).
- Whether a boot with no SSID logs a W in the smoke's window (T2).
- The l0-l2 Basis count B2 can measure in one block: at the valve it stops at a seam and hands back what is left.
- All base times marked "measure".