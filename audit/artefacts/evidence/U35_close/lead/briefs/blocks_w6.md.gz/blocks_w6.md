# U35 wave 6 blocks: lanes T and U (lead, 2026-10-21)

Each block reads `S/u35/briefs/common_u35.md` first, then its own section here. About 60-80 tool calls each: count
them, and at 70 finish the step in hand, commit, and hand back the rest (CHECKLIST 21). CHECKLIST 22 (disk) and 23
(load) are binding. `<SHIMFIX>` (LEAD NOTES 22) touches no T or U site.

## T3a (lane T: the twin integration file, step 124)
Start: audit/u35-t at T2b's head `f9569b9` in S/wt-u35t (rebuilt); T2b's hand-back `S/u35/handbacks/T2b_final.md`.
File: tests/test_digital_twin_sensortask_integration.py.
- 124 (P1's row, lane_plan.md :312; the full change via `python3 -I S/u35/tools/steps.py 124`): test 2 becomes a `main()`
  run under `run()`, renamed, with `_feed_watchdog_periodically()` and the hand-started timers and tasks gone; it asserts
  `public_destinations_refused == 0` (today only printed on the runner's shutdown line) and, one full WDT period past the
  first supervisor feed, `would_have_triggered_count == 0`. Then folds (11)-(16) and (18), each seen failing first on a
  planted defect.
- CG's item (LEAD NOTES 20): the file holds a slot for 23.5 s wall at 3 CPU-s per device under settrace (arzi 119 s
  plain). List each real-time wait with what it waits for; move each that no assertion measures to a driven or
  event-gated form, every assertion kept; a wait whose real time is the scenario's subject stays, with a one-line reason.
- Runs: the file per device (TEST_DEVICE, all six, under the 4-process cap), paired base/head at both stages (U32: arzi
  119.08/118.64, dev 22.95/23.65, grkizi 21.65/22.05, klkizi 21.69/21.89, schlafzi 21.64/21.66, wozi 22.14/22.31); any
  new test's added time stated per test (LEAD NOTES 20's ruling on new checks).
- Hand-back: steps by verdict; the wait table; T3b's start state.

## T3b (lane T: the scenarios, generated_boot, Run 3's silent writes)
Start: T3a's head and hand-back, after the lead has merged P2b's `<SILENTW>` head into audit/u35-t (stated in your
prompt; if it is not there yet, do 125 and 149 first and hand back the Run 3 item). Files: scripts/_digital_twin_scenarios.py,
digital_twin/run_generic_integration.py, scripts/_twin_process.py, scripts/_digital_twin_ci_suite.py,
tests_scripts/test_digital_twin_generated_boot.py, tests_scripts/test_digital_twin_ci_suite_matrix.py,
tests_scripts/test_digital_twin_ci_suite_errcount.py, tests_scripts/test_digital_twin_scenarios.py, digital_twin/_fram_chip.py
(from P, LEAD NOTES 28) and, for the chip's case, tests/test_digital_twin_fram.py (handed with it).
- 125 (P1's row :313): (f) watchdog_fault_* on T1's `--test-watchdog-fault` and `WDT_AT_FAULT`; (g) A.U35.09's two
  recombinations; (h) the bounded storm on T1's `fram_writes*` fields; (i) zero_think readers; folds (1)-(3).
- 149 (row :487): `_normal_boot_log_failures` in the `/status` branch, the boot-sequence order, the :505-506 comment.
  155: check-only, one line.
- LEAD NOTES 24 and 28: digital_twin/_fram_chip.py is now T's. First show on the real dev twin whether a planted write
  storm (in a scratch copy) moves the chip's `silent_write_count` during Run 3; P2b reports a correct product issues no
  data-phase write to a silent chip, so it may not. If it cannot, the chip also counts write attempts while silent (a
  WREN), seen failing first in tests/test_digital_twin_fram.py. The runner prints the count Run 3 needs on the shutdown
  line, `ShutdownLine` parses it (a parser case seen failing first), and Run 3 checks it against T2b's bound
  (window / 627 ms x 2), bitten by the planted storm on the real twin and by T2b's stub plant. Run 3's L0 case goes in
  the matrix or errcount file.
- Runs: dev's suite `--only 3` and the scenario runs your steps touch, at both stages, base and head; the T readers of
  your files, paired.
- Hand-back: steps by verdict; T4's start state (T4 holds values, README, settrace, T's checks).

## U3a (lane U: owner question 5's hazard mode in dev's exerciser; step 148's bound)
Start: audit/u35-u at U2's head `f6f54cc` in S/wt-u35u; U2's hand-back `S/u35/handbacks/U2_final.md`. LEAD NOTES 12
(question 5's part, the owner's words and the lead's form) is the spec; LEAD NOTES 25 for 148. Files:
src/asy_uart_link_driver.py, tests/test_asy_uart_link_driver.py, tests/test_uart_comm_hazard.py.
- The hazard mode: off by default, reachable only on `dev`, started by a dispatch-only command (never persisted, so no
  boot starts in it and the flash-wear gate is untouched), running today's set from
  tests_hardware/device_scripts/uart_comm_hazards.py (read, not edited) through the protocol's existing API, bounded,
  then back to the normal echo. No emitted byte, accept/reject rule or timing changes (no Class A row); a Class B row,
  if needed, is relayed to P under `## P`. If the command needs buildgen/codegen.py or buildgen/definitions.py (lane C's
  files), stop before editing them and hand back exactly what is needed: the lead arranges the handover.
- Unit tests first, each seen failing; the mode's every verdict and its return to the echo are asserted.
- The `src/` edit: the mpy-cross compare (LEAD NOTES 7); test_twin_record goes red, expected. Effect per device (dev
  only; every other device wires no `uart_link`) and per mode (STA, AP, Silent, Off, USB).
- 148 (LEAD NOTES 25): restate `l1.uart_comm_hazard_clean_transaction_virtual_ms`'s basis: J.7's figure if J.7 states
  one, otherwise the measured virtual time with no margin; both plants stay red. Relay the new value under `## D`.
- Runs: link_driver and hazard paired base/head at both stages (U2's heads: 2.43/2.61 and 105.17/108.19).
- Hand-back: steps by verdict; the per-device and per-mode statement; U3b's start state.

## U3b (lane U: the crossing's NO_ACK, then the hazard route)
Start: audit/u35-u at `78fb201` in S/wt-u35u (U3a's `4d6568f` plus the lead's merge of C's `7442273`, rebuilt); U3a's
hand-back `S/u35/handbacks/U3a_final.md`; LEAD NOTES 31. Files: src/asy_uart_link_driver.py,
tests/test_asy_uart_link_driver.py, src/asy_webserver_service.py, buildgen/codegen.py, buildgen/definitions.py,
mockdata/samples.json, tests_scripts/test_buildgen_generate.py, tests_scripts/test_buildgen_definitions.py,
tests_js/templates.test.js, tests_js/definitions-mockdata-coverage.test.js.
- First, the open thread: why the crossing logs NO_ACK where PEER_INITIATED is expected, and why the first recovery try
  logs NO_ACK (the pinned `[85, 81, 81]`). Trace it at line level through src/asy_uart_comm.py and the mock (read
  only); a protocol defect is recorded with its class (J's accept/reject rules and timings are untouched), a test or
  mock cause is fixed in your files. The pin stays only with its cause written beside it.
- Re-check U3a's "stop, don't cancel" under the driven clock now that `<SHIMFIX>` is merged; use the plain cancel
  where it now holds.
- The route (LEAD NOTES 12's form): a dispatch-only PUT key on `/status` (U3a's proposal `{"UartHazards": true}`,
  beside ResetErrors) that calls `request_hazard_run()` and answers VALID or FAILED, generated only where a `uart_link`
  is wired; the report readable through a maintenance entry. Each piece seen failing first (buildgen, webserver,
  definitions, mock data, the two JS tests; npm runs in `unshare -n S/u24/ns_xdg.sh`). Nothing persists: the
  flash-wear gate stays untouched, shown by a test that the PUT writes no config.
- The `src/` edits: the mpy-cross compare; test_twin_record goes red, expected. Effect per device (dev only; the five
  others generate no key) and per mode (STA, AP, Silent, Off, USB).
- Runs: link_driver paired against `f6f54cc` at both stages; the buildgen and JS tests; every test file running a
  generated module on dev at both stages.
- Hand-back: the open thread's cause; the route; U3c's start state.

## U3c (lane U: the hazard route completed)
Start: audit/u35-u at `bfc6519` in S/wt-u35u (rebuilt at `78fb201`: rebuild before the runs, since U3b changed src/);
U3b's hand-back `S/u35/handbacks/U3b_final.md` (its remainder list is your list); LEAD NOTES 33. Files: lane U's
(lanes.py), which now include js/mock-server.js and tests/test_asy_webserver_service.py.
- The guard (LEAD NOTES 33): `_put_status`'s registered command takes SPECIFICATION.md G.2's caller-supplied callback
  dispatch guarding, the shape `_run_system_cmd` uses (its errno, `report_if_fatal`, `"Failed"`). Seen failing first in
  tests/test_asy_webserver_service.py on a command that raises (500 today), with the service-level test of
  `add_status_command` (Valid, Failed, Invalid for another value and for an unregistered key, nothing persisted). The
  mpy-cross compare (LEAD NOTES 7); test_twin_record goes red, expected.
- The two buildgen reader tests U3b updated: shown failing on base (`S/wt-u35base`, read only) and green on the head.
- mockdata/samples.json gains `status.sensors.UART_init {Runs, Pending, Last}`, the JS coverage test seen red first;
  tests_js templates and definitions-mockdata-coverage cases for the `uartHazards` group and the two fields; and
  js/mock-server.js answers `{"UartHazards": true}` as the device does on dev (G.3's mirror), seen failing first in a
  tests_js test. npm runs in `unshare -n S/u24/ns_xdg.sh` after a rebuild.
- Runs: the link driver test paired against `f6f54cc` (U3a's base) at both stages; the webserver service test paired
  base/head at both stages; every dev generated-module test file at both stages on the head; the readers of every file
  this block changes (grep), and the 12 commit checks.
- Hand-back: steps by verdict; the times; U3d's start state.

## U3d (lane U: the hazard mode under API load in the twin)
Start: audit/u35-u at `962602d` in S/wt-u35u (rebuild first: U3c changed src/); U3c's hand-back
`S/u35/handbacks/U3c_final.md`; LEAD NOTES 41. Files: lane U's (lanes.py).
- The twin proof (LEAD NOTES 12): tests/test_digital_twin_uart_link.py starts the hazard run through the route while
  readers hammer the API; every hazard's verdict is asserted, and so are zero MemoryError and no reboot, at both GC
  stages. Seen failing first on a planted hazard that misreports. U3a measured a run at about 3.6 min real time on
  dev's 1000 ms timeout: state the twin test's added time, and make it efficient where it can be without changing dev's
  configured timeout.
- The mock mirror's final `Promise.all` form (definitions-mockdata-coverage.test.js) is shown failing against the mock
  before U3c's change (a scratch copy of js/mock-server.js at `bfc6519`), in `unshare -n S/u24/ns_xdg.sh`.
- Runs: the link driver test paired against `f6f54cc` at both stages, through scripts/test.sh's own MICROPYPATH (no
  ext/ added by hand, LEAD NOTES 41); every dev generated-module test file at both stages on the head; the twin link
  file at both stages, paired against `bfc6519`.
- Hand-back: steps by verdict; the times; U3e's start state.

## U3e (lane U: the bench collection, the relays, U's checks; U's last block)
Start: audit/u35-u at `181c954` in S/wt-u35u (rebuilt at `962602d`; U3d changed no src/); U3d's hand-back
`S/u35/handbacks/U3d_final.md`; LEAD NOTES 49. Files: lane U's.
- First, the twin link file at 32768 (58.7 → 128.3 s; U3d's test serves 243 reads at -1 and 1464 at 32768): pace the
  readers on the driven clock so each run serves a fixed, stated number of requests at either stage, every assertion
  kept, U3d's bites still biting; paired against `bfc6519` at both stages. The file must not grow beyond what the new
  test needs (state it).
- The bench test (tests_hardware/bench/test_uart_link_under_api_load.py and its device script) gains the hazard run
  under the bench's reader load, collected only (`--collect-only`); its silicon run is parked for hardware session 1.
- Relay D2's lines under `## D`: SPECIFICATION.md E.6.6's `uart-hazards-under-api-load` row and the other "not written"
  sites; the route's A.8 sentence (`UartHazards`, dev only, dispatch-only); G.2's guarded-callback list naming
  `_run_status_cmd()`; tests_hardware/README.md; BACKLOG.md question 5's removal; the two hazards left out (LEAD NOTES
  31); U3a's five Part N rows and U3d's three (tests/test_digital_twin_uart_link.py:145, :147, :150).
- D.15's module-level and class order over every file lane U changed since `f3fff0e` (C5's checker
  `S/u35/laneC/c5/tools/d15.py`, run from the worktree with `PYTHONPATH=tests_scripts`; it misses class-body method
  defaults that run at import time, LEAD NOTES 36): buildgen/codegen.py, buildgen/definitions.py and the two buildgen
  tests were already out of order at base; each file its own commit, no content change (line multiset and top-level
  AST node multiset).
- U's complete checks: the readers of every file lane U changed (U3c's grep list: test_error_catalog,
  test_preview_server, test_js_api_mirrors, test_definitions_js_mirrors, test_api_reference and the rest);
  test_twin_record (red, expected); the silent-failure scan (CHECKLIST 16) of every file lane U changed since
  `f3fff0e`; the 17 scans.
- Hand-back: steps by verdict; the checks.

## U3f (lane U: U3e's three open items; U's last block)
Start: audit/u35-u at `8039259` in S/wt-u35u (U3e's `a3c3392` plus the lead's memory-catalog row; rebuild first: U3e's
reorders regenerated the device modules); U3e's hand-back `S/u35/handbacks/U3e_final.md`; LEAD NOTES 57. Files: lane U's.
- task_tops and task_inventory (4 and 16 failures): `_two_initiations()` (src/asy_uart_link_driver.py:201-211) creates
  two tasks running `uart_set()` with no task top. Give them the task-top form the convention's checks name (the
  existing tops in src/ are the model), so an exception in either is logged and the run's verdict reads it, seen
  failing first in tests/test_asy_uart_link_driver.py on a planted raising `uart_set()`; the C.9 row is relayed (U3e
  did).
- const_mirrors: src's new `_RECOVERY_ATTEMPTS` shares a name with tests/test_uart_comm_hazard.py:76 (`= 4`) and
  tests/test_digital_twin_uart_comm_hazard.py:38 (`= 2`, not lane U's). Rename the src constant
  `_HAZARD_RECOVERY_ATTEMPTS` with its three readers in lane U (the twin link test, the bench test, the link driver
  test) and its tag line; mpy-cross shows identical bytes for a `const()` rename.
- The class-1 finding in `_sweep_fields`: a raw write that fails is recorded as "not ACKed", which is the expected
  verdict for an illegal value, so a dropped frame passes silently (dev, STA and AP, under load). This is the unit's own
  new code, so it is fixed, not flagged: a failed raw write gets its own verdict that the twin and bench judges count as
  a failure, seen failing first on a planted write failure in the twin and the link driver test.
- The `src/` edits: the mpy-cross compare; test_twin_record red, expected. Per device (dev only) and per mode.
- Runs: the link driver, twin link, uart_comm_hazard and webserver service tests at both stages on the head; the 12
  checks; the 17 scans; the readers of the changed files.
- Hand-back: each item's verdict; the runs; the checks.

## R1 (root cause only: T3a's two unexplained reds; nothing committed)
Start: S/wt-u35r, a detached scratch worktree at T3a's head `ffd742f` (rebuilt). T3a's hand-back
`S/u35/handbacks/T3a_final.md`. You commit nothing and edit no tracked file in any lane worktree; planted or probe copies
go under `S/u35/laneR/` and run from there, first on MICROPYPATH (the lanes' method). A red is never called a flake: each
item ends in a root cause at line level, or in the exact runs and probes that leave it open.
- (a) Fold (14), class 4 if confirmed: on dev, one EIO on the SCD30's `readfrom_into` during the config snapshot sends
  `{'SCD30': {'SelfCal': None, ..., 'FRCWindow': None}}` instead of the failure marker the code reading predicts
  (`_config_snapshot` returning None), while bmp3xx gives the marker. T3a's draft and plant: `S/u35/laneT/t3a_plant14/`
  and `S/u35/laneT/t3a_h14_wt-u35t_dev_-1*.log`. Trace where the marker is lost (driver, the base class, the generated
  module's snapshot assembly, the webserver), state whether a failed read reaches the API as nulls on real hardware, in
  which modes and on which devices (every device wiring an SCD30), and name the fix and its file.
- (b) `test_a_supervised_task_death...` (tests/test_digital_twin_sensortask_integration.py:603 at that run) failed once
  on dev at -1: "56 B retained per supervised death: [1304832, 1304032, 1304032, 1303680, 1303456, 1303680, ...]"
  against a 32 B limit; it passed on the final file, at 32768 and on base. Run dev at -1 repeatedly on base
  (S/wt-u35base) and on this head, alternating, enough times to give the failure rate on each; find what the dip at
  death 4 is (what is allocated at that measurement, and why only sometimes) and whether any death retains memory.
  State whether the test's slope method lets one transient set the verdict, and the fix that keeps the check's
  strictness (a real per-death retention must still fail; prove it with a planted 64 B retention).
- Load: count heavy processes before each run; each dev run takes about 23 s; at most 2 of yours at once.
- Hand-back (at most 30 lines): each root cause, the evidence paths, the fix with its file and lane (lanes.py), and the
  per-device and per-mode effect for (a).

## T3c (lane T: the integration file's folds, the drift check, the remaining waits)
Start: T3b's head and hand-back; T3a's and R1's hand-backs (`S/u35/handbacks/T3a_final.md`, `R1_final.md`); LEAD NOTES
29 and 32. File: tests/test_digital_twin_sensortask_integration.py.
- The drift check (:603-604 at `ffd742f`, `test_a_supervised_task_death...`): replace the slope with R1's Theil-Sen form
  (`S/u35/laneR/b_fix/test_fix.py`), keeping the 32 B bound; seen failing first on R1's planted 64 B per death; run at
  -1, at 32768 and under settrace; the two known limits go in the hand-back and in a one-line comment.
- Fold (14) as a guard (green on head): bites at the SCD30 path (T3a's plant) and at bmp3xx's and isl29125's callback
  branch; every control runs from a directory with no plant in it (the Unix port puts the script's own directory first
  on sys.path).
- Folds (11), (13), (15), (16) and (18) (step 124's packet), each seen failing first; for (16) the connect poll's real
  500 ms step costs about 25 s per device: make it efficient where no assertion measures it.
- T3a's remaining real waits (test 4's link wait and uptime ticks, the PC-report test's link wait, tests 6-9's SGP40,
  SCD30 and monitor cycles): move each that no assertion measures; the rest stay with a reason.
- Runs: the file per device at both stages, paired against `f9569b9`; each new test's added time stated.
- Hand-back: steps by verdict; the wait table; T4's start state.

## T3d (lane T: the integration file's last folds and waits)
Start: audit/u35-t at `dc8c180` in S/wt-u35t (no rebuild needed; no src/ change since T3a); T3c's hand-back
`S/u35/handbacks/T3c_final.md`, with T3a's and T3b's for the folds' history; LEAD NOTES 29, 32, 35 and 42. File:
tests/test_digital_twin_sensortask_integration.py.
- Folds (11), (13) and (18) (step 124's packet, `python3 -I S/u35/tools/steps.py --standing 124`), each seen failing
  first on a planted defect run from its own scratch directory, the control from a clean one (R1's finding).
- The waits in tests 6-9 (SGP40 init and cycle waits, SCD30 and monitor cycles): move each that no assertion measures
  to a driven or event-gated form, every assertion kept; a wait whose real time is the subject stays, with a one-line
  reason. Each moved wait is seen failing on a planted defect.
- Runs: the file per device at both stages, paired against `dc8c180` (T3c's head), alternating; each fold's added time.
- Hand-back: steps by verdict; the wait table; the times; T3e's start state.

## T3e (lane T: T3b's leftovers in the suite)
Start: audit/u35-t at `5ca6b30` in S/wt-u35t (no rebuild needed); T3d's and T3b's hand-backs; LEAD NOTES 35 and 60.
Files: lane T's (lanes.py), the README excepted (T4's).
- T3d's class-3 gap in fold (18) (tests/test_digital_twin_sensortask_integration.py test 10): its wake-up bound does not
  catch a listener that sleeps one idle poll before each read. Count the socket's idle sleeps during the burst (at most
  1), seen failing first on that planted listener.
- 149's booted boot order (R-24): the twin log's boot-phase markers located at line level, then the order asserted at
  the booted level, seen failing first on a planted reorder.
- 125 (f)-(i) and its folds (1)-(3) (step 125's packet), each seen failing first.
- Runs: each changed file's readers and the twin suite runs that exercise the change, per device where it applies, at
  both stages, paired against T3d's head.
- Hand-back: steps by verdict; the times; T4's start state.

## P6 (lane P: P5's two open reds; P's last block)
Start: audit/u35-p at `596e7ff` in S/wt-u35p (rebuilt at P5's print_log change); P5's hand-back
`S/u35/handbacks/P5_final.md`; LEAD NOTES 56. Files: tests/test_asy_config_manager.py and tests/_async_harness.py (P's
for this block).
- test_microtest's `asyncio.run() only in the harness`: P4's `_run_to_interrupt()` (tests/test_asy_config_manager.py
  :3321) calls `asyncio.run()` to let a KeyboardInterrupt escape a parked flush as the boot entry's loop does. Move
  that runner into tests/_async_harness.py as a named helper beside `run()`, with its behaviour stated (it runs until a
  KeyboardInterrupt ends it, then a fresh event loop and `cur_task` cleared, as the boot entry's new_event_loop()
  does), called only from synchronous test scope (CLAUDE.md's nested-run rule); the three interrupt tests keep every
  assertion and each P4 bite still bites.
- test_microtest's json.loads count (2 for this file, "config files and a decoder stand-in"): route the 9 new
  `json.loads(...)` reads of stored documents (:2461 and the eight `json.loads(files.docs[path])` sites) through one
  module helper, so the file holds 2 sites again. The allow-list is not touched.
- Runs: test_asy_config_manager at both stages; test_microtest and every reader of the harness (grep `_async_harness`)
  at both stages where they run MicroPython; the 12 commit checks.
- Hand-back: both verdicts; the runs.

## T3f (lane T: step 125's (f)-(i) and its folds (1)-(3); before W6)
Start: audit/u35-t at `7f5501d` in S/wt-u35t (no rebuild needed); T3e's and T3b's hand-backs; LEAD NOTES 35 and 62.
Files: lane T's (lanes.py), the README excepted (T4's).
- Step 125's (f)-(i) and its folds (1)-(3) (`python3 -I S/u35/tools/steps.py --standing 125`): nine scenarios the
  registry does not hold yet. Their blockers have landed (the runner's `--test-watchdog-fault` and `WDT_AT_FAULT` at
  :452 and :868; the shutdown line's `fram_writes_by=` and `fram_writes_unattributed=` at :381-400). Each is seen
  failing first on a planted defect run from its own scratch tree, at both GC stages, and registered with the needs
  and drivers flags the registry's other entries carry.
- Runs: each new scenario per device where it applies, at both stages; the suite's readers (the matrix, errcount, soak
  and scenarios files); the 12 checks.
- Hand-back: each scenario by verdict; the times; T4's start state.

## T3g (lane T: the storm bound's host independence, step 125's (g) and folds (1)-(3); before W6)
Start: audit/u35-t at `b7d9f31` in S/wt-u35t (no rebuild needed); T3f's hand-back `S/u35/handbacks/T3f_final.md`;
LEAD NOTES 65. Files: lane T's (lanes.py), the README excepted (T4's).
- First, (h)'s bound (`a_bounded_fault_storm_keeps_every_logger_within_its_persisted_log_rate`): it reads
  window / 627 ms x 2 over spawn-to-exit, so the idle boot pads the window; SGP40 wrote 28 against 30 in every control,
  and a host that runs it in under about 8.8 s fails with no defect. Make the bound independent of host speed, every
  check kept: the window is the storm's own (its first fault to its last counted write, both from the twin's log or
  the shutdown line), or the bound counts entries per storm event against the product's own rule (each failing cycle
  persists its failure and C.7's streak entry, src/asy_base_classes.py:584). Seen failing first: the old form on a
  window shortened to a fast host's, the new form passing there; plant B (40 writes per entry) still bites.
- Step 125's (g)(a), (g)(b) and folds (1)-(3), with T3f's facts: the harness boots in AP, so (g) PUTs SSID and NTPHost
  and relaunches on the same state; under `unshare -n` the NTP code is NTP_NOT_SENT (the suite's
  `_ntp_unreachable_verdict`), and the harness may not import tests/; fold (3) runs as root here, so use a write probe
  with `setpriv --bounding-set=-dac_override` rather than a uid skip; fold (1) uses HTTP_PEER_RESET; fold (2) needs a
  `--fault` MATCH only the config snapshot hits (digital_twin/launch.py:500). Each seen failing first on a planted
  defect from its own scratch tree, at both stages.
- Tags: each new literal carries its `@tunable` tag with a basis; relay the rows under `## D` (T3f's three
  `l2.zero_think_*` rows too, estimated, agent).
- Runs: each changed scenario per device where it applies, at both stages; the suite's readers; the 12 checks.
- Hand-back: each item by verdict; the times; T4's start state.

## P3 (lane P: R-9, the config flush in chunks)
Start: audit/u35-p at `83e8633` in S/wt-u35p (rebuilt); P2b's hand-back `S/u35/handbacks/P2b_final.md`; R-9 and LEAD
NOTES 2b in the plan; OF-225's row in `audit/sweeps/open_findings.md`. Files: src/asy_config_manager.py,
tests/test_asy_config_manager.py, UART_C_PORT_CHANGELOG.md (only if B68's threshold moves).
- First, read only: littlefs's commit point in v1.29.0 (`lib/littlefs` and `extmod/vfs_lfsx.c` in the toolchain's
  checkout under `/root/pico-toolchain`), stated at line level: what a reader opening the file mid-write sees, and
  what a power loss mid-write leaves.
- Seen failing first in test_asy_config_manager.py: a flush yields between fixed-size slices of the text already
  serialised, each slice within a bound grounded in one sector erase (J.6, Part N `uart.flash_hold_max_ms`); the bite
  is today's one-stretch write. Then one helper serves both sites (:399-401, :584-586 at the base); no `flush()` or
  sync between slices. The chunk size, if a new constant, carries its tag and a relayed Part N row.
- `_config_lock` stays held across every yield: name it by line, and name every reader of the config file and whether
  it takes the lock. The L1 hazard test (CLAUDE.md's shared-resource rule): a concurrent PUT and a concurrent read of
  the same document during a yielded write see the old or the new document, never a torn one, seen failing first on a
  planted lock release. A twin test only if the twin's filesystem models commit at close; else say why at line level.
- The allocation per flush before and after, at both stages: no new whole-document copy, the slice churn stated, zero
  MemoryError and zero "memory allocation failed".
- The `src/` edit: the mpy-cross compare (LEAD NOTES 7); test_twin_record goes red, expected. Effect per device (every
  device persists config) and per mode (STA, AP, Silent, Off, USB; boot's validation write named).
- Relay under `## D`: the figures D needs to re-derive J.6 and `uart.rx_ring_floor`'s hold term (dev's configured ring
  stays). If B68's threshold moves, a Class B row in UART_C_PORT_CHANGELOG.md.
- Runs: test_asy_config_manager paired base/head at both stages; every importer of asy_config_manager (grep) at both
  stages on the head, the per-device files on all six.
- Hand-back: steps by verdict; littlefs's commit point; the allocation figures; P4's start state.

## P4 (lane P: the chunked flush's residuals and a shared commit-at-close fake)
Start: audit/u35-p at `934539c` in S/wt-u35p (rebuild first: P3 changed src/); P3's hand-back
`S/u35/handbacks/P3_final.md`; LEAD NOTES 46. Files: src/asy_config_manager.py, tests/test_asy_config_manager.py, and a
new tests/_littlefs_fake.py (P's).
- The interrupt residual (P3's class-5 finding, USB mode, all devices): a KeyboardInterrupt while the flush is parked at
  a yield leaves the handle to gc's finaliser, which commits a prefix (vfs_lfsx_file.c:95), so the next boot falls back
  to defaults. Extend `_write_text()`'s cancel fallback (write the rest, close, re-raise) to KeyboardInterrupt, seen
  failing first on a planted interrupt at a yield (the committed text is the whole new document or the whole old one).
- A failing close inside that fallback must not replace the cancel or the interrupt: the close's OSError is logged
  through the module's logger and the original exception propagates, seen failing first on a planted close failure.
- The slice churn: write `memoryview` slices of the serialised text in place of `str` slices. The pinned port's `str`
  exposes the buffer protocol (py/objstr.c:2219, :2351); the lead's probe measured a 256-byte slice at 64 B against
  128 B for a 20-char `str` slice, and a text-mode file takes the slices, a split UTF-8 sequence included
  (`S/u35/lead/mv_probe.txt`). Slice by bytes, keep `_FLUSH_SLICE_CHARS`'s meaning stated (or rename it with its tag
  and relay the row change to D), re-measure P3's allocation figures at both stages, and state what remains of the
  MemoryError-in-fallback residual.
- tests/_littlefs_fake.py: lift P3's `_LittlefsOpen` (commit at close: a reader opening the file mid-write gets the old
  document whole, a new file reads empty) into this shared fake, used by test_asy_config_manager. Lane V's
  test_bus_hazard_multi_device.py:1095 needs it (V4, after the lead merges P4's head into V).
- The `src/` edits: the mpy-cross compare; test_twin_record red, expected. Effect per device and mode.
- Runs: test_asy_config_manager paired against `83e8633` at both stages; the 20 importers at both stages on the head;
  test_sensortask on all six at both stages.
- Hand-back: steps by verdict; the allocation figures; P5's start state.

## P5 (lane P: R-10, then P's checks; P's last block)
Start: audit/u35-p at `65f7454` in S/wt-u35p (its generated tree current); P4's hand-back `S/u35/handbacks/P4_final.md`;
LEAD NOTES 52. First: every place in src/, tests/, digital_twin/, scripts/, buildgen/ and tests_hardware/ that lists,
globs or counts a config directory's files is checked for P4's `<file>.tmp` sibling, one line each with its verdict; a
site in a P file that would misread it is fixed, seen failing first; one in another lane's file goes in the hand-back. Files: src/asy_print_log.py, tests/test_asy_print_log.py, and P's for the checks.
- R-10 (OF-221): the test first in test_asy_print_log.py: two `ResetErrors` at once on one store, the newest code
  repeating between their starts, and a pause refusing the later reset's write. Fix src/asy_print_log.py only if it
  fails, then with the mpy-cross compare and the per-mode effect; if it passes, the test stays as the guard and the
  row's reading is stated wrong at line level.
- UART_C_PORT_CHANGELOG.md: one row per change lane P made to src/asy_uart_comm.py since `f3fff0e`, classified; the
  exerciser gets none (LEAD NOTES 31).
- P's complete checks: the mpy-cross compare for every `src/` file lane P changed since `f3fff0e`, the silent-failure
  scan of P's files, the 17 scans, every reader of a P file.
- Hand-back: R-10's verdict; the checks.
